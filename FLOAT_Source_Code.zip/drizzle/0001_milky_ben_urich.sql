CREATE TABLE `practice_sessions` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`mode` text NOT NULL,
	`craft` text NOT NULL,
	`status` text DEFAULT 'in_progress' NOT NULL,
	`payload` text NOT NULL,
	`answers` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`score` integer DEFAULT 0 NOT NULL,
	`total` integer NOT NULL,
	`moves` integer DEFAULT 0 NOT NULL,
	`xp` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	`completed_at` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `practice_user_active_mode` ON `practice_sessions` (`user_id`,`mode`) WHERE "practice_sessions"."status" = 'in_progress';--> statement-breakpoint
CREATE INDEX `practice_user_status` ON `practice_sessions` (`user_id`,`status`);