CREATE TABLE `attempts` (
	`id` text PRIMARY KEY NOT NULL,
	`user_id` text NOT NULL,
	`kind` text NOT NULL,
	`status` text NOT NULL,
	`question_order` text NOT NULL,
	`answers` text NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`score` integer,
	`evaluation` text,
	`certificate_name` text,
	`completed_at` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `attempt_user_kind` ON `attempts` (`user_id`,`kind`);--> statement-breakpoint
CREATE TABLE `profiles` (
	`user_id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`age` integer,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `progress` (
	`user_id` text NOT NULL,
	`part_id` text NOT NULL,
	`status` text DEFAULT 'not_yet' NOT NULL,
	`exercise_passed` integer DEFAULT 0 NOT NULL,
	`viewed` integer DEFAULT 0 NOT NULL,
	`updated_at` text NOT NULL,
	PRIMARY KEY(`user_id`, `part_id`)
);
