// Runs the real route logic with in-memory SQLite and two mock authenticated users.
const fs=require('node:fs'),path=require('node:path'),ts=require('typescript'),assert=require('node:assert/strict'),{DatabaseSync}=require('node:sqlite');
const sql=new DatabaseSync(':memory:');sql.exec(fs.readFileSync('drizzle/0000_blushing_mach_iv.sql','utf8'));
const database={prepare(s){
 return {bind(...args){
  return {
   async first(){return sql.prepare(s).get(...args)||null},
   async all(){return {results:sql.prepare(s).all(...args)}},
   async run(){return {meta:{changes:Number(sql.prepare(s).run(...args).changes)}}}
  };
 }};
}};
let user={userId:'learner-a',email:'a@example.test'};const cache={};
function load(file){file=path.resolve(file);if(cache[file])return cache[file].exports;const m={exports:{}};cache[file]=m;const code=ts.transpileModule(fs.readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;new Function('require','module','exports',code)(name=>{if(name.includes('chatgpt-auth'))return {getChatGPTUser:async()=>user};if(name==='@/lib/store')return {db:()=>database};return load(name.startsWith('@/')?name.slice(2)+'.ts':path.resolve(path.dirname(file),name+'.ts'))},m,m.exports);return m.exports;}
const route=load('app/api/learning/route.ts'),cert=load('app/api/certificate/route.ts'),{bank,createOrder}=load('lib/questions.ts'),{parts,evaluation}=load('lib/curriculum.ts');
async function call(body,status=200){const r=await route.POST(new Request('https://example.test/api/learning',{method:'POST',headers:{origin:'https://example.test','content-type':'application/json'},body:JSON.stringify(body)}));const j=await r.json();assert.equal(r.status,status,JSON.stringify(j));return j;}
async function get(){return (await route.GET(new Request('https://example.test/api/learning'))).json()}
(async()=>{
assert.equal(parts.length,61);assert.equal(bank.length,70);assert.equal(new Set(bank.map(q=>q.prompt)).size,70);
for(let i=1;i<=35;i++){const a=bank.find(q=>q.id===`pre-${i}`),b=bank.find(q=>q.id===`post-${i}`);assert.equal(a.correct,b.correct);assert.notEqual(a.prompt,b.prompt);assert.equal(new Set(a.choices.map(x=>x.id)).size,4)}
assert.notDeepEqual(createOrder('pre'),createOrder('pre'));
assert.equal(evaluation(0),'Poor understanding');assert.equal(evaluation(14),'Needs more learning');assert.equal(evaluation(21),'Not bad');assert.equal(evaluation(27),'Good understanding');assert.equal(evaluation(32),'Good job');
user=null;assert.equal((await route.GET(new Request('https://example.test/api/learning'))).status,401);user={userId:'learner-a',email:'a@example.test'};
await call({action:'profile',name:'Test Learner',age:''});await call({action:'part',partId:parts[0].id,status:'learned'},403);await call({action:'start',kind:'post'},403);
let state=await call({action:'start',kind:'pre'});let a=state.attempts[0];assert.equal(a.questions.length,35);assert.ok(a.questions.every(q=>!('correct'in q)&&!('explanation'in q)));
const first=a.questions[0];let answers={[first.id]:first.choices[0].id};state=await call({action:'answers',attemptId:a.id,revision:a.revision,answers});assert.deepEqual((await get()).attempts[0].answers,answers);await call({action:'answers',attemptId:a.id,revision:a.revision,answers},409);a=state.attempts[0];await call({action:'submit',attemptId:a.id,revision:a.revision,answers},400);
answers=Object.fromEntries(bank.filter(q=>q.kind==='pre').map(q=>[q.id,q.correct]));state=await call({action:'submit',attemptId:a.id,revision:a.revision,answers});a=state.attempts[0];assert.equal(a.score,35);assert.equal(a.evaluation,'Good job');assert.equal(state.parts.length,61);
const started=await call({action:'start',kind:'pre'});assert.equal(started.attempts.length,1);assert.equal(started.attempts[0].status,'completed');await call({action:'submit',attemptId:a.id,revision:0,answers:{}});assert.equal((await get()).attempts[0].score,35);
for(const p of parts)await call({action:'part',partId:p.id,status:'learned'});assert.equal((await get()).unlocked,false);await call({action:'start',kind:'post'},403);
await call({action:'exercise',partId:parts[0].id,answer:parts[1].id});assert.equal((await get()).progress[0].exercise_passed,0);
for(const p of parts.slice(0,60))await call({action:'exercise',partId:p.id,answer:p.id});assert.equal((await get()).unlocked,false);
await call({action:'exercise',partId:parts[60].id,answer:parts[60].id});assert.equal((await get()).unlocked,true);
state=await call({action:'start',kind:'post'});let b=state.attempts.find(a=>a.kind==='post');assert.equal(b.questions.length,35);answers=Object.fromEntries(bank.filter(q=>q.kind==='post').map(q=>[q.id,q.correct]));
await call({action:'part',partId:parts[0].id,status:'almost'});await call({action:'submit',attemptId:b.id,revision:b.revision,answers},403);await call({action:'part',partId:parts[0].id,status:'learned'});state=await call({action:'submit',attemptId:b.id,revision:b.revision,answers});assert.equal(state.attempts.find(a=>a.kind==='post').score,35);
let cr=await cert.GET(new Request(`https://example.test/api/certificate?id=${a.id}`));assert.equal(cr.status,200);assert.match(await cr.text(),/Test Learner/);
await call({action:'profile',name:'Renamed Learner',age:25});cr=await cert.GET(new Request(`https://example.test/api/certificate?id=${a.id}`));assert.match(await cr.text(),/Test Learner/);
user={userId:'learner-b',email:'b@example.test'};assert.equal((await get()).attempts.length,0);await call({action:'profile',name:'Other User',age:null});await call({action:'answers',attemptId:a.id,revision:0,answers:{}},404);assert.equal((await cert.GET(new Request(`https://example.test/api/certificate?id=${a.id}`))).status,404);
console.log('PASS: 70 paired questions, shuffling, evaluation bands, saved answers, single attempt, both 61-part gates, scoring, certificate ownership and immutable names.');
})().catch(e=>{console.error(e);process.exitCode=1});
