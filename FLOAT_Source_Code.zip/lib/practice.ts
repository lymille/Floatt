import {parts} from './curriculum';
import {shuffle} from './questions';
import freefall from './practice-freefall.json';

export type PracticeMode='quiz'|'match';
export type Craft='both'|'davit'|'freefall';
export type PracticeSummary={quizCount:number;gameCount:number;bestQuiz:number|null;bestGame:number|null;xp:number;perfectQuiz:boolean;perfectGame:boolean};
export const emptyPractice:PracticeSummary={quizCount:0,gameCount:0,bestQuiz:null,bestGame:null,xp:0,perfectQuiz:false,perfectGame:false};
type Item={id:string;name:string;purpose:string;category:string;craft:'davit'|'freefall';concept:string};
export const practiceItems:Item[]=[...parts.map(p=>({...p,craft:'davit' as const,concept:p.id})),...freefall.map(p=>({...p,craft:'freefall' as const}))];
export const craftName=(craft:string)=>craft==='both'?'Both lifeboats':craft==='freefall'?'Free-fall lifeboat':'Davit lifeboat';
export type QuizQuestion={id:string;concept?:string;prompt:string;choices:{id:string;text:string}[];correct:string;explanation:string;name:string;category:string;craft:string};
export type MatchPair={id:string;left:string;right:string;name:string;purpose:string;craft:string;category:string};
export type PracticePayload={questions?:QuizQuestion[];pairs?:MatchPair[];leftOrder?:string[];rightOrder?:string[]};
export type MatchMove={id:string;left:string;right:string;correct:boolean};

export function createPractice(mode:PracticeMode,craft:Craft,count:number,excludedConcepts:string[]=[]):PracticePayload{
 const seen=new Set<string>();
 const pool=shuffle(practiceItems.filter(p=>(craft==='both'||p.craft===craft)&&!excludedConcepts.includes(p.concept))).filter(p=>{if(seen.has(p.concept))return false;seen.add(p.concept);return true;});
 const chosen=pool.slice(0,mode==='match'?6:count);
 if(mode==='match'){
  const pairs=chosen.map(p=>({id:p.id,left:crypto.randomUUID(),right:crypto.randomUUID(),name:p.name,purpose:p.purpose,craft:p.craft,category:p.category}));
  return {pairs,leftOrder:shuffle(pairs.map(p=>p.left)),rightOrder:shuffle(pairs.map(p=>p.right))};
 }
 return {questions:chosen.map((p,i)=>{
  const identify=i%2===0;
  const others=shuffle(pool.filter(x=>x.concept!==p.concept&&x.name.toLowerCase()!==p.name.toLowerCase()&&x.purpose!==p.purpose));
  const candidates=[...others.filter(x=>x.category===p.category),...others.filter(x=>x.category!==p.category)].slice(0,3);
  const choices=shuffle([p,...candidates]).map(x=>({id:crypto.randomUUID(),text:identify?x.name:x.purpose,correct:x.id===p.id}));
  return {id:crypto.randomUUID(),concept:p.concept,prompt:identify?`Which part fits this description? ${p.purpose}`:`What is the main purpose of ${p.name}?`,choices:choices.map(({id,text})=>({id,text})),correct:choices.find(c=>c.correct)!.id,explanation:`${p.name}: ${p.purpose}`,name:p.name,category:p.category,craft:p.craft};
 })};
}
