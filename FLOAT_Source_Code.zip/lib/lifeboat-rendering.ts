import * as THREE from 'three';
import {mergeGeometries} from 'three/addons/utils/BufferGeometryUtils.js';

// Batch only within a named equipment group. Picking, hiding and exploding
// continue to operate on that group; no geometry or equipment is removed.
export function batchInterior(root:THREE.Group){
 for(const group of root.children){
  if(!group.userData.sourceObjectId)continue;
  const batches=new Map<string,THREE.Mesh[]>();
  for(const child of group.children){
   if(!(child instanceof THREE.Mesh)||Array.isArray(child.material))continue;
   const material=child.material as THREE.MeshStandardMaterial;
   if(!material.isMeshStandardMaterial||material.map)continue;
   const key=JSON.stringify([material.color.getHex(),material.roughness,material.metalness,material.opacity,material.transparent,material.side,material.emissive.getHex(),material.emissiveIntensity,child.userData.compartmentCover||'']);
   const batch=batches.get(key)||[];batch.push(child);batches.set(key,batch);
  }
  for(const batch of batches.values()){
   if(batch.length<2)continue;
   const geometries=batch.map(mesh=>{mesh.updateMatrix();const geometry=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();geometry.applyMatrix4(mesh.matrix);return geometry;});
   const merged=mergeGeometries(geometries,false);geometries.forEach(g=>g.dispose());
   if(!merged)continue;
   const material=batch[0].material;
   const combined=new THREE.Mesh(merged,material);combined.userData={...batch[0].userData};group.add(combined);
   for(const mesh of batch){group.remove(mesh);mesh.geometry.dispose();if(mesh.material!==material)(mesh.material as THREE.Material).dispose();}
  }
 }
 root.updateMatrixWorld(true);
}

export function viewerMaterial(source:THREE.MeshStandardMaterial,lightweight:boolean){
 // Vertex-lit materials avoid the per-pixel PBR work on mobile GPUs.
 const material=lightweight?new THREE.MeshLambertMaterial({
  color:source.color,map:source.map,emissive:source.emissive,
  emissiveMap:source.emissiveMap,emissiveIntensity:source.emissiveIntensity,
  opacity:source.opacity,transparent:source.transparent,side:source.side,
  alphaTest:source.alphaTest,vertexColors:source.vertexColors,
 }):source.clone();
 material.userData.baseOpacity=source.opacity;
 return material;
}
