import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import type {ModelLabel} from './lifeboat-labels';

type V=[number,number,number];
const reference={label:'VIKING Norsafe GES-25 MKII — comparable interior systems',url:'https://myviking.viking-life.com/medias/GES-25-MKII-DS-0002-4.pdf?attachment=true&context=bWFzdGVyfHJvb3R8Mjg2ODU1fGFwcGxpY2F0aW9uL3BkZnxoNGMvaGYzLzkzMTMzNTIyMjA3MDIvR0VTLTI1IE1LSUlfRFMtMDAwMi00LnBkZnwzNmY5MjdkY2Y2NGIyM2NlZjFlMTI5MjQwMzVlOTk0MWEyZmY1YzNiNGZlODNiNDZhZmFlNDBkYzBjZTg4MTNh'};
const helmReference={label:'Fassmer-Marland CFL-C66E — seating direction (§3.18) and helm equipment (§3.36–3.44)',url:'https://www.mbshk.net/File/FD_Oshima10548_Lifeboat.pdf'};
const equipmentReference={label:'IMO LSA Code — equipment categories (§4.4.8; check applicable amendments)',url:'https://wwwcdn.imo.org/localresources/en/KnowledgeCentre/IndexofIMOResolutions/MSCResolutions/MSC.48(66).pdf'};

// Interior geometry stays in the same boat-local frame as the exterior.
// The parent builder applies the launch inclination to each named assembly.
export function buildFreefallInterior(pose:THREE.Matrix4){
 const root=new THREE.Group();root.name='Free-fall fitted interior';const equipment:ModelLabel[]=[];
 const mat=(color:number,roughness=.52,metalness=.04)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
 const M={liner:mat(0xd8ded6),seat:mat(0x809199,.75),floor:mat(0x637881,.86),metal:mat(0xb8c6cc,.30,.7),dark:mat(0x20343f,.68),yellow:mat(0xf4c64b,.80),blue:mat(0x123b69,.80),engine:mat(0x187f92,.40,.35),red:mat(0xcb4933),orange:mat(0xf08a26),water:mat(0xa9dce5,.28),white:mat(0xf4f4e7),green:mat(0x328877),rope:mat(0xc9b99c,.92)};
 const mesh=(g:THREE.Group,geo:THREE.BufferGeometry,m:THREE.Material,p:V)=>{const o=new THREE.Mesh(geo,m);o.position.set(...p);g.add(o);return o;};
 const box=(g:THREE.Group,p:V,size:V,m:THREE.Material,round=0)=>mesh(g,round?new RoundedBoxGeometry(...size,2,round):new THREE.BoxGeometry(...size),m,p);
 const cyl=(g:THREE.Group,p:V,r:number,h:number,m:THREE.Material,axis:'x'|'y'|'z'='y',n=12)=>{const o=mesh(g,new THREE.CylinderGeometry(r,r,h,n),m,p);if(axis==='x')o.rotation.z=Math.PI/2;if(axis==='z')o.rotation.x=Math.PI/2;return o;};
 const bar=(g:THREE.Group,a:V,b:V,w:number,d:number,m:THREE.Material)=>{const v=new THREE.Vector3(...a),end=new THREE.Vector3(...b),dir=end.clone().sub(v);const o=box(g,v.add(end).multiplyScalar(.5).toArray() as V,[w,dir.length(),d],m);o.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),dir.normalize());return o;};
 const tube=(g:THREE.Group,ps:V[],r:number,m:THREE.Material)=>mesh(g,new THREE.TubeGeometry(new THREE.CatmullRomCurve3(ps.map(p=>new THREE.Vector3(...p))),Math.max(12,ps.length*5),r,6,false),m,[0,0,0]);
 const ring=(g:THREE.Group,p:V,r:number,t:number,m:THREE.Material,axis:'x'|'y'|'z'='z')=>{const o=mesh(g,new THREE.TorusGeometry(r,t,6,18),m,p);if(axis==='y')o.rotation.x=Math.PI/2;if(axis==='x')o.rotation.y=Math.PI/2;return o;};
 function part(id:string,name:string,category:string,description:string,location:string,quantity='One illustrated assembly.',use='Identify this fitting and its connection to the surrounding equipment.'){
  const g=new THREE.Group();g.name=name;g.userData={sourceObjectId:`ff-${id}`,craft:'freefall',assembly:'interior',interior:true,concealedByShell:true};root.add(g);
  equipment.push({id:`ff-${id}`,objects:[`ff-${id}`],name,category,description,location,source:'Added training equipment',identification:'Illustrative fitted interior. Seating count, stock and storage positions describe this learning model, not an approved passenger capacity or vessel inventory.',references:[reference,equipmentReference],learning:{meaning:description,quantity,use,care:'Keep the actual fitting secured and follow the lifeboat’s approved instructions.'}});
  return g;
 }
 const nodes=()=>new Map(root.children.map(g=>[g.userData.sourceObjectId,g]));
 function stow(g:THREE.Group,id:string){
  g.userData.storageId=`ff-${id}`;
  const holder=equipment.find(e=>e.id===`ff-${id}`)!,item=equipment.find(e=>e.id===g.userData.sourceObjectId)!;
  item.stowage={id:holder.id,name:holder.name};item.location=`Secured inside the ${holder.name.toLowerCase()}. Zoom close to inspect the compartment.`;
 }
 function locker(id:string,name:string,p:V,s:V,category='Survival Equipment'){
  const g=part(id,name,category,'A secured compartment keeps its contents retained during the launch and voyage.','Fitted below the passenger seats, clear of the central aisle.');
  g.userData.storageCover=`ff-${id}`;g.userData.storageZone={center:p,size:s};
  box(g,p,s,M.liner,.012);box(g,[p[0],p[1]+s[1]/2+.007,p[2]],[s[0]+.008,.023,s[2]+.008],M.floor,.008);
  for(const dz of [-s[2]*.32,s[2]*.32]){box(g,[p[0],p[1]+s[1]/2+.023,p[2]+dz],[.12,.028,.04],M.metal);box(g,[p[0],p[1]+s[1]/2+.04,p[2]+dz],[.065,.014,.025],M.dark);}
  return g;
 }
 function pack(g:THREE.Group,p:V,s:V,m:THREE.Material){box(g,p,s,m,.01);for(const dz of [-s[2]*.25,s[2]*.25])box(g,[p[0],p[1]+s[1]/2+.004,p[2]+dz],[s[0]+.006,.014,.018],M.dark);}

 // A tapered deck with an aft machinery opening and an unobstructed aisle.
 const floor=part('cabin-deck','Cabin deck and central aisle','Structure','The fitted non-slip deck supports the seating and provides a passage from the boarding area.','Along the cabin centreline and beneath the seat mounts.','One deck with a central aisle.','Follow the clear aisle between the two seating banks.');
 const plan=new THREE.Shape();const outline:V[]=[[-1.23,.73,-2.12],[-1.22,.73,0],[-1.07,.73,1.65],[-.77,.73,2.85],[-.36,.73,3.48],[.36,.73,3.48],[.77,.73,2.85],[1.07,.73,1.65],[1.22,.73,0],[1.23,.73,-2.12]];
 plan.moveTo(outline[0][0],outline[0][2]);for(const p of outline.slice(1))plan.lineTo(p[0],p[2]);plan.closePath();
 const deckGeo=new THREE.ExtrudeGeometry(plan,{depth:.06,bevelEnabled:false});deckGeo.rotateX(Math.PI/2);deckGeo.translate(0,.73,0);mesh(floor,deckGeo,M.floor,[0,0,0]);
 for(let z=-1.98;z<2.25;z+=.20)box(floor,[0,.737,z],[.42,.012,.025],M.dark);
 box(floor,[0,1.19,-3.78],[1.25,.065,.28],M.floor);box(floor,[.89,.92,-3.61],[.42,.07,.30],M.floor);
 const structure=part('seat-foundations','Seat foundation rails','Structure','Rigid rails connect the passenger seat supports to the boat structure.','Under the port and starboard seating banks.','Two paired longitudinal foundations.');
 for(const x of [-1.00,-.46,.46,1.00])box(structure,[x,.77,-.46],[.075,.07,3.77],M.metal);

 // Passengers face -Z (aft). The separate operating helm faces +Z (bow).
 const seats:{id:string;x:number;z:number;color:number;helm:boolean}[]=[];
 function seat(number:number,x:number,z:number,elev=0,helm=false,color=M.yellow){
  const id=helm?'helm-seat':`seat-${String(number).padStart(2,'0')}`,name=helm?'Helmsman’s seat':`Passenger seat ${number}`;
  const g=part(id,name,'Safety Equipment','A shaped rear-facing seat supports the occupant during the free-fall launch.','Facing the stern; mounted securely to the cabin structure.','One illustrated seat. The model’s seat count does not establish a certified capacity.','Identify the seat pan, straight reclined backrest and head support.');
  g.userData.seat={facing:helm?[0,0,1]:[0,0,-1],number,helm};
  const y=1.045+elev;
  box(g,[x,y,z],[.45,.11,.47],M.liner,.035).name='seat-pan';box(g,[x,y+.077,z-.025],[.404,.065,.414],M.seat,.028);
  const back=box(g,[x,y+.47,z+.255],[.45,.84,.10],M.liner,.028);back.rotation.x=.16;back.name='seat-back';
  const pad=box(g,[x,y+.48,z+.192],[.394,.70,.055],M.seat,.022);pad.rotation.x=.16;
  box(g,[x,y+.995,z+.337],[.30,.17,.115],M.seat,.027);
  for(const sx of [-.18,.18]){bar(g,[x+sx,helm?1.65:.77+elev,z-.14],[x+sx,y-.055,z-.14],.042,.05,M.metal);bar(g,[x+sx,helm?1.65:.77+elev,z+.15],[x+sx,y-.055,z+.15],.042,.05,M.metal);}
  for(const sx of [-.24,.24]){box(g,[x+sx,y+.18,z-.02],[.048,.052,.34],M.dark,.016);bar(g,[x+sx,y+.16,z+.10],[x+sx,y-.02,z+.10],.032,.035,M.metal);}
  const belts=part(`${id}-harness`,`${helm?'Helmsman’s':`Seat ${number}`} four-point harness`,'Safety Equipment','Two shoulder straps and two lap straps meet at a central buckle to restrain the occupant.','Attached to this seat’s upper back and lower anchorage points.','One four-point harness per illustrated seat.','Identify both shoulder straps, lap straps and the central buckle.');
  belts.userData.harness={seatId:`ff-${id}`,color:color.color.getHex(),row:z};
  const buckle:V=[x,y+.17,z-.15];
  for(const s of [-1,1]){bar(belts,[x+s*.145,y+.85,z+.235],[x+s*.065,y+.32,z+.115],.037,.011,color);bar(belts,[x+s*.065,y+.32,z+.115],buckle,.037,.011,color);bar(belts,[x+s*.222,y+.035,z+.09],buckle,.043,.012,color);box(belts,[x+s*.127,y+.65,z+.197],[.053,.045,.018],M.metal);}
  box(belts,buckle,[.085,.060,.028],M.metal,.01);cyl(belts,[x,y+.17,z-.169],.022,.018,M.red,'z');
  if(helm){
   const turn=new THREE.Matrix4().makeTranslation(x,0,z).multiply(new THREE.Matrix4().makeRotationY(Math.PI)).multiply(new THREE.Matrix4().makeTranslation(-x,0,-z));
   for(const group of [g,belts])for(const child of group.children)child.applyMatrix4(turn);
   // The raised foot platform sits over the engine enclosure; feet and seat
   // supports land on this platform instead of intersecting the engine cover.
   box(g,[0,1.643,-2.72],[.88,.050,1.40],M.floor,.012).name='helm-platform';
   for(const px of [-.34,.34])bar(g,[px,1.18,-2.35],[px,1.618,-2.13],.045,.055,M.metal);
   for(const px of [-.28,.28])box(g,[px,1.677,-2.40],[.24,.020,.20],M.dark,.009);
   box(g,[.71,1.36,-2.95],[.31,.06,.37],M.floor,.012);
   const label=equipment.find(e=>e.id===g.userData.sourceObjectId)!;
   label.description='The raised helmsman’s operating seat faces the bow, giving the driver a forward view through the steering-shelter window.';
   label.location='In the raised aft steering shelter, behind the forward-facing console and above the engine enclosure.';
   label.learning={...label.learning!,meaning:label.description,quantity:'One illustrated steering seat with a restraint and raised foot platform.',use:'Identify the forward driving position. The helmsman’s launch seating and restraint procedure follow the actual craft’s approved arrangement.'};
  }
  seats.push({id:`ff-${id}`,x,z,color:color.color.getHex(),helm});
 }
 let seatNumber=0;
 for(const [row,z] of [-1.45,-.35,.75,1.56].entries())for(const [column,x] of (row===3?[-.50,.50]:[-.98,-.46,.46,.98]).entries())seat(++seatNumber,x,z,0,false,(column+row)%2===0?M.yellow:M.blue);
 seat(0,0,-2.76,1.00,true,M.yellow);
 root.userData.seats=seats;

 // Under-seat lockers, plus a low forward utility store.
 locker('provisions-locker','Provisions locker',[-.84,.93,-.88],[.68,.30,1.25]);
 locker('signal-locker','Distress-signal locker',[.84,.93,-.88],[.68,.30,1.25],'Signaling');
 locker('tools-locker','Tools and repair locker',[-.84,.93,.46],[.68,.30,1.15]);
 locker('thermal-locker','Thermal-aid locker',[.84,.93,.46],[.68,.30,1.15]);
 const bowLocker=locker('bow-locker','Forward equipment locker',[0,.98,2.80],[1.06,.41,.85]);equipment.find(e=>e.id===bowLocker.userData.sourceObjectId)!.location='Low in the narrowing bow, ahead of the seating.';
 const water=part('water','Drinking-water packs','Survival Equipment','Sealed potable-water packs form part of the survival supply.','Inside the provisions locker.','Representative packs are shown; actual carriage follows the approved person capacity.','Locate the drinking supply and keep its packaging clean.');
 for(const x of [-1.04,-.84,-.64])for(const z of [-1.25,-.96]){box(water,[x,.90,z],[.155,.14,.22],M.water,.025);cyl(water,[x,.98,z],.028,.025,M.blue);}stow(water,'provisions-locker');
 const food=part('rations','Emergency food rations','Survival Equipment','Waterproof ration packs contain the emergency food supply.','In the provisions locker beside drinking water.','Representative sealed packs.','Locate the ration packs and check their seals and expiry when inspecting real stock.');for(const x of [-1.04,-.83,-.62])pack(food,[x,.915,-.52],[.18,.13,.28],M.yellow);stow(food,'provisions-locker');
 const drink=part('drinking-vessel','Graduated drinking vessel','Survival Equipment','A small marked vessel helps distribute measured drinking water.','In the provisions locker.','One illustrated drinking vessel.');cyl(drink,[-.59,.918,-.755],.043,.12,M.metal);for(const y of [.89,.925,.955])box(drink,[-.545,y,-.755],[.008,.007,.023],M.dark);stow(drink,'provisions-locker');
 const rockets=part('rocket-flares','Rocket parachute flares','Signaling','Rocket distress signals carry a red light aloft under a parachute.','Retained in the distress-signal locker.','Four illustrated cartridges.','Identify the long sealed signal cartridges.');for(let i=0;i<4;i++){cyl(rockets,[.66+i*.115,.92,-1.00],.040,.62,M.red,'z');cyl(rockets,[.66+i*.115,.92,-1.32],.043,.04,M.dark,'z');}stow(rockets,'signal-locker');
 const flares=part('hand-flares','Red hand flares','Signaling','Handheld pyrotechnic signals help attract nearby rescuers.','In the distress-signal locker.','Six illustrated cartridges.','Distinguish hand flares from rocket flares and smoke signals.');for(let i=0;i<6;i++)cyl(flares,[.61+i*.09,1.02,-.56],.027,.21,M.orange,'z');stow(flares,'signal-locker');
 const smoke=part('smoke-signals','Buoyant smoke signals','Signaling','Floating signals produce orange smoke for daylight location.','In the distress-signal locker.','Two illustrated smoke-signal containers.');for(const x of [.69,.91]){cyl(smoke,[x,.895,-.46],.064,.10,M.orange);cyl(smoke,[x,.95,-.46],.066,.018,M.metal);}stow(smoke,'signal-locker');
 const torch=part('torch','Waterproof signaling torch','Signaling','A portable waterproof light supports close work and light signaling.','Secured in the tools and repair locker.','One illustrated torch with its spare-power case.');cyl(torch,[-1.02,.93,.20],.048,.27,M.dark,'z');cyl(torch,[-1.02,.93,.052],.064,.046,M.metal,'z');cyl(torch,[-1.02,.93,.025],.053,.012,M.white,'z');pack(torch,[-1.02,.93,.49],[.15,.12,.17],M.yellow);stow(torch,'tools-locker');
 const knife=part('knife','Jackknife and lanyard','Survival Equipment','A tethered utility knife provides a controlled cutting tool.','Retained inside the tools and repair locker.','One illustrated knife.');box(knife,[-.73,.925,.17],[.047,.034,.20],M.red,.014);tube(knife,[[-.73,.94,.29],[-.64,.96,.38],[-.62,.94,.22]],.005,M.rope);stow(knife,'tools-locker');
 const tools=part('repair-kit','Tool and repair kit','Emergency Equipment','A secured selection of tools supports permitted onboard adjustments and repairs.','Inside the tools and repair locker.','One illustrative tool tray; actual contents are craft-specific.');box(tools,[-.72,.84,.63],[.40,.045,.45],M.dark);for(const x of [-.84,-.70,-.56]){bar(tools,[x,.90,.47],[x,.90,.76],.025,.021,M.metal);box(tools,[x,.90,.45],[.054,.027,.04],M.red);}stow(tools,'tools-locker');
 const thermal=part('thermal-aids','Thermal protective aids','Safety Equipment','Packaged protective coverings help reduce heat loss.','Inside the thermal-aid locker.','Representative sealed packages.','Locate the packages and recognize their purpose as thermal protection.');for(const x of [.66,.99])for(const z of [.13,.55])pack(thermal,[x,.92,z],[.26,.10,.31],M.metal);stow(thermal,'thermal-locker');
 const medicine=part('seasickness','Anti-seasickness supplies','Safety Equipment','A sealed medicine pouch and bags are kept with the survival stores.','In the thermal-aid locker.','One illustrative medicine pouch and bag bundle.','Recognize the pouch; use medicines only according to their labels and approved medical guidance.');pack(medicine,[.83,.94,.88],[.47,.11,.19],M.white);stow(medicine,'thermal-locker');
 const anchor=part('sea-anchor','Sea anchor and line','Survival Equipment','A fabric drogue and its line help control drift and the boat’s attitude to the sea.','Folded in the forward equipment locker.','One illustrated drogue and coiled line.');pack(anchor,[-.25,.93,2.73],[.36,.20,.48],M.orange);for(let i=0;i<4;i++)ring(anchor,[.27,.85+i*.028,2.73],.18,.011,M.rope,'y');stow(anchor,'bow-locker');
 const bailer=part('bailer','Buoyant bailer','Survival Equipment','A hand scoop removes shallow water from the boat.','Inside the forward equipment locker.','One illustrated scoop.');box(bailer,[0,1.03,3.08],[.25,.025,.16],M.orange);for(const x of [-.12,.12])box(bailer,[x,1.075,3.08],[.023,.09,.16],M.orange);box(bailer,[0,1.075,3.155],[.25,.09,.02],M.orange);stow(bailer,'bow-locker');

 // Machinery is held below the aft steering platform in separate covered bays.
 const engineCover=locker('engine-cover','Aft engine enclosure',[0,1.055,-2.96],[1.10,1.10,1.44],'Propulsion');equipment.find(e=>e.id===engineCover.userData.sourceObjectId)!.location='Beneath the raised steering position, aft of the passenger cabin.';
 const engine=part('engine','Diesel engine','Propulsion','The inboard diesel engine supplies mechanical power to the propeller drive.','In the aft machinery bay under the helm.','One illustrated engine.','Locate the engine block, cylinder head and mounting beds.');
 for(const x of [-.34,.34]){box(engine,[x,.65,-2.88],[.12,.11,1.15],M.metal);for(const z of [-3.3,-2.47])box(engine,[x,.70,z],[.15,.065,.14],M.dark);}
 box(engine,[0,.90,-2.86],[.65,.40,.79],M.engine,.04);box(engine,[0,1.145,-2.86],[.55,.12,.81],M.metal,.022);
 for(const z of [-3.11,-2.87,-2.63])box(engine,[0,1.24,z],[.49,.10,.17],M.dark,.025);
 cyl(engine,[.08,1.32,-2.83],.06,.07,M.yellow);for(const x of [-.21,.21])for(const z of [-3.14,-2.61])cyl(engine,[x,1.22,z],.025,.035,M.metal,'y',6);
 cyl(engine,[0,.93,-2.42],.24,.08,M.dark,'z',20);cyl(engine,[0,.93,-2.369],.18,.02,M.metal,'z',20);stow(engine,'engine-cover');
 const gearbox=part('gearbox','Marine gearbox','Propulsion','The gearbox transmits engine power to the propeller shaft.','At the aft end of the engine.','One illustrated gearbox.');box(gearbox,[0,.87,-3.39],[.42,.33,.35],M.metal,.045);cyl(gearbox,[0,.79,-3.59],.11,.08,M.dark,'z');stow(gearbox,'engine-cover');
 const cooling=part('cooling','Engine cooling circuit','Propulsion','Hoses and a header tank form part of the engine cooling installation.','Beside the engine in the machinery enclosure.','One illustrated circuit.');box(cooling,[.37,1.32,-2.77],[.21,.19,.36],M.metal,.018);cyl(cooling,[.37,1.43,-2.77],.049,.035,M.dark);tube(cooling,[[.37,1.28,-2.90],[.43,1.06,-3.15],[.40,.88,-3.25],[.24,.84,-3.16]],.027,M.dark);stow(cooling,'engine-cover');
 const alternator=part('alternator','Alternator and drive belt','Propulsion','A belt-driven alternator provides electrical charging while the engine runs.','Low beside the engine.','One illustrated alternator.');cyl(alternator,[-.37,.91,-2.67],.11,.25,M.metal,'z');cyl(alternator,[-.37,.91,-2.51],.089,.04,M.dark,'z');tube(alternator,[[-.37,1.01,-2.48],[-.14,1.12,-2.48],[.14,.94,-2.48],[-.16,.81,-2.48],[-.37,.82,-2.48],[-.37,1.01,-2.48]],.011,M.dark);stow(alternator,'engine-cover');
 const exhaust=part('exhaust-pipe','Engine exhaust piping','Propulsion','Piping routes exhaust gases from the engine toward the stern outlet.','Along the starboard side of the engine bay.','One illustrated exhaust run.');tube(exhaust,[[.29,1.11,-2.94],[.43,1.10,-3.08],[.45,.78,-3.48]],.051,M.metal);cyl(exhaust,[.43,.75,-3.33],.083,.26,M.dark,'z');stow(exhaust,'engine-cover');
 const fuelCover=locker('fuel-cover','Fuel-tank access cover',[-.89,.60,-2.91],[.52,.35,1.30],'Propulsion');equipment.find(e=>e.id===fuelCover.userData.sourceObjectId)!.location='Under the port-side aft walkway, separated from survival supplies.';
 const fuel=part('fuel-tank','Diesel fuel tank','Propulsion','A fixed tank stores the engine’s fuel supply.','In a dedicated port-side machinery compartment.','One illustrated tank; volume is not specified by this model.');box(fuel,[-.89,.57,-2.91],[.45,.245,1.12],M.metal,.025);for(const z of [-3.28,-2.53])box(fuel,[-.89,.706,z],[.46,.025,.07],M.dark);stow(fuel,'fuel-cover');
 const valve=part('fuel-valve','Fuel shut-off valve','Propulsion','A valve controls the fuel supply connection from the tank.','At the aft fuel tank outlet.','One illustrated shut-off valve.');cyl(valve,[-.72,.70,-2.62],.031,.10,M.metal);bar(valve,[-.78,.757,-2.62],[-.66,.757,-2.62],.025,.025,M.red);stow(valve,'fuel-cover');
 const batteryCover=locker('battery-cover','Battery compartment',[.89,.60,-2.91],[.52,.35,1.30],'Propulsion');equipment.find(e=>e.id===batteryCover.userData.sourceObjectId)!.location='Under the starboard aft walkway, in a dedicated battery enclosure.';
 const batteries=part('batteries','Starting batteries','Propulsion','The battery installation supplies the engine starting and onboard electrical circuits.','Secured inside the starboard aft battery compartment.','Two illustrated battery units.');for(const z of [-3.22,-2.61]){box(batteries,[.89,.563,z],[.43,.235,.46],M.dark,.018);box(batteries,[.89,.689,z],[.43,.025,.46],M.liner);for(const x of [.76,1.02])cyl(batteries,[x,.72,z-.09],.026,.027,x<.9?M.red:M.blue);box(batteries,[.89,.716,z+.07],[.46,.015,.06],M.blue);}stow(batteries,'battery-cover');
 const shaft=part('propeller-shaft','Propeller shaft and stern tube','Propulsion','A rotating shaft carries the drive from the gearbox through the stern tube.','Below the aft boarding area, leading to the exterior propeller.','One shaft line.');bar(shaft,[0,.79,-3.59],[0,.35,-3.94],.065,.065,M.metal);cyl(shaft,[0,.55,-3.80],.087,.14,M.dark,'z');
 const steeringRam=part('steering-ram','Hydraulic steering actuator','Propulsion','A hydraulic actuator transmits helm movement to the steering assembly.','Low at the stern beside the shaft line.','One illustrated actuator.');cyl(steeringRam,[.54,.69,-3.70],.073,.33,M.metal,'x');cyl(steeringRam,[.25,.69,-3.70],.030,.25,M.metal,'x');box(steeringRam,[.15,.63,-3.71],[.14,.17,.10],M.dark);
 const bilge=part('bilge-pump','Manual bilge pump','Safety Equipment','A manually operated pump removes collected bilge water.','Accessible at the aft end of the cabin beside the machinery enclosure.','One illustrated manual pump.');box(bilge,[-.88,1.11,-2.17],[.20,.24,.14],M.liner,.025);cyl(bilge,[-.88,1.30,-2.17],.040,.17,M.metal);bar(bilge,[-1.00,1.4,-2.17],[-.76,1.4,-2.17],.035,.035,M.dark);tube(bilge,[[-.88,.99,-2.17],[-.79,.55,-2.13],[-.61,.18,-2.03]],.018,M.dark);

 // The operating helm looks forward (+Z) from the raised aft shelter.
 // Control faces point back toward the driver; the dash stays below the window.
 const console=part('console','Steering console','Navigation','The forward-facing helm station carries steering, propulsion and electrical controls below the forward window.','Ahead of the helmsman’s seat, on the forward side of the raised aft shelter.','One illustrated steering console.','Compare the driver’s forward view with the rear-facing passenger seating.');
 for(const x of [-.34,.34])box(console,[x,1.98,-2.13],[.10,.66,.14],M.liner,.015);
 box(console,[0,2.24,-2.13],[.85,.28,.29],M.liner,.028);
 const panelPose=new THREE.Matrix4().makeTranslation(0,2.53,-2.17).multiply(new THREE.Matrix4().makeRotationX(.35));
 const onPanel=(u:number,v:number,d:number)=>new THREE.Vector3(u,v,d).applyMatrix4(panelPose).toArray() as V;
 const dash=box(console,[0,0,0],[.85,.30,.055],M.dark,.016);dash.applyMatrix4(panelPose);
 const wheel=part('steering-wheel','Steering wheel','Navigation','The helm wheel commands the boat’s steering system from the forward-facing driving position.','Between the helmsman and the console, facing back toward the driver.','One illustrated helm wheel.','Locate the wheel in front of the driver, aligned with the bow and forward window.');
 const wheelCenter:V=[0,2.46,-2.385];
 ring(wheel,wheelCenter,.196,.020,M.dark);cyl(wheel,wheelCenter,.045,.09,M.metal,'z');
 for(let i=0;i<3;i++){const a=i*Math.PI*2/3;bar(wheel,wheelCenter,[Math.sin(a)*.18,2.46+Math.cos(a)*.18,-2.385],.024,.017,M.metal);}
 const wheelTilt=new THREE.Matrix4().makeTranslation(...wheelCenter).multiply(new THREE.Matrix4().makeRotationX(.18)).multiply(new THREE.Matrix4().makeTranslation(0,-2.46,2.385));
 for(const child of wheel.children)child.applyMatrix4(wheelTilt);
 bar(wheel,[0,2.46,-2.385],[0,2.43,-2.19],.075,.075,M.metal);
 const instruments=part('engine-instruments','Engine instrument panel','Propulsion','Gauges and warning lamps present engine operating information to the seated helmsman.','On the inclined dashboard ahead of the steering wheel, facing the driver.','One illustrative panel with three gauges.','Identify the engine instruments without confusing them with the compass or release controls.');
 for(const x of [-.29,-.10,.09]){
  const bezel=cyl(instruments,[0,0,0],.054,.021,M.metal,'z');bezel.position.set(...onPanel(x,.035,-.038));bezel.rotation.x+=.35;
  const face=cyl(instruments,[0,0,0],.046,.012,M.dark,'z');face.position.set(...onPanel(x,.035,-.053));face.rotation.x+=.35;
  bar(instruments,onPanel(x,.035,-.061),onPanel(x+.021,.063,-.061),.008,.008,M.white);
  for(let i=0;i<7;i++){const a=i*Math.PI/4-Math.PI*.75;bar(instruments,onPanel(x+Math.sin(a)*.032,.035+Math.cos(a)*.032,-.061),onPanel(x+Math.sin(a)*.038,.035+Math.cos(a)*.038,-.061),.003,.003,M.white);}
 }
 for(const x of [.25,.34]){const lamp=cyl(instruments,[0,0,0],.019,.014,x<.3?M.green:M.red,'z');lamp.position.set(...onPanel(x,.03,-.044));lamp.rotation.x+=.35;}
 const throttle=part('throttle','Engine throttle and gear control','Propulsion','A single lever provides the installed engine throttle and gear command.','At the driver’s right hand, on the starboard side of the helm.','One illustrated control lever.','Identify the propulsion control separately from the launch-release controls.');
 box(throttle,[.49,2.30,-2.33],[.14,.20,.22],M.dark,.02);bar(throttle,[.49,2.40,-2.33],[.49,2.56,-2.27],.028,.028,M.metal);mesh(throttle,new THREE.SphereGeometry(.045,12,8),M.red,[.49,2.56,-2.27]);
 const compass=part('compass','Steering compass','Navigation','The steering compass displays the boat’s heading from the helm position.','On the port side of the dashboard, below the forward viewing window.','One illustrated compass.');
 cyl(compass,[-.29,2.65,-2.13],.080,.08,M.dark);mesh(compass,new THREE.SphereGeometry(.067,16,10,0,Math.PI*2,0,Math.PI/2),M.metal,[-.29,2.69,-2.13]);bar(compass,[-.325,2.726,-2.13],[-.255,2.726,-2.13],.007,.009,M.red);
 const switches=part('electrical-switches','Battery and lighting switches','Navigation','A separate panel groups the battery and lighting controls beside the driver.','Within reach on the port side of the steering console.','One illustrated switch panel.');
 box(switches,[-.49,2.30,-2.32],[.15,.26,.06],M.dark,.015);for(const y of [2.23,2.30,2.37]){cyl(switches,[-.49,y,-2.365],.025,.026,M.red,'z');bar(switches,[-.51,y,-2.383],[-.47,y,-2.383],.008,.014,M.white);}
 for(const id of ['helm-seat','helm-seat-harness','console','steering-wheel','engine-instruments','throttle','compass','electrical-switches']){
  const label=equipment.find(e=>e.id===`ff-${id}`)!;
  label.references=[helmReference,reference];
  label.identification='Illustrative forward-facing operating helm, informed by the Fassmer-Marland CFL-C66E seating and control specifications. This is not a dimensional copy or a manufacturer-approved launch arrangement.';
 }
 for(const [id,x,name] of [['primary-release',.91,'Primary free-fall release control'],['secondary-release',-.91,'Secondary free-fall release control']] as const){
  const p=part(id,name,'Launching Equipment','A dedicated hydraulic control forms part of the free-fall release system.','At the aft control area, separate from engine and steering controls.','One illustrated control station.','Identify this release control; this learning model does not operate a launch mechanism.');
  box(p,[x,1.40,-3.43],[.18,.24,.19],M.metal,.025);cyl(p,[x,1.55,-3.43],.035,.10,M.metal);bar(p,[x,1.59,-3.43],[x,1.77,-3.35],.03,.035,M.red);box(p,[x,1.34,-3.325],[.15,.06,.012],M.red);
 }

 // Fixed safety fittings remain reachable beside the entrance and cabin aisle.
 const firstAid=part('first-aid','First-aid outfit','Safety Equipment','A secured waterproof case contains initial-care supplies.','On the port side near the aft boarding area.','One illustrated first-aid case.');pack(firstAid,[-1.09,1.60,-3.46],[.18,.28,.33],M.green);box(firstAid,[-.991,1.60,-3.46],[.012,.16,.045],M.white);box(firstAid,[-.991,1.60,-3.46],[.012,.045,.15],M.white);
 const extinguisher=part('extinguisher','Portable fire extinguisher','Emergency Equipment','A retained portable extinguisher provides the installed initial fire-fighting equipment.','In a bracket on the starboard side of the aft boarding area.','One illustrated extinguisher.');cyl(extinguisher,[1.13,1.70,-3.53],.073,.38,M.red);cyl(extinguisher,[1.13,1.91,-3.53],.030,.06,M.metal);bar(extinguisher,[1.13,1.96,-3.6],[1.13,1.96,-3.44],.025,.026,M.dark);ring(extinguisher,[1.13,1.69,-3.53],.080,.014,M.metal,'y');tube(extinguisher,[[1.13,1.91,-3.51],[1.06,1.84,-3.46],[1.04,1.52,-3.47]],.013,M.dark);
 const radio=part('vhf','Portable survival-craft VHF','Communication','A handheld marine radio supports communication with nearby rescuers.','In a retained bracket beside the aft cabin aisle.','One illustrative radio; assigned carriage follows the vessel’s emergency plan.');box(radio,[1.18,1.71,-2.19],[.09,.24,.13],M.yellow,.018);box(radio,[1.125,1.75,-2.19],[.014,.08,.08],M.dark);cyl(radio,[1.18,1.94,-2.23],.009,.21,M.dark);box(radio,[1.24,1.66,-2.19],[.03,.22,.17],M.metal);
 const sart=part('sart','Search and rescue transponder (SART)','Communication','A carried locating device helps compatible search radar identify the survival craft.','Secured in a port-side bracket near the entrance.','One illustrative carried device; allocation is vessel-specific.');cyl(sart,[-1.19,1.80,-2.48],.056,.34,M.yellow);cyl(sart,[-1.19,2.0,-2.48],.061,.07,M.dark);ring(sart,[-1.19,1.77,-2.48],.06,.009,M.metal,'y');
 const epirb=part('epirb','Emergency position-indicating radio beacon','Communication','A carried EPIRB can transmit a satellite distress alert when used as specified.','Shown secured in a separate port-side bracket.','Optional carried example; not an assumed extra requirement for every lifeboat.');cyl(epirb,[-1.19,1.72,-2.13],.065,.22,M.orange);cyl(epirb,[-1.19,1.865,-2.13],.047,.09,M.white);cyl(epirb,[-1.19,2.045,-2.13],.008,.27,M.dark);
 const manual=part('instructions','Operating instructions and survival manual','Safety Equipment','Retained instructions identify the craft-specific controls and survival guidance.','Beside the aft cabin aisle.','One illustrated document holder.');box(manual,[-1.14,1.51,-2.79],[.05,.30,.21],M.blue,.012);for(const y of [1.45,1.50,1.55,1.60])box(manual,[-1.109,y,-2.79],[.012,.011,.14],M.white);
 const lights=part('cabin-lights','Cabin lights','Navigation','Fixed interior lights illuminate the seating and access route.','On the inside of the canopy.','Two illustrated luminaires.');for(const [z,y] of [[-.8,2.53],[.8,2.28]]){box(lights,[0,y,z],[.12,.045,.34],M.dark,.012);box(lights,[0,y-.029,z],[.092,.025,.29],M.white,.01);}
 const vent=part('cabin-vent','Cabin ventilation fitting','Structure','A closable ventilation fitting serves the enclosed cabin.','High on the aft port side of the cabin.','One illustrative ventilation fitting.');box(vent,[-1.09,2.12,-3.02],[.06,.18,.26],M.liner,.016);for(const y of [2.06,2.10,2.14,2.18])box(vent,[-1.053,y,-3.02],[.013,.013,.20],M.dark);
 const ribs=part('cabin-frames','Internal canopy frames','Structure','Shallow frames support the inner enclosure and define the cabin shape.','Across the inside of the canopy, clear of the seated head space.','Three illustrated frame stations.');for(const [z,w,t] of [[-1.95,1.45,2.70],[.20,1.42,2.50],[1.90,1.23,2.19]]){const h=t-1.36;tube(ribs,[[-w*.93,1.35,z],[-w*.89,1.36+h*.54,z],[-w*.70,1.36+h*.86,z],[-w*.35,t-.07,z],[0,t-.025,z],[w*.35,t-.07,z],[w*.70,1.36+h*.86,z],[w*.89,1.36+h*.54,z],[w*.93,1.35,z]],.022,M.liner);}
 const handles=part('cabin-handholds','Interior handholds','Safety Equipment','Graspable handholds support movement along the boarding route.','Beside the aft entrance and raised helm.','Four illustrated handholds.');for(const x of [-.62,.62])for(const z of [-3.69,-2.03])tube(handles,[[x,1.16,z],[x,1.30,z-.045],[x,1.55,z-.045],[x,1.68,z]],.022,M.metal);

 // Each labelled group receives the identical boat pose; no interior object
 // is parented to an exterior shell that will fade or be hidden.
 for(const g of root.children)g.applyMatrix4(pose);
 root.updateMatrixWorld(true);
 return {root,equipment,seats,storage:nodes()};
}
