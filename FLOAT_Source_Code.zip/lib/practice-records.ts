import {db} from './store';
import type {PracticeSummary} from './practice';

export async function practiceSummary(uid:string):Promise<PracticeSummary>{
 const row=await db().prepare(`SELECT
 SUM(CASE WHEN mode='quiz' THEN 1 ELSE 0 END) AS quizCount,
 SUM(CASE WHEN mode='match' THEN 1 ELSE 0 END) AS gameCount,
 MAX(CASE WHEN mode='quiz' THEN ROUND(score*100.0/total) END) AS bestQuiz,
 MAX(CASE WHEN mode='match' THEN ROUND(score*100.0/total) END) AS bestGame,
 COALESCE(SUM(xp),0) AS xp,
 MAX(CASE WHEN mode='quiz' AND score=total THEN 1 ELSE 0 END) AS perfectQuiz,
 MAX(CASE WHEN mode='match' AND score=total THEN 1 ELSE 0 END) AS perfectGame
 FROM practice_sessions WHERE user_id=? AND status='completed'`).bind(uid).first<any>();
 return {quizCount:Number(row?.quizCount||0),gameCount:Number(row?.gameCount||0),bestQuiz:row?.bestQuiz??null,bestGame:row?.bestGame??null,xp:Number(row?.xp||0),perfectQuiz:!!row?.perfectQuiz,perfectGame:!!row?.perfectGame};
}
