import * as THREE from 'three';
import type {ModelLabel} from './lifeboat-labels';
import {buildFreefallInterior} from './freefall-interior';

// An original, illustrative training craft, not a certified arrangement.
// Boat-local axes: +Z bow, +Y up. Both skid runners share the ramp inclination.
export const FREEFALL_ANGLE=35*Math.PI/180;
const ORIGIN=new THREE.Vector3(0,4.05,0);
export const freefallShellIds=new Set(['ff-hull','ff-canopy','ff-wheelhouse','ff-front-window','ff-aft-window','ff-port-window','ff-starboard-window','ff-aft-door','ff-front-hatch','ff-joint']);
const boatReference={label:'VIKING Norsafe — free-fall lifeboat exterior and arrangement references',url:'https://www.viking-life.com/products/boats-and-davits/boats/free-fall-lifeboats/viking-norsafe-ges-45-free-fall-lifeboat-max-60-persons/'};
const launchReference={label:'VIKING Norsafe — free-fall boats and skid-launch davits',url:'https://www.viking-life.com/product-insights/offshore-free-fall-lifeboat-and-davit-systems/'};
type Point=[number,number,number];
type Section={z:number;w:number;top:number};
const sections:Section[]=[
 {z:-4,w:1.12,top:2.52},{z:-3.8,w:1.30,top:2.70},
 {z:-3.15,w:1.44,top:2.75},{z:-2,w:1.46,top:2.72},
 {z:0,w:1.44,top:2.56},{z:1.65,w:1.29,top:2.28},
 {z:2.85,w:1.04,top:1.93},{z:3.8,w:.63,top:1.58},
 {z:4.45,w:.22,top:1.27},{z:4.7,w:.025,top:1.15},
];
export function freefallPoint(x:number,y:number,z:number){return new THREE.Vector3(x,y,z).applyAxisAngle(new THREE.Vector3(1,0,0),FREEFALL_ANGLE).add(ORIGIN);}

// Connect the raised helm to the cabin without a roof slab through its occupant.
// Clip only the roof under the existing shelter; the outside silhouette stays intact.
function openHelmRoof(geometry:THREE.BufferGeometry){
 type Vertex={p:THREE.Vector3;n:THREE.Vector3;uv:THREE.Vector2};
 const position=geometry.attributes.position,normal=geometry.attributes.normal,uv=geometry.attributes.uv,index=geometry.index;
 const positions:number[]=[],normals:number[]=[],uvs:number[]=[];
 const planes=[{axis:'x' as const,edge:-.73,sign:1},{axis:'x' as const,edge:.73,sign:-1},{axis:'z' as const,edge:-3.49,sign:1},{axis:'z' as const,edge:-1.87,sign:-1}];
 function clip(poly:Vertex[],plane:typeof planes[number],inside:boolean){
  const out:Vertex[]=[];const distance=(v:Vertex)=>(v.p[plane.axis]-plane.edge)*plane.sign*(inside?1:-1);
  for(let i=0;i<poly.length;i++){const a=poly[i],b=poly[(i+1)%poly.length],da=distance(a),db=distance(b);if(da>=0)out.push(a);if((da>=0)!==(db>=0)){const t=da/(da-db);out.push({p:a.p.clone().lerp(b.p,t),n:a.n.clone().lerp(b.n,t).normalize(),uv:a.uv.clone().lerp(b.uv,t)});}}
  return out;
 }
 function emit(poly:Vertex[]){for(let i=1;i<poly.length-1;i++)for(const v of [poly[0],poly[i],poly[i+1]]){positions.push(...v.p.toArray());normals.push(...v.n.toArray());uvs.push(...v.uv.toArray());}}
 for(let i=0;i<(index?.count??position.count);i+=3){
  let poly=[0,1,2].map(j=>{const n=index?index.getX(i+j):i+j;return {p:new THREE.Vector3().fromBufferAttribute(position,n),n:new THREE.Vector3().fromBufferAttribute(normal,n),uv:new THREE.Vector2(uv.getX(n),uv.getY(n))};});
  if(poly.every(v=>v.p.y<2.5)){emit(poly);continue;}
  for(const plane of planes){emit(clip(poly,plane,false));poly=clip(poly,plane,true);if(!poly.length)break;}
 }
 const result=new THREE.BufferGeometry();result.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));result.setAttribute('normal',new THREE.Float32BufferAttribute(normals,3));result.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));geometry.dispose();return result;
}

export function buildFreefallLifeboat(){
 const root=new THREE.Group();root.name='Free-fall lifeboat and launch skid';
 const equipment:ModelLabel[]=[];
 const pixels=new Uint8Array(64*64*4);
 const paint=new THREE.DataTexture(pixels,64,64);
 // Small, repeatable gelcoat/paint grain; no network-dependent texture files.
 let seed=37;
 for(let i=0;i<pixels.length;i+=4){seed=(1664525*seed+1013904223)>>>0;const n=119+(seed%18);pixels[i]=pixels[i+1]=pixels[i+2]=n;pixels[i+3]=255;}
 paint.wrapS=paint.wrapT=THREE.RepeatWrapping;paint.repeat.set(12,12);paint.needsUpdate=true;
 const material=(color:number,roughness=.4,metalness=.05)=>new THREE.MeshStandardMaterial({color,roughness,metalness});
 const hull=material(0xe89725,.38),canopy=material(0xffb43e,.32),hatchPaint=material(0xf3a224,.36);
 const steel=material(0x007f91,.43,.46),edgeSteel=material(0x056777,.46,.42),metal=material(0xc3ccd0,.27,.8),dark=material(0x17242b,.76),glass=material(0x153345,.17,.3),white=material(0xe3eee6,.38),bronze=material(0xb88b3d,.35,.68),red=material(0xe75635,.38);
 for(const m of [hull,canopy,hatchPaint,steel,edgeSteel]){m.bumpMap=paint;m.bumpScale=.013;}
 const solid=(g:THREE.Group,geometry:THREE.BufferGeometry,mat:THREE.Material,p:Point=[0,0,0])=>{const m=new THREE.Mesh(geometry,mat);m.position.set(...p);g.add(m);return m;};
 const box=(g:THREE.Group,p:Point,size:Point,mat:THREE.Material)=>solid(g,new THREE.BoxGeometry(...size),mat,p);
 const cylinder=(g:THREE.Group,p:Point,r:number,length:number,mat:THREE.Material,axis:'x'|'y'|'z'='y',segments=16)=>{const m=solid(g,new THREE.CylinderGeometry(r,r,length,segments),mat,p);if(axis==='x')m.rotation.z=Math.PI/2;if(axis==='z')m.rotation.x=Math.PI/2;return m;};
 const bar=(g:THREE.Group,a:Point,b:Point,w:number,d:number,mat:THREE.Material)=>{const start=new THREE.Vector3(...a),end=new THREE.Vector3(...b),diff=end.clone().sub(start);const m=box(g,start.add(end).multiplyScalar(.5).toArray() as Point,[w,diff.length(),d],mat);m.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0),diff.normalize());return m;};
 const tube=(g:THREE.Group,points:Point[],radius:number,mat:THREE.Material,closed=false)=>{
  const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(...p)),closed,'centripetal');
  return solid(g,new THREE.TubeGeometry(curve,Math.max(12,points.length*5),radius,6,closed),mat);
 };
 const straightTube=(g:THREE.Group,points:Point[],radius:number,mat:THREE.Material,closed=false)=>{
  const path=new THREE.CurvePath<THREE.Vector3>();
  const vertices=points.map(p=>new THREE.Vector3(...p));if(closed)vertices.push(vertices[0]);
  for(let i=1;i<vertices.length;i++)path.add(new THREE.LineCurve3(vertices[i-1],vertices[i]));
  return solid(g,new THREE.TubeGeometry(path,Math.max(16,points.length*8),radius,6,closed),mat);
 };
 const plate=(g:THREE.Group,points:Point[],mat:THREE.Material)=>{const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(points.flat(),3));const indices=[];for(let i=1;i<points.length-1;i++)indices.push(0,i,i+1);geo.setIndex(indices);geo.computeVertexNormals();const m=solid(g,geo,mat);return m;};
 const world=(p:Point)=>freefallPoint(...p).toArray() as Point;
 function part(id:string,name:string,category:string,description:string,location:string,quantity:string,use:string,boat=true){
  const g=new THREE.Group();g.name=name;g.userData={sourceObjectId:`ff-${id}`,craft:'freefall',assembly:boat?'boat':'launch'};
  if(boat){g.position.copy(ORIGIN);g.rotation.x=FREEFALL_ANGLE;}
  root.add(g);
  equipment.push({id:`ff-${id}`,name,category,description,location,objects:[`ff-${id}`],source:'Added training equipment',
   identification:'Illustrative free-fall exterior. The arrangement and quantities describe this model; actual installations follow their approved drawings.',
   references:[boat?boatReference:launchReference],learning:{meaning:name,quantity,use,care:'Use the vessel-specific drawings and approved inspection instructions for the actual fitting.'}});
  return g;
 }
 function loft(g:THREE.Group,shape:(s:Section)=>[number,number][],mat:THREE.Material){
  const rings=sections.map(shape),n=rings[0].length,vertices:number[]=[],indices:number[]=[];
  for(let j=0;j<sections.length;j++)for(const [x,y] of rings[j])vertices.push(x,y,sections[j].z);
  for(let j=0;j<sections.length-1;j++)for(let i=0;i<n;i++){const a=j*n+i,b=j*n+(i+1)%n,c=(j+1)*n+(i+1)%n,d=(j+1)*n+i;indices.push(a,b,d,b,c,d);}
  for(let i=1;i<n-1;i++){indices.push(0,i+1,i);const a=(sections.length-1)*n;indices.push(a,a+i,a+i+1);}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);
  // UVs for subtle paint grain, not a large downloaded image.
  geo.setAttribute('uv',new THREE.Float32BufferAttribute(vertices.flatMap((_,i)=>i%3===0?[vertices[i]/3,vertices[i+2]/9]:[]),2));geo.computeVertexNormals();return solid(g,geo,mat);
 }
 const h=part('hull','Free-fall lifeboat hull','Structure','The buoyant lower shell has a fine bow and reinforced running surfaces for the skid-launch arrangement.','Lower orange body, beneath the canopy.','One hull.','Identify the bow, stern and hull-to-skid connection.');
 loft(h,s=>{const w=s.w,k=s.z>2.85?(s.z-2.85)*.45:0;return [[0,k],[w*.46,.06+k*.6],[w*.82,.25+k*.5],[w,.85+k*.25],[w,1.36],[-w,1.36],[-w,.85+k*.25],[-w*.82,.25+k*.5],[-w*.46,.06+k*.6]];},hull);
 const c=part('canopy','Enclosed canopy','Structure','The rigid upper enclosure shelters the occupants. Zoom close to see the fitted interior through the shell.','Orange superstructure above the hull.','One enclosed canopy.','Identify the enclosure and its closed access hatches.');
 const canopyMesh=loft(c,s=>{const t=Math.max(s.top,1.38),w=s.w;return [[w,1.36],[w*.98,1.36+(t-1.36)*.55],[w*.80,1.36+(t-1.36)*.9],[w*.45,t],[0,t+.04],[-w*.45,t],[-w*.80,1.36+(t-1.36)*.9],[-w*.98,1.36+(t-1.36)*.55],[-w,1.36]];},canopy);
 canopyMesh.geometry=openHelmRoof(canopyMesh.geometry);
 const seam=part('joint','Hull-to-canopy joint','Structure','A continuous joint connects the upper enclosure to the hull.','Along the perimeter at the base of the canopy.','One continuous perimeter joint.','Follow the seam around the boat to distinguish hull and canopy.');
 for(const sign of [-1,1])tube(seam,sections.map(s=>[sign*(s.w+.012),1.36,s.z] as Point),.035,dark);
 tube(seam,[[-1.12,1.36,-4],[0,1.36,-4.02],[1.12,1.36,-4]],.035,dark);
 const helm=part('wheelhouse','Raised steering shelter','Structure','The raised shelter provides outward visibility from the steering position.','Upper aft section of the canopy.','One steering shelter.','Locate the windows around the steering position.');
 const cabinGeometry=new THREE.BoxGeometry(1.6,.86,1.62);const cp=cabinGeometry.attributes.position;
 for(let i=0;i<cp.count;i++){const y=cp.getY(i);if(y>0){cp.setX(i,cp.getX(i)*.74);cp.setZ(i,cp.getZ(i)*.77);}}
 // A perimeter rim replaces the closed floor of the raised shelter.
 const roofIndices=[];for(let i=0;i<cabinGeometry.index!.count;i+=3){const tri=[0,1,2].map(j=>cabinGeometry.index!.getX(i+j));if(!tri.every(n=>cp.getY(n)<-.42))roofIndices.push(...tri);}cabinGeometry.setIndex(roofIndices);cabinGeometry.clearGroups();cabinGeometry.computeVertexNormals();
 for(const x of [-.8025,.8025])box(helm,[x,2.68,-2.68],[.145,.12,1.84],canopy);
 for(const z of [-3.545,-1.815])box(helm,[0,2.68,z],[1.46,.12,.11],canopy);
 solid(helm,cabinGeometry,canopy,[0,3.04,-2.68]);
 const windowMaterial=glass.clone();windowMaterial.side=THREE.DoubleSide;
 function windowPart(id:string,name:string,points:Point[]){const w=part(id,name,'Navigation','A sealed viewing pane provides visibility from the steering shelter.',`On the ${name.toLowerCase()} face of the raised steering shelter.`,'One viewing pane in this illustrated position.','Recognize the field of view from this window.');plate(w,points,windowMaterial);straightTube(w,points,.026,dark,true);}
 windowPart('front-window','Forward window',[[-.68,2.79,-1.900],[.68,2.79,-1.900],[.50,3.35,-2.019],[-.50,3.35,-2.019]]);
 windowPart('aft-window','Aft window',[[.68,2.79,-3.460],[-.68,2.79,-3.460],[-.50,3.35,-3.341],[.50,3.35,-3.341]]);
 for(const sign of [-1,1])windowPart(sign<0?'port-window':'starboard-window',sign<0?'Port window':'Starboard window',[[sign*.769,2.79,-3.32],[sign*.769,2.79,-2.04],[sign*.627,3.35,-2.14],[sign*.627,3.35,-3.22]]);
 const door=part('aft-door','Aft embarkation door','Structure','The main boarding door leads into the enclosed lifeboat from the embarkation platform.','At the stern, facing the upper boarding platform.','One aft boarding door.','Identify the boarding route and door securing fittings.');
 box(door,[0,1.84,-4.045],[.94,1.22,.075],dark);box(door,[0,1.84,-4.093],[.82,1.10,.055],hatchPaint);
 for(const y of [1.53,2.12]){cylinder(door,[-.45,y,-4.14],.035,.16,metal);bar(door,[.32,y,-4.14],[.47,y,-4.14],.035,.04,metal);}
 bar(door,[.24,1.76,-4.16],[.24,1.98,-4.16],.045,.055,metal);
 const hatch=part('front-hatch','Forward top hatch','Structure','A closed access hatch interrupts the forward canopy surface.','On top of the canopy, ahead of the steering shelter.','One forward top hatch.','Locate the hatch and its closure hardware.');
 const hatchBase=box(hatch,[0,2.565,.20],[.85,.085,.92],dark);hatchBase.rotation.x=.125;
 const hatchLid=box(hatch,[0,2.61,.20],[.77,.065,.84],hatchPaint);hatchLid.rotation.x=.125;
 for(const x of [-.26,.26])bar(hatch,[x,2.695,-.04],[x,2.695,.22],.035,.035,metal);
 const handrails=part('handrails','External handrails','Safety Equipment','Graspable rails provide handholds beside the exterior access areas.','Along the canopy sides and beside the aft door.','Two side rails and two aft door handholds in this model.','Identify secure handholds along the access route.');
 const surface=(z:number)=>{const i=Math.max(0,sections.findIndex(s=>s.z>=z)-1),a=sections[i],b=sections[i+1],t=(z-a.z)/(b.z-a.z);return {w:THREE.MathUtils.lerp(a.w,b.w,t),top:THREE.MathUtils.lerp(a.top,b.top,t)};};
 const sideX=(z:number,y:number)=>{const {w,top}=surface(z),v=(y-1.36)/(top-1.36);return w*(v<.55?THREE.MathUtils.lerp(1,.98,v/.55):v<.9?THREE.MathUtils.lerp(.98,.80,(v-.55)/.35):THREE.MathUtils.lerp(.80,.45,(v-.9)/.1));};
 for(const s of [-1,1]){
  const points:Point[]=[-3.25,-2.8,-1.3,.4].map(z=>{const y=1.36+(surface(z).top-1.36)*.65;return [s*(sideX(z,y)+.085),y,z];});
  tube(handrails,points,.028,metal);for(const [x,y,z] of points)bar(handrails,[x,y,z],[s*(sideX(z,y)+.006),y,z],.04,.04,metal);
  tube(handrails,[[s*.66,1.35,-4.16],[s*.66,1.53,-4.24],[s*.66,2.34,-4.24],[s*.66,2.48,-4.16]],.028,metal);
 }
 const reflect=part('reflectors','Retroreflective markings','Signaling','Reflective patches help an illuminated craft stand out against its surroundings.','White-silver patches along both canopy shoulders.','Five patches per side in this illustrative model.','Recognize the difference between reflective markings and powered lights.');
 root.updateMatrixWorld(true);
 const patchRay=new THREE.Raycaster();
 for(const s of [-1,1])for(const z of [-3.4,-1.9,-.5,.95,2.4]){
  const y=1.36+(surface(z).top-1.36)*.8;
  const vertices:number[]=[],indices:number[]=[];
  for(let row=0;row<=2;row++)for(let col=0;col<=4;col++){
   const py=y-.08+row*.08,pz=z-.16+col*.08;
   patchRay.set(freefallPoint(s*4,py,pz),new THREE.Vector3(-s,0,0));
   const hit=patchRay.intersectObject(c,true)[0];
   const p=hit?c.worldToLocal(hit.point.clone()):new THREE.Vector3(s*sideX(pz,py),py,pz);p.x+=s*.014;vertices.push(...p.toArray());
  }
  for(let row=0;row<2;row++)for(let col=0;col<4;col++){const a=row*5+col,b=a+1,d=a+5,e=d+1;indices.push(...(s>0?[a,d,b,b,d,e]:[a,b,d,b,e,d]));}
  const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(vertices,3));geo.setIndex(indices);geo.computeVertexNormals();solid(reflect,geo,white);
 }
 const light=part('light','External marking light','Signaling','A powered exterior light helps indicate the boat’s position.','On the roof of the steering shelter.','One illustrated light.','Locate the external light and distinguish it from the reflective patches.');
 cylinder(light,[0,3.53,-2.75],.11,.10,dark);cylinder(light,[0,3.65,-2.75],.077,.16,white);cylinder(light,[0,3.74,-2.75],.088,.025,metal);
 const bollards=part('bollards','Mooring and towing bollards','Structure','Strong deck fittings provide attachment points for the designated lines.','One at the bow and a pair near the stern.','Three illustrated bollards.','Identify the strong points specified for line handling.');
 for(const [x,y,z] of [[0,1.52,3.65],[-.92,1.47,-3.76],[.92,1.47,-3.76]]){box(bollards,[x,y,z],[.23,.05,.38],metal);cylinder(bollards,[x,y+.11,z],.054,.20,metal);cylinder(bollards,[x,y+.21,z],.038,.27,metal,'z');}
 const lifting=part('lifting','Recovery lifting point','Launching Equipment','A dedicated lifting connection is used with the approved recovery appliance.','On the reinforced roof area, ahead of the steering shelter.','One illustrated lifting connection.','Distinguish the recovery lifting point from the free-fall release hook.');
 box(lifting,[0,2.74,-.95],[.4,.09,.42],metal);const liftingEye=solid(lifting,new THREE.TorusGeometry(.115,.035,8,20),metal,[0,2.89,-.95]);liftingEye.rotation.y=Math.PI/2;
 const release=part('release-hook','Free-fall release hook','Launching Equipment','This restraining connection holds the boat on the inclined skid until its approved release system disengages.','Low on the stern, between the boat and launch structure.','One illustrated hook assembly.','Identify the release connection. Selecting it here only inspects the model.');
 box(release,[0,.78,-4.13],[.35,.42,.12],metal);const hook=solid(release,new THREE.TorusGeometry(.17,.065,8,20,Math.PI*1.65),metal,[0,.76,-4.29]);hook.rotation.y=Math.PI/2;hook.rotation.z=.5;cylinder(release,[0,.88,-4.31],.075,.48,red,'x');
 const runners=part('runners','Lifeboat skid runners','Launching Equipment','Paired running surfaces on the boat bear on the launch skidways.','Along the underside, aligned with the two launch rails.','Two boat-mounted runners.','Follow the boat-to-skid contact surfaces toward the bow.');
 for(const x of [-.79,.79]){box(runners,[x,.185,-.30],[.24,.13,7.4],metal);for(const z of [-3.3,-1.8,0,1.6,2.9])box(runners,[x,.32,z],[.23,.11,.38],hull);}
 const shoe=part('keel-shoe','Keel shoe','Structure','A protective fitting follows the lowest central part of the hull.','Under the centreline of the hull.','One illustrated keel shoe.','Identify the central keel protection separately from the two runners.');box(shoe,[0,-.014,-.50],[.16,.09,6.6],dark);
 const nozzle=part('nozzle','Propeller nozzle','Propulsion','The ring surrounds the propeller at the stern.','Beneath the aft hull, clear of the skid runners.','One nozzle.','Locate the propeller opening from behind the boat.');
 const nozzleMesh=solid(nozzle,new THREE.TorusGeometry(.39,.073,10,28),hatchPaint,[0,.29,-4.33]);box(nozzle,[0,.72,-4.20],[.12,.32,.21],metal);
 const prop=part('propeller','Propeller','Propulsion','The rotating blades produce thrust when driven by the propulsion system.','Inside the stern nozzle.','One three-bladed propeller in this model.','Inspect the blades inside the protective ring.');
 cylinder(prop,[0,.29,-4.35],.105,.26,bronze,'z');
 for(let i=0;i<3;i++){const blade=solid(prop,new THREE.SphereGeometry(1,12,8),bronze);blade.scale.set(.085,.245,.024);const a=i*Math.PI*2/3;blade.position.set(Math.sin(a)*.16,.29+Math.cos(a)*.16,-4.35);blade.rotation.z=-a;blade.rotation.y=.23;}
 const outlets=part('exhaust','Exhaust outlet','Propulsion','The exterior outlet is the final opening of the engine exhaust system.','On the stern, to starboard of the boarding door.','One illustrated exhaust outlet.','Locate the outlet without confusing it with a handhold or drain.');cylinder(outlets,[.85,1.0,-4.045],.095,.12,metal,'z');cylinder(outlets,[.85,1.0,-4.112],.065,.015,dark,'z');

 // Launch skid: support surfaces are coplanar with the underside runners.
 const rails=part('skid','Inclined launch skidways','Launching Equipment','The twin inclined rails guide the lifeboat toward the open end of the launch structure. Gravity carries the released boat down this path.','Below the two hull runners, sloping down toward the bow.','Two inclined skidway rails.','Trace the launch direction from the stern toward the clear, lower end.',false);
 rails.position.copy(ORIGIN);rails.rotation.x=FREEFALL_ANGLE;
 for(const x of [-.79,.79]){box(rails,[x,-.13,-.10],[.12,.40,9.7],steel);box(rails,[x,.092,-.10],[.37,.055,9.7],metal);box(rails,[x,-.34,-.10],[.39,.065,9.7],edgeSteel);}
 const cross=part('crossmembers','Skid cross-members','Launching Equipment','Transverse steel members connect the two launch rails.','Across the underside of the launch skid.','Seven transverse members.','Identify how the rails are tied together.',false);cross.position.copy(ORIGIN);cross.rotation.x=FREEFALL_ANGLE;
 for(const z of [-4.45,-3.1,-1.75,-.4,.95,2.3,3.65])box(cross,[0,-.36,z],[2.6,.18,.19],steel);
 const frame=part('frame','Launch support frame','Launching Equipment','The structural supports carry the inclined skid and transfer its loads to the foundation.','Vertical columns and longitudinal beams underneath the skidways.','Four main columns with two base beams.','Distinguish the stationary frame from the boat-mounted runners.',false);
 for(const x of [-1.21,1.21]){
  box(frame,[x,.26,-.58],[.28,.30,7.95],steel);
  for(const z of [-3.85,2.35]){const p=world([x,-.43,z]);bar(frame,[x,.37,p[2]],p,.24,.24,steel);box(frame,[x,.085,p[2]],[.78,.17,.86],edgeSteel);}
 }
 const braces=part('bracing','Support-frame bracing','Launching Equipment','Diagonal braces stiffen the launch support frame.','Between the columns and below the inclined rails.','Bracing on both sides and across the rear support.','Identify the triangular load paths.',false);
 for(const x of [-1.21,1.21]){const a=world([x,-.43,-3.85]),b=world([x,-.43,2.35]);bar(braces,[x,.42,a[2]],b,.13,.13,edgeSteel);bar(braces,[x,.42,b[2]],a,.13,.13,edgeSteel);}
 const rear=world([0,-.43,-3.85]);bar(braces,[-1.21,.45,rear[2]],[1.21,rear[1],rear[2]],.12,.12,edgeSteel);bar(braces,[1.21,.45,rear[2]],[-1.21,rear[1],rear[2]],.12,.12,edgeSteel);
 const bolts=part('anchors','Foundation anchor bolts','Launching Equipment','The foundation fasteners connect the support feet to the vessel’s structural foundation.','At the four support-frame footplates.','Four bolts per illustrated footplate.','Locate the fasteners at the base of the launch installation.',false);
 for(const x of [-1.21,1.21])for(const z of [-3.85,2.35]){const p=world([x,-.43,z]);for(const dx of [-.27,.27])for(const dz of [-.30,.30]){cylinder(bolts,[x+dx,.195,p[2]+dz],.035,.07,metal);cylinder(bolts,[x+dx,.215,p[2]+dz],.055,.04,metal,'y',6);}}
 const securing=part('securing-bar','Release-hook securing bar','Launching Equipment','The stationary securing bar provides the mating connection for the boat’s release hook.','Immediately behind the low stern release hook.','One illustrated bar and mounting bracket.','Compare this fixed fitting with the hook attached to the boat.',false);
 securing.position.copy(ORIGIN);securing.rotation.x=FREEFALL_ANGLE;
 cylinder(securing,[0,.77,-4.40],.063,.62,metal,'x');for(const x of [-.32,.32]){box(securing,[x,.32,-4.40],[.12,.90,.16],edgeSteel);box(securing,[x,-.16,-4.40],[.25,.10,.4],steel);}
 const boarding=world([0,1.16,-4.24]),deckY=boarding[1]-.05,deckZ=boarding[2]-.78;
 const platform=part('platform','Embarkation platform','Launching Equipment','An elevated landing provides access to the aft boarding door.','At the upper end of the ramp, immediately behind the boat.','One illustrated platform.','Follow the access route to the stern door.',false);
 box(platform,[0,deckY-.10,deckZ],[3.15,.17,1.60],steel);for(let i=0;i<16;i++)box(platform,[-1.48+i*.197,deckY,deckZ],[.055,.05,1.55],metal);
 for(const x of [-1.45,1.45]){bar(platform,[x,.14,deckZ-.60],[x,deckY-.12,deckZ-.60],.18,.18,steel);box(platform,[x,.07,deckZ-.60],[.48,.14,.5],edgeSteel);}
 const guard=part('guardrails','Embarkation guardrails','Safety Equipment','Rails border the raised embarkation platform while leaving its access points open.','Around the exposed sides of the upper platform.','One platform guardrail arrangement.','Locate the protected approach to the boarding door.',false);
 for(const x of [-1.52,1.52]){for(const z of [deckZ-.75,deckZ,deckZ+.75])cylinder(guard,[x,deckY+.52,z],.026,1.04,metal);for(const y of [.52,1.04])tube(guard,[[x,deckY+y,deckZ-.75],[x,deckY+y,deckZ+.75]],.026,metal);}
 for(const x of [-1.52,.10])cylinder(guard,[x,deckY+.52,deckZ-.76],.026,1.04,metal);for(const y of [.52,1.04])tube(guard,[[-1.52,deckY+y,deckZ-.76],[.10,deckY+y,deckZ-.76]],.026,metal);
 const access=part('ladder','Embarkation access ladder','Launching Equipment','A fixed ladder provides the illustrated approach to the elevated boarding platform.','At the rear of the embarkation platform.','One fixed access ladder.','Identify the route from the base to the platform.',false);
 const ladderZ=deckZ-.88;for(const x of [.23,1.22])bar(access,[x,.22,ladderZ-.80],[x,deckY+1.02,ladderZ],.06,.06,metal);
 const steps=Math.ceil(deckY/.32);for(let i=1;i<=steps;i++){const y=i*deckY/steps,z=ladderZ-.80*(1-y/(deckY+1.02));bar(access,[.23,y,z],[1.22,y,z],.06,.09,metal);}
 const gantry=part('recovery-frame','Recovery davit frame','Launching Equipment','The overhead recovery structure supports the hoisting system used to return the boat to its stowed position.','Above and outside the boat, attached to the main launch frame.','One illustrated recovery frame.','Distinguish the recovery appliance from the gravity-launch skid.',false);
 const gantryTop=world([0,3.8,-1.7]);gantryTop[1]+=1.35;
 for(const x of [-1.95,1.95]){const foot=world([x,-.35,-3.35]);bar(gantry,foot,[x,gantryTop[1],gantryTop[2]],.23,.31,steel);bar(gantry,[x,deckY-.45,deckZ+.6],foot,.16,.18,edgeSteel);cylinder(gantry,foot,.20,.34,metal,'x');}
 bar(gantry,[-1.95,gantryTop[1],gantryTop[2]],[1.95,gantryTop[1],gantryTop[2]],.27,.30,steel);
 const winch=part('winch','Recovery winch','Launching Equipment','The winch winds the recovery wire. It belongs to the hoisting system, not the boat’s gravity-driven free-fall motion.','On a bracket outside the port side of the recovery frame.','One illustrated winch.','Locate the cable drum and drive housing.',false);
 const winchPoint=world([-2.12,.15,-3.2]);box(winch,[winchPoint[0],winchPoint[1]-.14,winchPoint[2]],[1.0,.13,.8],steel);cylinder(winch,winchPoint,.24,.48,dark,'x',24);
 for(const dx of [-.26,.26])cylinder(winch,[winchPoint[0]+dx,winchPoint[1],winchPoint[2]],.32,.055,metal,'x',24);
 for(let i=0;i<12;i++){const winding=solid(winch,new THREE.TorusGeometry(.245,.010,5,24),metal,[winchPoint[0]-.21+i*.038,winchPoint[1],winchPoint[2]]);winding.rotation.y=Math.PI/2;}
 cylinder(winch,[winchPoint[0]-.52,winchPoint[1],winchPoint[2]],.19,.35,steel,'x');cylinder(winch,[winchPoint[0]-.72,winchPoint[1],winchPoint[2]],.16,.025,red,'x');
 const sheaves=part('sheaves','Recovery wire sheaves','Launching Equipment','Grooved wheels change the direction of the recovery wire.','At the head of the recovery frame.','Two illustrated sheaves.','Trace the recovery-wire path across the frame.',false);
 for(const x of [-1.85,0]){cylinder(sheaves,[x,gantryTop[1],gantryTop[2]],.19,.09,metal,'z',24);cylinder(sheaves,[x,gantryTop[1],gantryTop[2]-.06],.055,.15,dark,'z');}
 const wire=part('recovery-wire','Recovery wire and parked hook','Launching Equipment','The hoisting wire ends in a recovery hook, shown parked clear of the boat.','From the winch over the overhead sheaves to the parked hook.','One illustrated recovery-wire assembly.','Follow its route; the parked hook is separate from the free-fall restraining connection.',false);
 const hookY=gantryTop[1]-1.05;const hookZ=gantryTop[2]-.15;
 straightTube(wire,[winchPoint,[-1.97,gantryTop[1]+.12,hookZ],[-1.85,gantryTop[1]+.19,hookZ],[0,gantryTop[1]+.19,hookZ],[.13,gantryTop[1]+.12,hookZ],[.19,gantryTop[1],hookZ],[.19,hookY,hookZ]],.014,metal);
 cylinder(wire,[.19,hookY-.08,hookZ],.08,.19,metal);const recoverHook=solid(wire,new THREE.TorusGeometry(.13,.04,8,20,Math.PI*1.7),metal,[.19,hookY-.28,hookZ]);recoverHook.rotation.z=.5;
 root.updateMatrixWorld(true);
 const boatBounds=new THREE.Box3();for(const node of root.children)if(node.userData.assembly==='boat')boatBounds.expandByObject(node);
 const boatPose=new THREE.Matrix4().compose(ORIGIN,new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(1,0,0),FREEFALL_ANGLE),new THREE.Vector3(1,1,1));
 const interior=buildFreefallInterior(boatPose);
 root.add(...[...interior.root.children]);equipment.push(...interior.equipment);
 root.updateMatrixWorld(true);
 return {root,equipment,boatBounds,boatCenter:boatBounds.getCenter(new THREE.Vector3()),boatPose,seats:interior.seats,
  interiorView:{target:freefallPoint(0,1.3,-.25),position:freefallPoint(-4.3,5.4,3.3)}};
}
