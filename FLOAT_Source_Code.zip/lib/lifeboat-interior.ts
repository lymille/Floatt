import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import {fitTrainingInterior} from './lifeboat-fitting';
import {parts} from './curriculum';
export type Equipment={id:string;name:string;partId?:string;description:string;location:string;source:'Reference model'|'Added training equipment';objects:string[];stowage?:{id:string;name:string}};
const pid=(n:number)=>`part-${String(n).padStart(2,'0')}`;
export const shellIds=new Set(['NODE248','NODE250','NODE260','NODE256','NODE254','NODE252','NODE258','NODE244','NODE246']);
export const referenceEquipment:Equipment[]=[
 {id:'hull',name:'Lifeboat Hull',partId:pid(1),objects:['NODE250'],location:'Outer body below the deck'},
 {id:'canopy',name:'Enclosed Canopy',partId:pid(2),objects:['NODE260','NODE256'],location:'Main enclosure and raised steering shelter'},
 {id:'windows',name:'Steering Shelter Windows',partId:pid(6),objects:['NODE254'],location:'Raised steering shelter'},
 {id:'deck-shell',name:'Deck and Gunwale',partId:pid(7),objects:['NODE248'],location:'Upper edge of the hull'},
 {id:'access-hatches',name:'Access Hatches and Frames',partId:pid(5),objects:['NODE252','NODE258','NODE244','NODE246'],location:'Aft and side entrances'},
 {id:'propeller',name:'Propeller',partId:pid(11),objects:['NODE4'],location:'Below the aft end of the hull'},
 {id:'handhold',name:'Entrance Handhold',partId:pid(4),objects:['NODE238'],location:'Aft entrance'}
].map(x=>({...x,source:'Reference model' as const,description:parts.find(p=>p.id===x.partId)?.purpose||''}));
export const interiorEquipment:Equipment[]=[];
const C={ivory:0xe5e9df,seat:0x576879,metal:0xaab7bf,dark:0x253341,orange:0xf58327,red:0xd83d35,green:0x258763,blue:0x317db6,yellow:0xf4cf57};
// This fitted learning arrangement is illustrative; it is not a manufacturer's as-built drawing.
// Original coordinates: Y is up, X crosses the boat, Z runs from aft (-Z) to bow (+Z).
export function buildInterior(){
 interiorEquipment.length=0;
 const root=new THREE.Group();root.name='Fitted training interior';const cx=-.626;
 function group(id:string,n:number|undefined,name:string,location:string,description?:string){const g=new THREE.Group();g.name=id;g.userData.sourceObjectId=id;g.userData.interior=true;root.add(g);const p=parts.find(p=>p.id===pid(n||0));interiorEquipment.push({id,name,partId:n?pid(n):undefined,description:description||p?.purpose||'',location,source:'Added training equipment',objects:[id]});return g;}
 function mesh(g:THREE.Group,geo:THREE.BufferGeometry,c:number,p:number[],rot?:number[]){const m=new THREE.Mesh(geo,new THREE.MeshStandardMaterial({color:c,roughness:c===C.metal?.33:.72,metalness:c===C.metal?.65:.05}));m.position.set(p[0]+cx,p[1],p[2]);if(rot)m.rotation.set(rot[0],rot[1],rot[2]);g.add(m);return m;}
 function box(g:THREE.Group,p:number[],s:number[],c=C.ivory){return mesh(g,new RoundedBoxGeometry(s[0],s[1],s[2],2,Math.min(...s)*.12),c,p)}
 function cyl(g:THREE.Group,p:number[],r:number,h:number,c:number,rot?:number[]){return mesh(g,new THREE.CylinderGeometry(r,r,h,24),c,p,rot)}
 function tube(g:THREE.Group,ps:number[][],r:number,c:number){const curve=new THREE.CatmullRomCurve3(ps.map(p=>new THREE.Vector3(p[0]+cx,p[1],p[2])));const m=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(12,ps.length*6),r,8,false),new THREE.MeshStandardMaterial({color:c,metalness:.35,roughness:.5}));g.add(m);return m;}
 function ring(g:THREE.Group,p:number[],r:number,t:number,c:number,rot?:number[]){return mesh(g,new THREE.TorusGeometry(r,t,10,36),c,p,rot)}
 function caseBox(g:THREE.Group,p:number[],s:number[],c:number){box(g,p,s,c);for(const x of [-1,1])box(g,[p[0]+x*s[0]*.3,p[1]+s[1]*.53,p[2]],[.04,.035,s[2]*.9],C.dark);box(g,[p[0],p[1]+s[1]*.6,p[2]],[s[0]*.28,.05,.06],C.metal);}
 let g=group('interior-floor',7,'Interior Floor','Central walking area');box(g,[0,4.22,5.75],[2.45,.12,6.65]);box(g,[0,4.22,1.62],[1.9,.12,1.62]);
 g=group('non-slip',37,'Non-slip Walkway','Central aisle');for(let z=2.9;z<8.7;z+=.18)box(g,[0,4.291,z],[.76,.012,.065],C.dark);
 g=group('benches',3,'Seats / Benches','Both sides of the central aisle');
 for(const side of [-1,1])for(let z=2.8;z<8.7;z+=.65){box(g,[side*.99,4.62,z],[.61,.12,.58]);box(g,[side*1.26,4.96,z],[.08,.62,.58],C.seat);for(const dz of [-.2,.2])box(g,[side*.99,4.44,z+dz],[.08,.32,.065],C.metal);box(g,[side*.96,4.695,z],[.53,.025,.48],C.seat);}
 g=group('harnesses',33,'Seat Belts / Harnesses','At each passenger seat');for(const side of [-1,1])for(let z=2.8;z<8.7;z+=.65){box(g,[side*.94,4.727,z],[.62,.025,.055],C.dark);box(g,[side*.85,4.751,z],[.095,.032,.082],C.metal);tube(g,[[side*1.2,5.19,z-.16],[side*.94,4.8,z],[side*.72,4.73,z+.18]],.024,C.dark);}
 g=group('interior-rails',4,'Interior Handrails','Along the seating and overhead');for(const side of [-1,1]){tube(g,[[side*.6,4.3,3],[side*.6,5.75,3],[side*.6,5.75,8.1],[side*.6,4.3,8.1]],.035,C.metal);}
 g=group('helm-seat',3,'Helmsman’s Seat','Raised aft steering position');box(g,[0,5.24,1.35],[.68,.15,.6],C.seat);box(g,[0,5.6,1.03],[.68,.64,.12],C.seat);cyl(g,[0,4.74,1.35],.1,.85,C.metal);
 g=group('helm-console',undefined,'Steering Console','Aft steering position','Houses steering instruments and controls.');box(g,[0,5.63,2.04],[1.4,.63,.46],C.ivory);box(g,[0,5.97,2.04],[1.35,.055,.49],C.dark);
 g=group('steering-wheel',19,'Steering Wheel','At the steering console');ring(g,[0,5.87,1.76],.25,.026,C.dark);cyl(g,[0,5.87,1.8],.064,.15,C.metal,[Math.PI/2,0,0]);for(let a=0;a<Math.PI*2;a+=Math.PI*2/3)tube(g,[[0,5.87,1.75],[Math.sin(a)*.23,5.87+Math.cos(a)*.23,1.75]],.018,C.metal);
 g=group('compass',18,'Magnetic Compass','Top of the steering console');cyl(g,[-.46,6.08,2.05],.14,.16,C.dark);cyl(g,[-.46,6.17,2.05],.12,.02,C.ivory);box(g,[-.46,6.19,2.05],[.025,.018,.17],C.red);
 g=group('throttle',17,'Throttle / Gear Control','Beside the steering wheel');box(g,[.48,6.01,1.94],[.2,.12,.22],C.metal);tube(g,[[.48,6.04,1.94],[.48,6.32,1.84]],.022,C.metal);mesh(g,new THREE.SphereGeometry(.06,16,12),C.red,[.48,6.32,1.84]);
 g=group('engine',10,'Diesel Engine','Under the aft seating platform, shown exposed for study');box(g,[0,3.65,1.72],[.74,.54,1.12],0x3d796f);box(g,[0,3.98,1.72],[.66,.18,.93],C.dark);for(let z=1.35;z<2.2;z+=.23){cyl(g,[.39,3.81,z],.085,.18,C.metal,[0,0,Math.PI/2]);tube(g,[[.22,3.93,z],[.38,4.04,z],[.49,3.75,z]],.018,C.metal);}cyl(g,[0,3.63,1.1],.26,.17,C.dark,[Math.PI/2,0,0]);
 g=group('shaft',12,'Propeller Shaft','Aft of the engine');tube(g,[[0,3.5,1.22],[0,2.66,-.65]],.045,C.metal);
 g=group('fuel',13,'Fuel Tank','Below the aft deck, beside the engine');caseBox(g,[-.88,3.66,1.8],[.55,.5,.93],C.metal);cyl(g,[-.88,3.96,1.5],.065,.09,C.dark);
 g=group('batteries',14,'Starting Batteries','Secured below the aft deck');for(const z of [2.4,2.83]){caseBox(g,[.84,3.59,z],[.48,.36,.34],C.dark);cyl(g,[.73,3.8,z],.022,.05,C.red);cyl(g,[.96,3.8,z],.022,.05,C.metal);}
 g=group('cooling',15,'Engine Cooling System','Alongside the engine');cyl(g,[.51,3.8,1.75],.085,.8,C.metal,[Math.PI/2,0,0]);tube(g,[[.51,3.8,2.13],[.6,3.47,2.13],[.2,3.4,1.8]],.035,C.dark);
 g=group('exhaust',16,'Engine Exhaust','From the engine toward the aft outlet');tube(g,[[-.4,3.9,1.5],[-.54,3.9,.9],[-.75,4.12,.5],[-.75,4.4,-.28]],.07,C.metal);
 g=group('bilge',58,'Manual Bilge Pump','Aft end of the central aisle');cyl(g,[.62,4.45,2.37],.11,.3,C.dark);tube(g,[[.62,4.59,2.37],[.62,4.88,2.37],[.83,4.88,2.37]],.025,C.metal);tube(g,[[.64,4.31,2.37],[.72,3.66,2.37]],.027,C.dark);
 g=group('lockers',48,'Equipment Lockers','Secured storage along the central platform');for(const z of [4.1,5.4,6.7]){caseBox(g,[0,4.64,z],[.8,.58,1.02],C.ivory);box(g,[0,4.98,z],[.8,.03,1.03],C.metal);}
 g=group('first-aid',34,'First-aid Kit','On the forward equipment locker');caseBox(g,[0,5.12,6.68],[.53,.24,.37],C.green);box(g,[0,5.248,6.68],[.27,.013,.065],0xffffff);box(g,[0,5.249,6.68],[.07,.014,.23],0xffffff);
 g=group('extinguisher',35,'Fire Extinguisher','Beside the forward aisle');cyl(g,[-.5,4.7,7.6],.115,.54,C.red);mesh(g,new THREE.SphereGeometry(.11,20,12),C.red,[-.5,4.98,7.6]);box(g,[-.5,5.08,7.6],[.16,.035,.075],C.dark);tube(g,[[-.43,5.03,7.6],[-.3,4.97,7.6],[-.31,4.48,7.6]],.02,C.dark);box(g,[-.5,4.68,7.48],[.13,.23,.012],C.ivory);
 g=group('water',39,'Drinking Water Containers','Forward stores');for(const x of [-.63,0,.63]){caseBox(g,[x,4.59,8.55],[.42,.53,.34],0xe9dfbb);cyl(g,[x+.1,4.91,8.55],.05,.08,C.blue);}
 g=group('rations',40,'Food Rations','Under the seats');for(const x of [-1,1])for(const z of [5.1,5.75,6.4])caseBox(g,[x,4.4,z],[.43,.2,.48],C.orange);
 g=group('vhf',20,'Portable VHF Radio','Steering console');caseBox(g,[-.52,6.2,1.8],[.16,.29,.08],C.dark);box(g,[-.52,6.25,1.75],[.115,.09,.01],C.blue);tube(g,[[-.56,6.35,1.8],[-.56,6.59,1.8]],.008,C.dark);
 g=group('epirb',21,'EPIRB','Transfer equipment rack near the aft entrance');cyl(g,[-.93,5.14,.92],.11,.3,C.yellow);cyl(g,[-.93,5.32,.92],.08,.07,C.orange);tube(g,[[-.93,5.36,.92],[-.93,5.65,.92]],.012,C.dark);
 box(g,[-.93,4.97,.96],[.29,.06,.24],C.metal);tube(g,[[-1.14,4.3,.96],[-1.14,5.1,.96]],.025,C.metal);
 g=group('sart',22,'Search and Rescue Transponder (SART)','Transfer equipment rack near the aft entrance');cyl(g,[.95,5.14,.92],.075,.45,C.orange);cyl(g,[.95,5.4,.92],.055,.06,C.dark);
 box(g,[.95,4.9,.96],[.22,.06,.22],C.metal);tube(g,[[1.14,4.3,.96],[1.14,5.1,.96]],.025,C.metal);
 g=group('lifejackets',30,'Lifejackets','Personal equipment stowage beneath seats');for(const z of [3.25,3.9])for(const x of [-1,1]){box(g,[x-.12,4.44,z],[.18,.23,.34],C.orange);box(g,[x+.12,4.44,z],[.18,.23,.34],C.orange);box(g,[x,4.44,z-.17],[.38,.23,.08],C.orange);}
 const packs:[string,number,string,number,number,number][]=[['immersion-suit',31,'Immersion Suit',-1,7.1,C.red],['tpa',32,'Thermal Protective Aids',1,7.1,C.metal],['seasickness',44,'Seasickness Supplies',-.24,5.4,C.blue],['fishing',43,'Fishing Tackle',.24,5.4,C.green]];
 for(const [id,n,name,x,z,c] of packs){g=group(id,n,name,'Secured survival stores');caseBox(g,[x,x===-1||x===1?4.4:5.11,z],[.32,.2,.32],c);}
 g=group('pyro-locker',undefined,'Distress Signal Storage Box','Central storage platform','Protective storage for pyrotechnic distress signals.');caseBox(g,[0,5.14,4.1],[.64,.27,.65],C.orange);
 for(const [id,n,name,x,r,h,c] of [['rocket',23,'Rocket Parachute Flare',-.2,.034,.4,C.red],['hand-flare',24,'Hand Flare',0,.03,.32,C.red],['smoke',25,'Buoyant Smoke Signal',.2,.07,.15,C.orange]] as [string,number,string,number,number,number,number][]){g=group(id,n,name,'Distress signal storage, displayed for identification');cyl(g,[x,5.32+h/2,4.1],r,h,c);cyl(g,[x,5.33+h,4.1],r,.025,C.dark);}
 g=group('torch',28,'Waterproof Torch','Central locker lid');cyl(g,[.23,5.06,6.2],.04,.25,C.yellow,[Math.PI/2,0,0]);cyl(g,[.23,5.06,6.04],.06,.05,C.metal,[Math.PI/2,0,0]);
 g=group('mirror',26,'Signal Mirror','Central locker lid');box(g,[-.2,5.01,6.13],[.17,.015,.12],C.metal);
 g=group('whistle',27,'Whistle','Central locker lid');box(g,[-.2,5.03,6.3],[.08,.04,.035],C.orange);
 g=group('cup',41,'Graduated Drinking Vessel','Forward stores');cyl(g,[.44,4.45,8.06],.075,.22,C.metal);ring(g,[.53,4.48,8.06],.055,.009,C.metal,[0,Math.PI/2,0]);
 g=group('manual',46,'Survival Manual','Central locker lid');box(g,[-.17,5.02,7.02],[.27,.035,.33],C.blue);box(g,[-.17,5.044,7.02],[.2,.006,.08],C.ivory);
 g=group('can-opener',45,'Tin Opener — One','Central locker lid');box(g,[.24,5.035,7.04],[.04,.028,.19],C.metal);ring(g,[.24,5.05,6.94],.035,.008,C.metal,[Math.PI/2,0,0]);
 g=group('sea-anchor',47,'Sea Anchor and Line','Forward floor stowage');mesh(g,new THREE.ConeGeometry(.25,.5,24,1,true),C.orange,[-.6,4.56,8.05],[0,0,Math.PI/2]);for(let i=0;i<5;i++)ring(g,[-.6,4.31+i*.025,8.4],.23,.015,0xbba982,[Math.PI/2,0,0]);
 g=group('bucket',59,'Bucket — Forward','Forward aisle');mesh(g,new THREE.CylinderGeometry(.18,.14,.29,24,1,true),C.orange,[.02,4.43,7.8]);ring(g,[.02,4.63,7.8],.17,.01,C.metal);
 g=group('tiller',60,'Emergency Tiller','Secured along the aft side');tube(g,[[.93,4.86,1.4],[.93,4.86,2.1],[.74,4.86,2.3]],.035,C.metal);
 g=group('quoit',61,'Rescue Quoit and Line — Forward','Near the forward entrance');ring(g,[.5,4.79,8.85],.22,.04,C.orange);for(let i=0;i<5;i++)ring(g,[.5,4.31+i*.025,8.75],.17,.013,0xc8bd9d,[Math.PI/2,0,0]);
 g=group('instructions',38,'Safety Instructions','Near the steering position');box(g,[-1.2,5.45,2.2],[.025,.4,.35],C.ivory);for(let y=5.33;y<5.6;y+=.06)box(g,[-1.184,y,2.2],[.01,.014,.26],C.green);
 g=group('oars',undefined,'Oars','Secured beneath side benches','Manual means of propulsion where provided.');for(const z of [4.3,4.48]){tube(g,[[1.1,4.34,z-1.2],[1.1,4.34,z+1]],.025,0xb48a50);box(g,[1.1,4.34,z+1.1],[.16,.04,.5],0xb48a50);}
 g=group('boat-hook',undefined,'Boat Hook — Port','Alongside the seats','A pole with a hook used to reach or handle lines and nearby objects.');tube(g,[[-1.17,4.37,5.4],[-1.17,4.37,7.3],[-1.17,4.49,7.4],[-1.17,4.54,7.32]],.018,C.metal);
 g=group('tool-kit',undefined,'Engine Tool Kit','Beside the engine access area','Tools for the engine and minor adjustments, according to the craft’s instructions.');caseBox(g,[.73,4.43,2.96],[.4,.23,.34],C.blue);
 g=group('hatchet',undefined,'Hatchet — Aft','Near the entrance','Cutting tool carried as part of the craft’s equipment.');box(g,[-1.04,4.97,2.15],[.04,.45,.035],0xb48a50);box(g,[-1.04,5.18,2.15],[.2,.11,.04],C.metal);
 g=group('rain-collector',42,'Rainwater Collection Sheet','Folded in forward stores');box(g,[.75,4.45,7.65],[.36,.09,.43],C.blue);
 g=group('vent',36,'Ventilation Duct','Inside the enclosure near the steering position');cyl(g,[1.14,5.47,2.54],.1,.45,C.ivory);for(let y=5.29;y<5.63;y+=.07)box(g,[1.14,y,2.43],[.13,.025,.02],C.dark);
 g=group('drain',9,'Drain Valve','Lowest accessible aft bilge area');cyl(g,[0,3.16,.1],.065,.1,C.metal);box(g,[0,3.23,.1],[.19,.025,.03],C.red);
 g=group('buoyancy',8,'Buoyancy Chambers','Under the side seating');for(const x of [-.96,.96])box(g,[x,3.97,5.6],[.54,.26,5.7],C.ivory);
 // Supplementary equipment identified in the supplied video. Separate IDs retain click targets.
 for(const [id,name,x] of [['painter','Forward Painter',-.5],['spare-painter','Second Painter',.5]] as const){g=group(id,56,name,'Secured at the bow; line shown coiled for stowage','A strong line used to control the boat relative to the ship or another craft.');for(let i=0;i<5;i++)ring(g,[x,4.35+i*.027,9.2],.22,.014,0xc9b995,[Math.PI/2,0,0]);tube(g,[[x,4.46,9.2],[x,4.6,9.7],[x,5.02,9.8]],.017,0xc9b995);}
 g=group('painter-release',56,'Painter Securing / Release Fitting','Forward interior beside the bow line','Secures the designated painter; release arrangement is craft-specific.');box(g,[-.5,5.02,9.8],[.25,.12,.18],C.metal);box(g,[-.5,5.12,9.8],[.19,.025,.04],C.red);
 g=group('radar-reflector',undefined,'Radar Reflector','Shown erected above the forward canopy; fold and secure in signal stores when stowed','A passive reflector that increases the craft’s radar return.');g.userData.interior=false;tube(g,[[.45,6.3,7.8],[.45,7.45,7.8]],.022,C.metal);box(g,[.45,7.4,7.8],[.48,.48,.018],C.metal);box(g,[.45,7.4,7.8],[.018,.48,.48],C.metal);box(g,[.45,7.4,7.8],[.48,.018,.48],C.metal);
 g=group('searchlight',29,'Searchlight','Outside the raised steering shelter','An aimable lamp for finding survivors and attracting attention.');g.userData.interior=false;box(g,[.52,7.43,1.8],[.24,.1,.25],C.dark);cyl(g,[.52,7.64,1.8],.16,.29,C.dark,[Math.PI/2,0,0]);cyl(g,[.52,7.64,1.96],.145,.015,C.ivory,[Math.PI/2,0,0]);
 g=group('torch-spares',28,'Torch Spare Batteries and Bulb','Waterproof box beside the torch','Replacement power and lamp components for the signaling torch.');caseBox(g,[.28,5.09,6.63],[.22,.18,.28],C.yellow);
 g=group('jackknife',undefined,'Jackknife with Lanyard','Tool stowage on the central locker','A folding utility knife tethered to the boat.');box(g,[.21,5.035,5.88],[.045,.035,.22],C.red);tube(g,[[.21,5.05,5.77],[.34,5.05,5.68],[.36,5.01,5.55]],.006,0xc9b995);
 g=group('rescue-signals',38,'Life-saving Signals Card','Beside the helmsman’s instructions','A waterproof reference for recognized rescue communications.');box(g,[-1.19,5.46,2.64],[.02,.32,.26],C.yellow);for(let y=5.36;y<5.59;y+=.06)box(g,[-1.176,y,2.64],[.01,.014,.18],C.dark);
 g=group('dipper',41,'Rustproof Dipper with Lanyard','Secured beside the drinking-water containers','A small ladle for transferring drinking water without putting hands into the supply.');mesh(g,new THREE.CylinderGeometry(.08,.065,.09,16,1,true),C.metal,[.6,4.4,8.9]);tube(g,[[.6,4.44,8.9],[.82,4.44,8.9]],.013,C.metal);tube(g,[[.82,4.44,8.9],[.86,4.35,8.8],[.75,4.35,8.6]],.006,0xc9b995);
 g=group('bailer',59,'Buoyant Bailer','Forward floor beside the buckets','A hand scoop for removing water from the bottom of the boat.');box(g,[-.25,4.31,7.6],[.18,.02,.25],C.orange);for(const x of [-.33,-.17])box(g,[x,4.37,7.6],[.02,.12,.25],C.orange);box(g,[-.25,4.37,7.715],[.18,.12,.02],C.orange);box(g,[-.25,4.42,7.82],[.055,.055,.2],C.orange);
 g=group('second-bucket',59,'Bucket — Aft','Aft aisle beside the bilge pump','A container for collecting and lifting unwanted water out of the craft.');mesh(g,new THREE.CylinderGeometry(.17,.13,.28,16,1,true),C.orange,[.65,4.44,3.4]);ring(g,[.65,4.65,3.4],.16,.01,C.metal);
 g=group('second-quoit',61,'Rescue Quoit and Line — Aft','Beside the aft entrance','A buoyant throwing ring attached to a rescue line.');ring(g,[-.94,4.82,.55],.2,.035,C.orange);for(let i=0;i<4;i++)ring(g,[-.94,4.34+i*.025,.55],.17,.013,0xc8bd9d,[Math.PI/2,0,0]);
 g=group('second-boat-hook',undefined,'Boat Hook — Starboard','Along the starboard seats, accessible for fending off','A reach pole with a shaped hook for controlled handling of nearby lines and objects.');tube(g,[[1.17,4.39,5.4],[1.17,4.39,7.3],[1.17,4.51,7.4],[1.17,4.56,7.32]],.018,C.metal);
 g=group('forward-hatchet',undefined,'Hatchet — Forward','Secured at the forward end','A short-handled cutting tool for emergencies.');box(g,[.95,4.85,9.1],[.04,.45,.035],0xb48a50);box(g,[.95,5.06,9.1],[.2,.11,.04],C.metal);
 for(const [id,name,x] of [['can-opener-2','Tin Opener — Two',.1],['can-opener-3','Tin Opener — Three',-.04]] as const){g=group(id,45,name,'Food utensil tray on the central locker','A manual tool for opening sealed food tins.');box(g,[x,5.035,7.04],[.04,.028,.19],C.metal);ring(g,[x,5.05,6.94],.035,.008,C.metal,[Math.PI/2,0,0]);}
 g=group('seasickness-bags',44,'Seasickness Bags','Packet in the medical / survival locker','Individual bags for containing vomit and keeping the seating area clean.');for(let i=0;i<3;i++)box(g,[-.23,5.01+i*.017,5.03],[.22,.013,.24],0xded7bb);
 g=group('air-horn',27,'Handheld Air Horn — Optional','Signal stores beside the steering position','A compressed-gas sound signal, shown as an optional supplement to the whistle.');cyl(g,[.58,5.19,2.45],.055,.19,C.orange);mesh(g,new THREE.ConeGeometry(.085,.17,16,1,true),C.red,[.58,5.33,2.49],[Math.PI/2,0,0]);
 g=group('solar-still',42,'Solar Still — Optional','Folded example in forward survival stores','Uses solar energy to evaporate water and collect condensed fresh water. Not a universal lifeboat fitting.');caseBox(g,[-.86,4.42,7.65],[.34,.16,.34],C.blue);
 g=group('desalinator',42,'Manual Reverse-osmosis Desalinator','Forward survival stores, where fitted','A hand-powered membrane device for producing fresh water from seawater.');cyl(g,[.8,4.48,8.16],.07,.36,C.blue,[Math.PI/2,0,0]);tube(g,[[.8,4.5,8],[.8,4.73,8],[.95,4.73,8]],.015,C.metal);tube(g,[[.8,4.44,8.3],[.97,4.34,8.45],[.75,4.34,8.5]],.011,C.dark);
 g=group('oarlocks',undefined,'Oar Crutches / Rowlocks','Stowed with the oars; used at the approved rowing positions','Supports that hold oars while allowing them to pivot.');for(const z of [4.3,4.6]){tube(g,[[1.12,4.39,z],[1.12,4.52,z]],.015,C.metal);ring(g,[1.12,4.57,z],.055,.012,C.metal);}
 g=group('cabin-lights',undefined,'Interior Lights','Above the central aisle','Provide light for reading instructions and finding equipment.');for(const z of [3.3,6.7])box(g,[0,5.92,z],[.32,.045,.12],C.ivory);
 g=group('position-light',undefined,'Exterior Lifeboat Light','Above the canopy','A white lamp that helps rescuers see the lifeboat.');g.userData.interior=false;tube(g,[[-.3,6.45,6.8],[-.3,6.75,6.8]],.025,C.metal);cyl(g,[-.3,6.75,6.8],.09,.1,C.dark);cyl(g,[-.3,6.88,6.8],.07,.16,C.ivory);
 // Display the entire fixed pyrotechnic complement without additional label clutter.
 for(const [id,count,spacing] of [['rocket',4,.075],['hand-flare',6,.067],['smoke',2,.15]] as const){const equipmentGroup=root.children.find(o=>o.userData.sourceObjectId===id)!;const examples=[...equipmentGroup.children];for(let i=1;i<count;i++)for(const example of examples){const duplicate=example.clone();duplicate.position.z+=i*spacing;equipmentGroup.add(duplicate);}}
 fitTrainingInterior(root,interiorEquipment);
 root.updateMatrixWorld(true);return {root,equipment:[...interiorEquipment]};
}
// Distance to the boat itself, not to the camera's orbit target or the davit.
export function closeViewOpacity(distance:number){const t=Math.max(0,Math.min(1,(distance-.6)/4));return .045+.955*t*t*(3-2*t);}
