import {parts} from './curriculum';
import freefall from './practice-freefall.json';
// Keep the original 35-question forms and IDs stable for saved results.
// New post-tests cover 61 davit components plus 9 free-fall topics. Keys stay private.
const pairs:[number,string,string][]=[
[1,'Which part forms the watertight body that keeps a lifeboat afloat?','A learner points to the craft’s main floating body below the canopy. Which part is it?'],
[2,'Which structure primarily shelters occupants from weather and sea spray?','Occupants need shelter overhead while inside an enclosed lifeboat. Which structure provides it?'],
[3,'Which fittings provide designated places for occupants to sit?','During familiarization, a learner identifies where people should sit inside the craft. What are these fittings called?'],
[4,'Which fittings provide a secure grip for occupants?','A person needs to steady themselves while moving inside the craft. Which fitting is intended for this?'],
[5,'Which opening provides a controlled route into and out of the enclosed craft?','A learner identifies the opening used to enter the lifeboat cabin. Which part are they identifying?'],
[8,'Which feature provides reserve flotation as part of the lifeboat design?','The craft has spaces designed to contribute reserve buoyancy. What are these called?'],
[9,'Which component controls drainage from the hull according to its approved design?','During familiarization, a learner asks which fitting manages the hull’s drainage opening. Which is correct?'],
[10,'Which component supplies the mechanical power used to drive the lifeboat?','The propeller needs a source of mechanical power. Which component normally supplies it?'],
[11,'Which component converts rotation into thrust through water?','A rotating device pushes water to move the craft. Which component performs this function?'],
[13,'Which component stores the engine’s fuel supply?','A learner distinguishes the engine’s fuel storage from its electrical supply. Which item stores the fuel?'],
[14,'Which item supplies electrical energy to an electric engine-starting system?','An electrically started engine needs stored electrical energy for starting. Which component provides it?'],
[16,'Which system carries engine exhaust gases away through the designed outlet?','A learner traces the route that removes combustion gases from the engine. Which system is being studied?'],
[17,'Which control selects engine power and drive direction?','The operator needs to select the drive direction and adjust engine power. Which control has this role?'],
[18,'Which instrument indicates direction for steering and navigation?','A learner needs to identify the instrument that provides a directional reference. Which is it?'],
[19,'Which system changes or maintains the lifeboat’s heading?','The craft needs a means of controlling its heading through the water. Which system provides it?'],
[20,'Which device is used for short-range voice communication with other stations?','Survivors need to speak by radio with a nearby rescue vessel. Which listed device supports this?'],
[21,'Which device sends a distress alert through a satellite-based system?','Which listed device is intended to alert rescuers via a satellite distress system?'],
[22,'Which device helps search units locate survivors using radar or AIS technology, depending on type?','A learner identifies a search-and-rescue locating device rather than a voice radio. Which is the best match?'],
[23,'Which visual distress signal is launched high and descends under a parachute?','A distress signal is designed to remain visible aloft while descending slowly. Which type is this?'],
[24,'Which item produces a bright handheld distress signal?','Which listed signal remains handheld during its intended visual signaling use?'],
[25,'Which signal produces smoke to help show position in daylight?','A learner selects a daytime distress signal that marks a position with visible smoke. Which item fits?'],
[26,'Which item uses reflected sunlight to signal a potential rescuer?','Which signaling device relies on sunlight reflected toward someone who may see it?'],
[29,'Which device directs a strong beam to help find objects or people in darkness?','A learner identifies a light intended to illuminate a selected area at night. Which device is it?'],
[30,'Which item provides personal buoyancy for a wearer in the water?','A learner needs to identify wearable equipment whose main purpose is supporting a person afloat. Which item is correct?'],
[31,'Which suit is designed to reduce exposure and heat loss in cold water?','A learner compares personal buoyancy equipment with a suit intended to limit cold-water exposure. Which is the suit?'],
[33,'Which fitting restrains a seated occupant during craft movement?','A learner identifies the restraint used at a seating position. Which fitting is this?'],
[35,'Which equipment can tackle an appropriate small fire when the user is trained and conditions are safe?','Which listed item is intended for initial firefighting within its approved limits?'],
[39,'Which survival supply provides potable fluid for occupants?','Survivors need the stored supply intended for safe drinking. Which item should a learner identify?'],
[40,'Which stored supplies provide food energy while awaiting rescue?','A learner identifies packaged survival provisions intended to supply calories. Which item is correct?'],
[47,'Which item creates water drag to help control drift and orientation?','Which equipment is deployed in the water to resist drift, rather than provide engine thrust?'],
[49,'Which structures support and guide a suspended lifeboat in its launching arrangement?','A learner points to the arms of the shipboard launching structure. What are these called?'],
[50,'Which mechanism controls movement of the lifting falls?','A learner identifies the lifting mechanism associated with winding and paying out falls. Which is it?'],
[51,'Which lines carry the suspended craft’s load through the launching system?','What are the load-carrying lifting wires of a davit arrangement called?'],
[53,'Which fittings connect the craft to its lifting arrangement and have a designed release function?','A learner identifies the connection fittings whose release must follow the approved system instructions. Which are they?'],
[58,'Which pump removes accumulated water from inside the hull?','Water has accumulated in the lower interior of the craft. Which installed pump has the relevant function?']
];
const originalBank=pairs.flatMap(([n,pre,post],i)=>{const answer=parts[n-1];const near=parts.filter(p=>p.category===answer.category&&p.id!==answer.id);const other=parts.filter(p=>p.id!==answer.id&&!near.includes(p));const distractors=[...near,...other].slice(0,3);return (['pre','post'] as const).map(kind=>({id:`${kind}-${i+1}`,concept:i+1,kind,prompt:kind==='pre'?pre:post,correct:answer.id,choices:[answer,...distractors].map(p=>({id:p.id,text:p.name})),explanation:answer.purpose,category:answer.category}));});
const originalConcepts=new Set(pairs.map(([n])=>parts[n-1].id));
const addedDavit=parts.filter(p=>!originalConcepts.has(p.id));
const addedFreefall=freefall.filter(p=>p.concept.startsWith('ff-')).slice(0,9);
const addedQuestions=[...addedDavit,...addedFreefall].map((answer,i)=>{
 const pool=answer.id.startsWith('ff-')?freefall:parts;
 const others=pool.filter(p=>p.id!==answer.id);
 const distractors=[...others.filter(p=>p.category===answer.category),...others.filter(p=>p.category!==answer.category)].slice(0,3);
 return {id:`post-${36+i}`,concept:36+i,kind:'post' as const,
  prompt:`${answer.id.startsWith('ff-')?'In the free-fall lifeboat or its launch arrangement, which':'Which'} part or equipment matches this function? ${answer.purpose}`,
  correct:answer.id,choices:[answer,...distractors].map(p=>({id:p.id,text:p.name})),explanation:answer.purpose,category:answer.category};
});
export const bank=[...originalBank,...addedQuestions];
export function shuffle<T>(items:T[]):T[]{const a=[...items];for(let i=a.length-1;i>0;i--){const random=new Uint32Array(1);crypto.getRandomValues(random);const j=Math.floor(random[0]/4294967296*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a;}
export function createOrder(kind:string){return shuffle(bank.filter(q=>q.kind===kind)).map(q=>({id:q.id,choices:shuffle(q.choices.map(c=>c.id))}));}
export function publicQuestions(order:{id:string,choices:string[]}[]){return order.map(o=>{const q=bank.find(q=>q.id===o.id)!;return {id:q.id,prompt:q.prompt,category:q.category,choices:o.choices.map(id=>q.choices.find(c=>c.id===id)!)};});}
export function exerciseFor(partId:string){const p=parts.find(p=>p.id===partId)!;const candidates=parts.filter(x=>x.id!==p.id&&x.category===p.category);const others=parts.filter(x=>x.id!==p.id&&!candidates.includes(x));return {partId,prompt:`Which statement describes the function of ${p.name}?`,choices:shuffle([p,...[...candidates,...others].slice(0,3)].map(x=>({id:x.id,text:x.purpose})))};}
