// Small, locally synthesized effects: no downloads, autoplay, or audio tracking.
export type SoundCue='tap'|'menu'|'select'|'confirm'|'back'|'inspect'|'zoom-in'|'zoom-out'|'success'|'retry'|'celebrate'|'sad';
type Note={hz:number;at:number;length:number;level:number;wave?:OscillatorType;to?:number};
const note=(hz:number,at=0,length=.13,level=.45,wave:OscillatorType='sine',to?:number):Note=>({hz,at,length,level,wave,to});
export const soundPlans:Record<SoundCue,Note[]>={
 tap:[note(560,0,.07,.4,'sine',380)],
 menu:[note(523,0,.11,.38),note(784,.055,.15,.3)],
 select:[note(880,0,.07,.3,'sine',1047)],
 confirm:[note(523,0,.1,.35,'triangle'),note(659,.07,.1,.3),note(784,.14,.17,.3)],
 back:[note(587,0,.1,.3),note(392,.065,.13,.25)],
 inspect:[note(440,0,.12,.32,'sine',660),note(880,.075,.17,.22)],
 'zoom-in':[note(330,0,.11,.28,'sine',660)],
 'zoom-out':[note(660,0,.11,.28,'sine',330)],
 success:[note(659,0,.12,.3),note(988,.09,.19,.3)],
 retry:[note(392,0,.14,.28),note(330,.11,.18,.25)],
 celebrate:[note(523,0,.2,.42,'triangle'),note(659,.12,.2,.4,'triangle'),note(784,.24,.22,.4,'triangle'),note(1047,.4,.48,.35),note(523,.4,.48,.18),note(659,.4,.48,.18),note(1319,.65,.33,.2)],
 sad:[note(392,0,.24,.32,'triangle'),note(311,.19,.28,.3,'triangle'),note(262,.42,.48,.28,'sine',247)],
};
export function scoreSound(score:number,total:number):'celebrate'|'sad'|null{
 if(!Number.isFinite(score)||!Number.isFinite(total)||total<=0||score<0||score>total)return null;
 return score*100>=total*60?'celebrate':'sad';
}
export const SOUND_STORAGE_KEY='survival-craft:sound:v1';
export type SoundPreferences={enabled:boolean;volume:number};
export const defaultSoundPreferences:SoundPreferences={enabled:true,volume:.45};
export function readSoundPreferences(raw:string|null):SoundPreferences{
 try{const value=JSON.parse(raw||'null');return {enabled:typeof value?.enabled==='boolean'?value.enabled:true,volume:typeof value?.volume==='number'&&Number.isFinite(value.volume)?Math.max(0,Math.min(1,value.volume)):.45};}catch{return {...defaultSoundPreferences}}
}
export class SoundEffects{
 private context:AudioContext|null=null;
 private output:GainNode|null=null;
 private voices=new Set<OscillatorNode>();
 private generation=0;
 private lastInteraction=-Infinity;
 private resultUntil=0;
 private results=new Set<string>();
 private listeners=new Set<()=>void>();
 private preferences={...defaultSoundPreferences};
 getPreferences=()=>this.preferences;
 subscribe=(listener:()=>void)=>{this.listeners.add(listener);return ()=>{this.listeners.delete(listener)}};
 loadPreferences=()=>{try{this.apply(readSoundPreferences(window.localStorage.getItem(SOUND_STORAGE_KEY)))}catch{}}
 private apply(next:SoundPreferences){this.preferences=next;if(!next.enabled||next.volume===0)this.stop();if(this.output&&this.context)this.output.gain.setValueAtTime(next.enabled?next.volume*.22:0,this.context.currentTime);this.listeners.forEach(fn=>fn());}
 setPreferences(patch:Partial<SoundPreferences>){const next=readSoundPreferences(JSON.stringify({...this.preferences,...patch}));this.apply(next);try{window.localStorage.setItem(SOUND_STORAGE_KEY,JSON.stringify(next))}catch{}}
 private audio(){
  if(typeof window==='undefined')return null;
  if(!this.context||this.context.state==='closed'){
   const Constructor=window.AudioContext||(window as typeof window&{webkitAudioContext?:typeof AudioContext}).webkitAudioContext;
   if(!Constructor)return null;
   this.context=new Constructor();this.output=this.context.createGain();this.output.gain.value=this.preferences.volume*.22;this.output.connect(this.context.destination);
  }
  return this.context;
 }
 play(cue:SoundCue,pitch=0){
  if(!this.preferences.enabled||this.preferences.volume===0||typeof document==='undefined'||document.hidden)return;
  const result=cue==='celebrate'||cue==='sad',now=Date.now();
  if(!result&&(now<this.resultUntil||now-this.lastInteraction<65))return;
  if(!result)this.lastInteraction=now;
  try{
   const context=this.audio();if(!context)return;
   if(result)this.stop();
   const generation=this.generation;
   const schedule=()=>{if(generation!==this.generation||!this.preferences.enabled||this.preferences.volume===0||document.hidden||context.state!=='running'||Date.now()-now>1200)return;this.schedule(cue,pitch);};
   // Called during a real click/keyboard activation, also resumes iOS interruptions.
   if(context.state!=='running')void context.resume().then(schedule).catch(()=>{});else schedule();
  }catch{/* Sound must never interrupt a lesson, a saved answer, or 3D controls. */}
 }
 private schedule(cue:SoundCue,pitch:number){
  const context=this.context!,plan=soundPlans[cue],start=context.currentTime+.008;
  const ratio=2**(Math.max(-12,Math.min(12,pitch))/12);
  if(cue==='celebrate'||cue==='sad')this.resultUntil=Date.now()+1000*Math.max(...plan.map(n=>n.at+n.length));
  for(const n of plan){
   if(this.voices.size>=20)break;
   const osc=context.createOscillator(),gain=context.createGain(),at=start+n.at;
   osc.type=n.wave||'sine';osc.frequency.setValueAtTime(n.hz*ratio,at);if(n.to)osc.frequency.exponentialRampToValueAtTime(n.to*ratio,at+n.length);
   gain.gain.setValueAtTime(.0001,at);gain.gain.exponentialRampToValueAtTime(n.level,at+.008);gain.gain.exponentialRampToValueAtTime(.0001,at+n.length);
   osc.connect(gain);gain.connect(this.output!);this.voices.add(osc);
   osc.onended=()=>{this.voices.delete(osc);osc.disconnect();gain.disconnect()};
   osc.start(at);osc.stop(at+n.length+.015);
  }
 }
 playResultOnce(id:string,score:number,total:number){
  const cue=scoreSound(score,total);if(!cue||this.results.has(id))return;
  this.results.add(id);if(this.results.size>200)this.results.delete(this.results.values().next().value!);
  this.play(cue);
 }
 stop(){this.generation++;this.resultUntil=0;for(const voice of this.voices){try{voice.stop()}catch{}}this.voices.clear();}
 pause(){this.stop();if(this.context&&this.context.state!=='closed')void this.context.suspend().catch(()=>{});}
 dispose(){this.stop();if(this.context)void this.context.close().catch(()=>{});this.context=null;this.output=null;}
}
export const sounds=new SoundEffects();

// A single capture listener covers native controls and controls inside dialogs.
// Explicit data-sound values override the semantic defaults.
export function controlSound(control:Element):SoundCue|null{
 if(control.closest('[disabled],[aria-disabled="true"],[data-disabled]'))return null;
 const explicit=control.closest('[data-sound]')?.getAttribute('data-sound');
 if(explicit==='none')return null;
 if(explicit&&Object.hasOwn(soundPlans,explicit))return explicit as SoundCue;
 const label=(control.getAttribute('aria-label')||control.textContent||'').trim().toLowerCase();
 if(/zoom in/.test(label))return 'zoom-in';if(/zoom out/.test(label))return 'zoom-out';
 if(/^(close|back|previous|cancel|keep reviewing|end round|stop reading|hide)/.test(label))return 'back';
 if(control.matches('.nav-button,.shortcut,[role="tab"]'))return 'menu';
 if(control.matches('[role="radio"],[role="switch"],input,.match-card,.question-map button'))return 'select';
 if(control.matches('.part-card,.recommendation,.inspection-labels button,.inspection-related button,.inspection-results button'))return 'inspect';
 if(/^(start|submit|finish|save|check|match selected|download|yes)/.test(label))return 'confirm';
 if(/^(next|continue|resume|open|view)/.test(label)||control.matches('a'))return 'menu';
 return 'tap';
}
