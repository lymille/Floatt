import * as THREE from 'three';
import type {Equipment} from './lifeboat-interior';
import identifications from './model-identifications.json';

export type ModelLabel=Equipment&{unverified?:boolean;category?:string;identification?:string;references?:{label:string;url:string}[];learning?:{meaning:string;quantity:string;use:string;care:string}};
const guide={label:'Your lifeboat arrangement guide',url:'/reference/lifeboat-arrangement-guide.jpeg'};
const imo={label:'IMO example lifeboat system manual — equipment terminology',url:'https://www.imorules.com/GUID-D9134C3B-8D27-45A4-A9B2-1CE1A1C4C1D4.html'};
const viking={label:'VIKING Norsafe JYN-65 — comparable lifeboat systems',url:'https://www.viking-life.com/pim/downloads/DS_B00101012002_JYN-65_MKI_T_TSB-0120-3.pdf?context=bWFzdGVyfHJvb3R8OTEyNjQ4fGFwcGxpY2F0aW9uL3BkZnxoMWEvaDI5Lzk3NzU2Nzk4OTc2MzAvRFNfQjAwMTAxMDEyMDAyX0pZTi02NV9NS0lfVF9UU0ItMDEyMC0zLnBkZnwzNmNmYjc1Y2ViZjExNDZkNzFmYjc1MmVmNmY1NWNmYjQ1MGY0MjYxZmViZGIxOWZkMjY0YWRmMWMzYTJjNmVj'};
const named:Record<string,{name:string;description:string;location:string;category:string;identification:string;basis:string;partId?:string}>=identifications;


// Use the actual scene as the inventory: every source object gets one label,
// even when a later model adds objects missing from the curated lesson list.
export function buildModelLabels(scene:THREE.Object3D,known:Equipment[]):ModelLabel[]{
 const labels:ModelLabel[]=[];
 const seen=new Set<string>();
 scene.traverse(node=>{
  const id=node.userData.sourceObjectId as string|undefined;
  if(!id||seen.has(id))return;
  seen.add(id);
  const match=known.find(item=>item.objects.includes(id));
  const identified=named[id];
  if(identified){
   labels.push({...identified,id,objects:[id],source:'Reference model',references:[guide,identified.category==='Launching Equipment'?imo:viking]});
  }else if(match){
   const number=match.objects.indexOf(id)+1;
   labels.push({...match,id,objects:[id],identification:match.source==='Added training equipment'?'Illustrative equipment added to the training model; location may differ on a real lifeboat.':undefined,references:[guide],name:match.objects.length>1?`${match.name} · ${number}`:match.name});
  }else{
   labels.push({id,objects:[id],name:`Reference Fitting · ${id}`,unverified:true,category:'Reference Fittings',
    source:'Reference model',
    description:'This fitting is present in the original lifeboat model. Its equipment name and function have not yet been verified against the vessel’s drawings.',
    location:'Original model — use Locate on Model to see its exact position.'});
  }
 });
 return labels.sort((a,b)=>Number(!!a.unverified)-Number(!!b.unverified));
}

// Return the nearest labelled ancestor for both ray picking and coverage checks.
export function modelObjectId(object:THREE.Object3D):string|undefined{
 let node:THREE.Object3D|null=object;
 while(node){if(node.userData.sourceObjectId)return node.userData.sourceObjectId;node=node.parent;}
 return undefined;
}
