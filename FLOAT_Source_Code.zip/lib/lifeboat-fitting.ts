import * as THREE from 'three';
import {RoundedBoxGeometry} from 'three/addons/geometries/RoundedBoxGeometry.js';
import type {Equipment} from './lifeboat-interior';

const CX=-.626;
const M={gel:0xe2e6dc,edge:0xb8c3bd,rubber:0x263441,metal:0xb9c6cd,orange:0xea7423,navy:0x164677,yellow:0xf8ce42,red:0xc84435,green:0x267c58,blue:0x366a93};
type V=[number,number,number];
export const seatStations=[4.78,5.4,6.02,6.64,7.26,7.88];
export const sideSeatStations=seatStations.slice(0,5);
export const seatBeltColors=[M.yellow,M.navy] as const;
export type StowageZone={id:string;center:V;size:V};
// A study arrangement fitted to this mesh, not a capacity or approval drawing.
export function fitTrainingInterior(root:THREE.Group,equipment:Equipment[]){
 const nodes=new Map(root.children.map(n=>[n.name,n as THREE.Group]));
 function add(id:string,name:string,partId:string|undefined,location:string,description:string){const g=new THREE.Group();g.name=id;g.userData={sourceObjectId:id,interior:true};root.add(g);nodes.set(id,g);equipment.push({id,name,partId,location,description,source:'Added training equipment',objects:[id]});return g;}
 function clear(id:string){const g=nodes.get(id)!;g.traverse(n=>{if(n instanceof THREE.Mesh){n.geometry.dispose();for(const mat of Array.isArray(n.material)?n.material:[n.material])mat.dispose();}});g.clear();return g;}
 function info(id:string,location:string,name?:string){const item=equipment.find(e=>e.id===id)!;item.location=location;if(name)item.name=name;}
 function mat(color:number){return new THREE.MeshStandardMaterial({color,roughness:color===M.metal?.29:color===M.gel?.42:color===M.rubber?.85:.65,metalness:color===M.metal?.8:.03});}
 function mesh(g:THREE.Group,geometry:THREE.BufferGeometry,color:number,p:V,rotation?:V){const m=new THREE.Mesh(geometry,mat(color));m.position.set(p[0]+CX,p[1],p[2]);if(rotation)m.rotation.set(...rotation);g.add(m);return m;}
 function box(g:THREE.Group,p:V,s:V,color=M.gel,round=.025){return mesh(g,new RoundedBoxGeometry(...s,1,Math.min(round,Math.min(...s)*.23)),color,p);}
 function cyl(g:THREE.Group,p:V,r:number,h:number,color=M.metal,rotation?:V,radial=16){return mesh(g,new THREE.CylinderGeometry(r,r,h,radial),color,p,rotation);}
 function sphere(g:THREE.Group,p:V,r:number,color:number){return mesh(g,new THREE.SphereGeometry(r,16,10),color,p);}
 function tube(g:THREE.Group,points:V[],r:number,color=M.metal){const curve=new THREE.CatmullRomCurve3(points.map(p=>new THREE.Vector3(p[0]+CX,p[1],p[2])));const m=new THREE.Mesh(new THREE.TubeGeometry(curve,Math.max(8,points.length*3),r,6,false),mat(color));g.add(m);return m;}
 function ring(g:THREE.Group,p:V,r:number,t:number,color=M.metal,rotation?:V){return mesh(g,new THREE.TorusGeometry(r,t,6,24),color,p,rotation);}
 function screw(g:THREE.Group,p:V,rotation?:V){cyl(g,p,.014,.009,M.metal,rotation,6);}
 function caseModel(g:THREE.Group,p:V,s:V,color:number,carryHandle=true){
  box(g,p,s,color);box(g,[p[0],p[1]+s[1]*.18,p[2]],[s[0]+.012,.012,s[2]+.012],M.rubber,.002);
  for(const x of [-1,1]){box(g,[p[0]+x*s[0]*.3,p[1]+s[1]*.04,p[2]-s[2]*.51],[.045,.08,.018],M.metal,.005);for(const z of [-1,1])box(g,[p[0]+x*s[0]*.43,p[1],p[2]+z*s[2]*.44],[.035,s[1]*.9,.035],M.rubber,.01);}
  if(carryHandle)tube(g,[[p[0]-.08,p[1]+s[1]*.5,p[2]],[p[0]-.08,p[1]+s[1]*.5+.045,p[2]],[p[0]+.08,p[1]+s[1]*.5+.045,p[2]],[p[0]+.08,p[1]+s[1]*.5,p[2]]],.013,M.rubber);else tube(g,[[p[0]-.07,p[1],p[2]-s[2]*.5],[p[0]-.07,p[1],p[2]-s[2]*.5-.028],[p[0]+.07,p[1],p[2]-s[2]*.5-.028],[p[0]+.07,p[1],p[2]-s[2]*.5]],.009,M.metal);
 }
 function can(g:THREE.Group,p:V,s:V,color:number){
  box(g,p,s,color,.055);for(const side of [-1,1])box(g,[p[0],p[1]-.03,p[2]+side*s[2]*.5],[s[0]*.73,s[1]*.58,.017],color,.02);
  tube(g,[[p[0]-.09,p[1]+s[1]*.47,p[2]],[p[0]-.09,p[1]+s[1]*.64,p[2]],[p[0]+.04,p[1]+s[1]*.64,p[2]],[p[0]+.07,p[1]+s[1]*.48,p[2]]],.02,color);
  cyl(g,[p[0]+s[0]*.27,p[1]+s[1]*.54,p[2]],.042,.045,M.blue);for(let i=0;i<8;i++){const a=i*Math.PI/4;box(g,[p[0]+s[0]*.27+Math.sin(a)*.039,p[1]+s[1]*.54,p[2]+Math.cos(a)*.039],[.008,.04,.008],M.rubber,.001);}
 }
 function coil(g:THREE.Group,p:V,r:number,turns=4){const pts:V[]=[];for(let i=0;i<=turns*32;i++){const a=i/32*Math.PI*2;pts.push([p[0]+Math.cos(a)*r,p[1]+i/(turns*32)*.1,p[2]+Math.sin(a)*r]);}tube(g,pts,.009,0xb8a67d);}
 function strap(g:THREE.Group,points:V[],width:number,color:number){const positions:number[]=[];for(let i=0;i<points.length-1;i++){const a=points[i],b=points[i+1];for(const [p,s] of [[a,-1],[a,1],[b,1],[a,-1],[b,1],[b,-1]] as [V,number][]){positions.push(p[0]+CX+s*width/2,p[1],p[2]);}}const geo=new THREE.BufferGeometry();geo.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));geo.computeVertexNormals();const material=mat(color);material.side=THREE.DoubleSide;const m=new THREE.Mesh(geo,material);g.add(m);return m;}
 function belt(g:THREE.Group,x:number,z:number,facing:number,index:number,row:string){const color=seatBeltColors[index%2],y=4.852;const back=x-facing*.18,front=x+facing*.16;
  strap(g,[[back,y,z-.26],[front,y+.015,z-.15],[front,y+.035,z-.035]],.055,color);
  strap(g,[[front,y+.035,z+.035],[front,y+.015,z+.15],[back,y,z+.26]],.055,color);
  // Tail and adjuster lie naturally on the empty seat.
  strap(g,[[front,y+.024,z+.15],[front-facing*.05,y+.005,z+.24],[x,y+.009,z+.26]],.045,color);
  box(g,[front,y+.042,z],[.09,.025,.068],M.metal,.01);box(g,[front,y+.058,z],[.048,.006,.04],M.red,.005);
  for(const dz of [-.265,.265]){cyl(g,[back,y-.006,z+dz],.021,.012,M.metal);screw(g,[back,y+.004,z+dz]);}
  const seats=g.userData.seats||(g.userData.seats=[]);seats.push({row,index,z,color,anchorY:y-.006});
 }
 let g=clear('interior-floor');box(g,[0,4.23,6.0],[3.42,.1,4.1]);const foreFloor=new THREE.Shape([new THREE.Vector2(-1.71,-8.05),new THREE.Vector2(1.71,-8.05),new THREE.Vector2(1.35,-8.75),new THREE.Vector2(.71,-9.3),new THREE.Vector2(-.71,-9.3),new THREE.Vector2(-1.35,-8.75)]);mesh(g,new THREE.ExtrudeGeometry(foreFloor,{depth:.1,bevelEnabled:false}),M.gel,[0,4.18,0],[-Math.PI/2,0,0]);box(g,[0,4.23,3.2],[3.42,.1,1.5]);
 // An opening in the aft deck accepts a separate engine hatch.
 for(const x of [-1.09,1.09])box(g,[x,4.23,1.55],[.72,.1,1.8]);box(g,[0,4.23,.4],[2.4,.1,.5]);
 g=clear('non-slip');for(const x of [-.77,.77]){box(g,[x,4.292,6.25],[.5,.018,4.65],M.rubber);for(let z=4.05;z<8.5;z+=.2)box(g,[x,4.305,z],[.46,.007,.012],0x526067,.002);}for(let z=2.55;z<3.85;z+=.17)box(g,[0,4.293,z],[2.8,.012,.045],M.rubber);info('non-slip','Twin aisles beside the center bench and the clear side-hatch access area');
 g=clear('benches');g.userData.structurallyAttached=true;
 for(const side of [-1,1]){
  for(const [j,z] of [5.04,6.31,7.25].entries()){const panel=box(g,[side*1.385,4.79,z],[.7,.11,j===2?.64:1.24]);panel.userData.compartmentCover=(side<0?['personal-locker','food-locker','thermal-locker']:['pyro-locker','signal-locker','utility-locker'])[j];}box(g,[side*1.722,5.14,5.99],[.09,.63,3.15]);box(g,[side*1.71,4.53,5.99],[.09,.47,3.15],M.edge);
  for(const z of [4.49,5.74,6.99,7.5]){box(g,[side*1.385,4.535,z],[.63,.46,.075]);box(g,[side*1.42,4.31,z],[.54,.045,.2],M.edge);screw(g,[side*1.18,4.335,z]);screw(g,[side*1.66,4.335,z]);}
  for(const [i,z] of sideSeatStations.entries()){const pad=box(g,[side*1.385,4.85,z],[.58,.018,.55],0xcbd3ca,.03);pad.userData.compartmentCover=(side<0?['personal-locker','food-locker','thermal-locker']:['pyro-locker','signal-locker','utility-locker'])[Math.floor(i/2)];box(g,[side*1.66,5.13,z],[.02,.44,.52],0xcbd3ca,.025);}
 }
 info('benches','Straight, level side benches fixed to the floor supports, with upright backrests; clear of the side hatches and narrow bow','Attached Side Benches');
 g=add('center-bench','Attached Center Bench','part-03','Between the two longitudinal aisles, forward of the side entrances','A continuous, back-to-back bench fixed to the floor structure, with storage beneath.');g.userData.structurallyAttached=true;
 for(const [j,z] of [5.04,6.31,7.61].entries()){const panel=box(g,[0,4.79,z],[1.02,.11,j===2?1.32:1.24]);panel.userData.compartmentCover=['tool-locker','water-locker','provision-locker'][j];}box(g,[0,5.1,6.33],[.09,.53,3.8]);
 for(const z of [4.49,5.74,6.99,8.17]){box(g,[0,4.535,z],[.94,.46,.075]);box(g,[0,4.31,z],[1.08,.04,.2],M.edge);for(const x of [-.44,.44])screw(g,[x,4.335,z]);}
 for(const side of [-1,1])for(const [i,z] of seatStations.entries()){const pad=box(g,[side*.28,4.85,z],[.44,.018,.55],0xcbd3ca);pad.userData.compartmentCover=['tool-locker','water-locker','provision-locker'][Math.floor(i/2)];box(g,[side*.05,5.09,z],[.016,.36,.51],0xcbd3ca);}
 g=clear('harnesses');for(const [r,side] of [-1,1].entries())for(const [i,z] of sideSeatStations.entries())belt(g,side*1.385,z,-side,i+r,'side-'+side);
 info('harnesses','At every side-bench seating position; adjacent belt sets alternate yellow and dark blue','Alternating Side-bench Seat Belts');
 g=add('center-belts','Alternating Center-bench Seat Belts','part-33','At every center-bench seating position','Contrasting adjacent lap-belt sets help occupants distinguish their own restraint.');for(const [r,side] of [-1,1].entries())for(const [i,z] of seatStations.entries())belt(g,side*.28,z,side,i+r,'center-'+side);
 g=clear('interior-rails');for(const side of [-1,1]){tube(g,[[side*1.65,5.42,4.45],[side*1.65,5.59,4.45],[side*1.65,5.63,4.51],[side*1.65,5.63,4.7],[side*1.65,5.63,5.9],[side*1.65,5.63,6.8],[side*1.65,5.63,7.31],[side*1.65,5.63,7.44],[side*1.65,5.59,7.5],[side*1.65,5.42,7.5]],.027);for(const z of [4.45,5.97,7.5])cyl(g,[side*1.66,5.39,z],.047,.025,M.metal,[0,0,Math.PI/2]);}info('interior-rails','Along the hull above the side-bench backrests');
 g=clear('buoyancy');for(const side of [-1,1])box(g,[side*1.4,4.04,5.99],[.6,.23,3.14]);info('buoyancy','Separate sealed flotation spaces below the side benches; not equipment lockers');
 // Refine the helm, instruments, machinery and all portable equipment.
 g=nodes.get('helm-seat')!;for(const x of [-.24,.24])tube(g,[[x,5.2,1.07],[x,4.34,1.12]],.035);box(g,[0,4.32,1.3],[.7,.045,.72],M.edge);for(const x of [-.25,.25])screw(g,[x,4.35,1.1]);
 g=nodes.get('helm-console')!;for(const x of [-.27,.01,.27]){cyl(g,[x,5.69,1.8],.075,.035,M.metal,[Math.PI/2,0,0]);cyl(g,[x,5.69,1.777],.062,.012,M.rubber,[Math.PI/2,0,0]);tube(g,[[x,5.69,1.766],[x+.026,5.727,1.766]],.003,M.yellow);}for(const x of [-.42,-.25,0,.25,.42])cyl(g,[x,5.48,1.795],.021,.027,x===0?M.red:M.rubber,[Math.PI/2,0,0]);
 g=nodes.get('steering-wheel')!;for(let a=0;a<Math.PI*2;a+=Math.PI/6)sphere(g,[Math.sin(a)*.25,5.87+Math.cos(a)*.25,1.76],.027,M.rubber);
 g=nodes.get('compass')!;for(let a=0;a<Math.PI*2;a+=Math.PI/8){const tick=box(g,[-.46+Math.sin(a)*.097,6.187,2.05+Math.cos(a)*.097],[.008,.006,.019],a===0?M.red:M.rubber,.001);tick.rotation.y=a;}
 g=nodes.get('throttle')!;box(g,[.48,6.08,1.94],[.065,.01,.16],M.rubber);for(const z of [1.9,1.96,2.02])box(g,[.54,6.08,z],[.018,.012,.01],M.gel,.002);
 g=nodes.get('engine')!;for(const z of [1.35,1.58,1.81,2.04]){box(g,[0,4.1,z],[.56,.075,.1],0x346b62);screw(g,[-.2,4.14,z]);screw(g,[.2,4.14,z]);}cyl(g,[-.3,3.57,1.74],.085,.23,M.gel);cyl(g,[.3,3.6,2.12],.1,.22,M.rubber,[Math.PI/2,0,0]);for(const side of [-1,1])for(const z of [1.35,2.1]){box(g,[side*.36,3.33,z],[.18,.06,.15],M.rubber);screw(g,[side*.36,3.37,z]);}
 g=nodes.get('shaft')!;cyl(g,[0,3.46,1.08],.09,.1,M.metal,[Math.PI/2,0,0]);
 g=nodes.get('fuel')!;for(const z of [1.49,2.1])box(g,[-.88,3.925,z],[.58,.025,.04],M.rubber);tube(g,[[-.59,3.71,1.95],[-.45,3.65,1.95],[-.45,3.6,1.7]],.018,M.rubber);
 g=nodes.get('batteries')!;for(const z of [2.4,2.83]){box(g,[.84,3.8,z],[.055,.025,.34],M.rubber);tube(g,[[.73,3.825,z],[.7,3.91,z],[.96,3.91,z]],.012,M.red);}
 g=nodes.get('cooling')!;for(const z of [1.45,1.95])ring(g,[.51,3.8,z],.088,.008,M.metal);g=nodes.get('exhaust')!;for(const z of [.6,.8,1.0])ring(g,[-.54,3.9,z],.073,.008,M.metal);
 g=nodes.get('bilge')!;box(g,[.62,4.3,2.37],[.3,.035,.28],M.metal);for(const x of [.52,.72])screw(g,[x,4.325,2.37]);cyl(g,[.81,4.88,2.37],.032,.16,M.rubber,[0,0,Math.PI/2]);
 g=clear('water');for(const x of [-.34,0,.34]){can(g,[x,0,0],[.28,.4,.24],0xdbe5dd);box(g,[x,-.025,-.13],[.16,.2,.012],M.blue);}
 g=clear('rations');for(const x of [-.16,.16])for(const z of [-.18,.18]){box(g,[x,0,z],[.28,.14,.3],0xccaa63,.02);box(g,[x,.077,z],[.19,.008,.19],M.gel,.005);for(const dz of [-.135,.135])box(g,[x,0,z+dz],[.28,.17,.016],0xa68a50,.002);}
 g=clear('first-aid');caseModel(g,[0,0,0],[.4,.18,.28],M.green);box(g,[0,.102,0],[.2,.01,.052],M.gel);box(g,[0,.104,0],[.052,.01,.17],M.gel);
 g=clear('tool-kit');caseModel(g,[0,0,0],[.48,.18,.28],M.blue);for(const x of [-.12,.12])box(g,[x,.1,0],[.06,.007,.15],M.edge);
 for(const [id,c] of [['immersion-suit',M.orange],['tpa',0xa6b7c5],['fishing',M.blue],['seasickness',M.gel],['solar-still',M.blue],['rain-collector',0x416c83]] as [string,number][]){g=clear(id);box(g,[0,0,0],[.33,.13,.27],c,.045);for(const z of [-.09,.09])box(g,[0,.073,z],[.34,.012,.035],M.rubber);box(g,[0,.078,0],[.12,.008,.08],M.gel,.002);tube(g,[[-.06,.06,-.14],[-.06,.105,-.16],[.06,.105,-.16],[.06,.06,-.14]],.008,M.rubber);}
 g=clear('lifejackets');for(const z of [-.13,.13]){for(const x of [-.1,.1])box(g,[x,0,z],[.16,.1,.24],M.orange,.04);box(g,[0,0,z-.11],[.34,.1,.07],M.orange);for(const x of [-.1,.1])box(g,[x,.056,z],[.09,.01,.04],M.edge);box(g,[0,.058,z+.08],[.24,.009,.022],M.rubber);}
 g=nodes.get('extinguisher')!;cyl(g,[-.51,5.04,7.49],.031,.018,M.metal,[Math.PI/2,0,0]);cyl(g,[-.51,5.04,7.477],.024,.012,M.gel,[Math.PI/2,0,0]);ring(g,[-.5,4.78,7.6],.122,.018,M.rubber,[Math.PI/2,0,0]);box(g,[-.5,4.68,7.735],[.19,.56,.04],M.metal);ring(g,[-.58,5.09,7.6],.025,.005);
 g=nodes.get('vhf')!;for(const x of [-.56,-.52,-.48])for(const y of [6.12,6.15,6.18])box(g,[x,y,1.751],[.022,.017,.008],M.edge,.002);for(const y of [6.29,6.31,6.33])box(g,[-.52,y,1.748],[.095,.006,.008],M.rubber,.001);
 for(const id of ['epirb','sart']){g=nodes.get(id)!;const x=id==='epirb'?-.93:.95;for(const y of [5.08,5.25])ring(g,[x,y,.92],id==='epirb'?.116:.08,.015,M.rubber,[Math.PI/2,0,0]);box(g,[x,5.17,.835],[.08,.12,.014],M.gel);}
 // Pyrotechnics are full complements stored horizontally in a fitted tray.
 for(const [id,count,r,length,color] of [['rocket',4,.026,.34,M.red],['hand-flare',6,.021,.23,M.orange],['smoke',2,.05,.12,M.orange]] as [string,number,number,number,number][]){g=clear(id);for(let i=0;i<count;i++){const x=(i-(count-1)/2)*(r*2+.012);cyl(g,[x,0,0],r,length,color,[Math.PI/2,0,0]);cyl(g,[x,0,-length/2],r*1.06,.018,M.rubber,[Math.PI/2,0,0]);cyl(g,[x,0,length/2],r*1.02,.014,M.metal,[Math.PI/2,0,0]);cyl(g,[x,0,.01],r*1.01,length*.35,M.gel,[Math.PI/2,0,0]);}}
 g=clear('torch');cyl(g,[0,0,0],.038,.19,M.rubber,[Math.PI/2,0,0]);cyl(g,[0,0,-.12],.053,.065,M.yellow,[Math.PI/2,0,0]);cyl(g,[0,0,-.155],.046,.012,M.metal,[Math.PI/2,0,0]);for(const z of [-.065,-.035,.0,.035,.065])ring(g,[0,0,z],.039,.006,M.rubber);box(g,[0,.04,-.03],[.025,.012,.038],M.orange);
 g=clear('torch-spares');caseModel(g,[0,0,0],[.22,.13,.2],M.yellow);
 g=clear('mirror');box(g,[0,0,0],[.16,.018,.11],M.rubber,.013);box(g,[0,.012,0],[.144,.006,.094],M.metal,.01);ring(g,[0,.018,0],.009,.003,M.rubber,[Math.PI/2,0,0]);
 g=clear('whistle');box(g,[0,0,0],[.035,.024,.07],M.orange,.006);box(g,[0,.014,-.008],[.018,.006,.015],M.rubber,.001);ring(g,[0,0,.046],.013,.003,M.metal);tube(g,[[0,0,.056],[.035,0,.09],[.07,0,.025]],.003,M.rubber);
 function vessel(id:string,r:number,height:number,color:number,handle=true){const g=clear(id);const geo=new THREE.LatheGeometry([new THREE.Vector2(0,0),new THREE.Vector2(r*.78,0),new THREE.Vector2(r,height),new THREE.Vector2(r-.007,height),new THREE.Vector2(r*.78-.007,.009),new THREE.Vector2(0,.009)],24);mesh(g,geo,color,[0,0,0]);ring(g,[0,height,0],r,.007,color,[Math.PI/2,0,0]);if(handle){const pts:V[]=[];for(let i=0;i<=16;i++){const a=i/16*Math.PI;pts.push([Math.cos(a)*r,height+Math.sin(a)*r,0]);}tube(g,pts,.006,M.metal);}return g;}
 vessel('bucket',.16,.26,M.orange);vessel('second-bucket',.16,.26,M.orange);
 g=vessel('cup',.06,.13,M.metal,false);ring(g,[.073,.09,0],.038,.007,M.metal,[0,Math.PI/2,0]);for(let y=.035;y<.12;y+=.022)box(g,[0,y,-.06],[.022,.003,.002],M.rubber,.001);
 g=vessel('dipper',.07,.07,M.metal,false);tube(g,[[.06,.06,0],[.24,.06,0]],.01,M.metal);tube(g,[[.24,.06,0],[.26,.005,.04],[.2,.005,.09]],.003,M.rubber);
 for(const id of ['manual','rescue-signals','instructions']){g=nodes.get(id)!;g.userData.closeRevealDistance=3.2;}
 for(const id of ['can-opener','can-opener-2','can-opener-3']){g=clear(id);box(g,[0,0,0],[.027,.013,.13],M.metal,.006);tube(g,[[0,0,-.055],[.038,0,-.08],[.043,.025,-.073]],.008,M.metal);screw(g,[0,.01,-.03]);ring(g,[0,0,.073],.012,.003,M.metal,[Math.PI/2,0,0]);}
 g=clear('jackknife');box(g,[0,0,0],[.033,.022,.14],M.red,.013);box(g,[0,.014,0],[.022,.006,.12],M.metal,.005);for(const z of [-.05,.05])screw(g,[0,.02,z]);tube(g,[[0,0,.08],[.09,0,.1],[.11,0,.01]],.003,M.rubber);
 g=clear('sea-anchor');box(g,[0,0,0],[.3,.15,.32],0xa8794d,.06);for(const z of [-.1,.1])box(g,[0,.08,z],[.32,.015,.03],M.rubber);coil(g,[0,-.08,.33],.14);info('sea-anchor','Packed sea-anchor bag with hawser, secured inside the forward recovery locker');
 for(const [id,z] of [['quoit',8.92],['second-quoit',.62]] as const){g=clear(id);const x=id==='quoit'?.87:-1.05;ring(g,[x,5.06,z],.19,.035,M.orange);for(const dx of [-.19,.19])box(g,[x+dx,5.06,z-.035],[.075,.1,.024],M.edge);coil(g,[x,4.68,z],.13);box(g,[x,4.63,z+.08],[.43,.05,.28],M.gel);tube(g,[[x,5.06,z],[x+.16,4.95,z],[x+.13,4.74,z]],.009,0xb8a67d);info(id,'Retained rescue-line holder '+(id==='quoit'?'at the bow':'beside the aft entrance'));}
 for(const [id,z] of [['hatchet',1.9],['forward-hatchet',9.02]] as const){g=clear(id);const x=id==='hatchet'?-1.35:-.9;box(g,[x,5.07,z],[.22,.13,.047],M.metal,.025);box(g,[x-.035,4.86,z],[.038,.43,.034],0x9b754c,.015);box(g,[x,5.07,z-.008],[.23,.15,.022],M.rubber);box(g,[x-.035,4.72,z-.02],[.09,.065,.04],M.metal);info(id,'Blade guard and quick-access retaining clips '+(id==='hatchet'?'at the aft end':'at the forward end'));}
 g=clear('radar-reflector');g.userData.interior=true;box(g,[0,0,0],[.32,.032,.32],M.metal,.003);for(const y of [.028,.04,.052])box(g,[0,y,0],[.31,.008,.31],M.edge,.002);box(g,[0,.07,0],[.035,.012,.34],M.rubber);info('radar-reflector','Folded and strapped in the starboard signal locker; erect only for use');
 g=nodes.get('searchlight')!;for(const x of [.34,.70])tube(g,[[x,7.43,1.8],[x,7.62,1.8]],.018,M.metal);ring(g,[.52,7.64,1.97],.15,.01,M.metal);for(const a of [0,Math.PI/2,Math.PI,Math.PI*1.5])screw(g,[.52+Math.sin(a)*.14,7.64+Math.cos(a)*.14,1.98],[Math.PI/2,0,0]);
 g=nodes.get('desalinator')!;for(const z of [8.05,8.23])ring(g,[.8,4.48,z],.076,.014,M.metal);cyl(g,[.93,4.73,8],.025,.15,M.rubber,[0,0,Math.PI/2]);
 g=nodes.get('tiller')!;for(const z of [1.5,2.05])box(g,[.93,4.86,z],[.1,.08,.035],M.rubber);g=nodes.get('vent')!;ring(g,[1.14,5.7,2.54],.104,.017,M.gel,[Math.PI/2,0,0]);g=nodes.get('drain')!;ring(g,[0,3.17,.1],.09,.014,M.metal,[Math.PI/2,0,0]);
 for(const [id,x] of [['painter',-.42],['spare-painter',.42]] as const){g=clear(id);coil(g,[x,4.48,9.48],.16,5);box(g,[x,4.46,9.48],[.39,.035,.39],M.gel);for(const dx of [-.1,.1])box(g,[x+dx,4.57,9.48],[.025,.018,.36],M.rubber);tube(g,[[x,4.58,9.48],[x,4.64,9.7],[x,5.02,9.8]],.013,0xb8a67d);info(id,'Secured line coil in the bow painter tray, ready for use.');}
 g=nodes.get('painter-release')!;ring(g,[-.5,5.07,9.82],.05,.012,M.metal);for(const x of [-.59,-.41])screw(g,[x,5.089,9.8]);
 g=nodes.get('oars')!;for(const z of [4.3,4.48]){cyl(g,[1.1,4.34,z-1.14],.034,.25,0x7b613d,[Math.PI/2,0,0]);box(g,[1.1,4.365,z+1.1],[.07,.013,.46],0xc6a674,.01);}
 for(const [id,x] of [['boat-hook',-1.17],['second-boat-hook',1.17]] as const){g=nodes.get(id)!;cyl(g,[x,4.39,5.55],.026,.25,M.rubber,[Math.PI/2,0,0]);cyl(g,[x,4.39,7.17],.023,.15,M.metal,[Math.PI/2,0,0]);}
 g=nodes.get('bailer')!;box(g,[-.25,4.435,7.82],[.029,.009,.13],M.rubber,.006);
 // Retain identifiable mountings and small-item details without expensive textures.
 g=nodes.get('air-horn')!;ring(g,[.58,5.3,2.45],.06,.008,M.metal,[Math.PI/2,0,0]);box(g,[.58,5.37,2.41],[.06,.025,.04],M.rubber);
 g=nodes.get('seasickness-bags')!;for(let i=0;i<3;i++)box(g,[-.23,5.022+i*.017,4.928],[.19,.003,.018],M.edge,.001);
 g=nodes.get('cabin-lights')!;for(const z of [3.3,6.7]){box(g,[0,5.943,z],[.36,.025,.16],M.edge);for(const x of [-.15,.15])screw(g,[x,5.956,z]);}
 g=nodes.get('position-light')!;ring(g,[-.3,6.96,6.8],.075,.009,M.metal,[Math.PI/2,0,0]);
 // Replace the old display plinths with actual enclosed compartments.
 const zones:StowageZone[]=[];
 function locker(id:string,name:string,p:V,s:V,color=M.gel){let g=nodes.has(id)?clear(id):add(id,name,'part-48','', 'Secured stowage compartment with a gasketed lid and retaining latches.');info(id,name+'; contents become visible during close inspection',name);g.userData.storageCover=id;g.userData.storageZone={center:[p[0]+CX,p[1],p[2]],size:s};zones.push({id,center:[p[0]+CX,p[1],p[2]],size:s});caseModel(g,p,s,color,false);return g;}
 locker('medical-locker','Aft Medical Locker',[-1.35,5.05,2.04],[.45,.64,.7],M.gel);
 locker('personal-locker','Port Personal-equipment Locker',[-1.385,4.52,4.93],[.59,.43,.92]);
 locker('food-locker','Port Ration Locker',[-1.385,4.52,6.04],[.59,.43,1.12]);
 locker('thermal-locker','Port Thermal-equipment Locker',[-1.385,4.52,7.25],[.59,.43,.58]);
 locker('pyro-locker','Starboard Distress-signal Locker',[1.385,4.52,4.93],[.59,.43,.92],M.orange);
 locker('signal-locker','Starboard Signaling-equipment Locker',[1.385,4.52,6.17],[.59,.43,1.23]);
 locker('utility-locker','Starboard Survival-equipment Locker',[1.385,4.52,7.25],[.59,.43,.58]);
 locker('tool-locker','Center-bench Tool Locker',[0,4.52,4.98],[.9,.43,1.04]);
 locker('water-locker','Center-bench Drinking-water Locker',[0,4.52,6.19],[.9,.43,1.18]);
 locker('provision-locker','Center-bench Utensil and Manual Locker',[0,4.52,7.61],[.9,.43,1.12]);
 locker('lockers','Forward Recovery-equipment Locker',[0,4.55,8.83],[1.3,.48,.86]);
 locker('engine-hatch','Engine Access Hatch',[0,4.225,1.55],[1.44,.065,1.8]);info('engine-hatch','Aft deck over the machinery bay','Engine Access Hatch');
 function stow(id:string,zone:string,p:V,size:V){const g=nodes.get(id)!;g.updateMatrixWorld(true);const b=new THREE.Box3().setFromObject(g),center=b.getCenter(new THREE.Vector3()),dim=b.getSize(new THREE.Vector3());const scale=Math.min(1,size[0]/Math.max(dim.x,.001),size[1]/Math.max(dim.y,.001),size[2]/Math.max(dim.z,.001));g.scale.setScalar(scale);g.position.set(p[0]+CX-center.x*scale,p[1]-center.y*scale,p[2]-center.z*scale);g.userData.storageId=zone;g.userData.closeRevealDistance=undefined;const holder=equipment.find(e=>e.id===zone)!;const item=equipment.find(e=>e.id===id)!;item.stowage={id:zone,name:holder.name};item.location=`Inside ${holder.name.toLowerCase()}. Secured in a fitted compartment; zoom close or choose Locate on Model to inspect.`;g.updateMatrixWorld(true);}
 stow('first-aid','medical-locker',[-1.35,5.14,2.03],[.36,.2,.45]);stow('seasickness','medical-locker',[-1.35,4.9,1.91],[.3,.13,.25]);stow('seasickness-bags','medical-locker',[-1.35,4.9,2.23],[.3,.12,.2]);
 stow('lifejackets','personal-locker',[-1.385,4.52,4.93],[.5,.3,.74]);stow('rations','food-locker',[-1.385,4.49,6.04],[.49,.28,.96]);
 stow('immersion-suit','thermal-locker',[-1.385,4.41,7.25],[.48,.16,.48]);stow('tpa','thermal-locker',[-1.385,4.61,7.25],[.48,.16,.48]);
 stow('rocket','pyro-locker',[1.385,4.42,4.71],[.46,.08,.35]);stow('hand-flare','pyro-locker',[1.385,4.43,5.05],[.47,.07,.25]);stow('smoke','pyro-locker',[1.385,4.57,5.1],[.45,.13,.2]);
 stow('radar-reflector','signal-locker',[1.385,4.41,5.8],[.43,.12,.37]);stow('torch','signal-locker',[1.25,4.46,6.17],[.15,.15,.35]);stow('torch-spares','signal-locker',[1.5,4.47,6.16],[.2,.2,.3]);stow('mirror','signal-locker',[1.25,4.44,6.52],[.21,.07,.14]);stow('whistle','signal-locker',[1.49,4.44,6.52],[.16,.08,.13]);
 stow('air-horn','utility-locker',[1.25,4.58,7.25],[.19,.28,.34]);stow('solar-still','utility-locker',[1.385,4.37,7.25],[.47,.1,.45]);stow('desalinator','utility-locker',[1.52,4.58,7.25],[.17,.28,.34]);
 stow('tool-kit','tool-locker',[0,4.46,4.77],[.73,.24,.43]);stow('jackknife','tool-locker',[-.3,4.45,5.29],[.12,.1,.24]);for(const [i,id] of ['can-opener','can-opener-2','can-opener-3'].entries())stow(id,'tool-locker',[-.12+i*.18,4.45,5.29],[.12,.09,.22]);
 stow('water','water-locker',[0,4.49,6.16],[.79,.31,.85]);stow('cup','provision-locker',[-.27,4.48,7.35],[.2,.25,.23]);stow('dipper','provision-locker',[.13,4.43,7.36],[.45,.13,.25]);stow('manual','provision-locker',[0,4.42,7.83],[.32,.065,.35]);stow('fishing','provision-locker',[-.29,4.45,7.83],[.23,.16,.3]);stow('rain-collector','provision-locker',[.3,4.45,7.83],[.23,.16,.3]);
 stow('sea-anchor','lockers',[-.4,4.52,8.83],[.39,.29,.66]);stow('bucket','lockers',[.07,4.5,8.65],[.34,.34,.34]);stow('second-bucket','lockers',[.45,4.5,8.65],[.34,.34,.34]);stow('bailer','lockers',[.26,4.5,9.02],[.58,.18,.23]);
 for(const id of ['engine','shaft','fuel','batteries','cooling','exhaust','drain']){nodes.get(id)!.userData.storageId='engine-hatch';const item=equipment.find(e=>e.id===id)!;item.stowage={id:'engine-hatch',name:'Aft machinery bay'};if(id==='engine')item.location='Under the aft engine access hatch, secured to engine beds.';}
 function rack(id:string,target:V,maxSize:V,location:string){const g=nodes.get(id)!;g.updateMatrixWorld(true);const b=new THREE.Box3().setFromObject(g),c=b.getCenter(new THREE.Vector3()),d=b.getSize(new THREE.Vector3());const s=Math.min(1,...maxSize.map((v,i)=>v/Math.max(d.getComponent(i),.001)));g.scale.setScalar(s);g.position.set(target[0]+CX-c.x*s,target[1]-c.y*s,target[2]-c.z*s);g.userData.closeRevealDistance=3.2;info(id,location);}
 rack('oars',[-1.62,5.52,6.25],[.25,.24,3.0],'Retaining clips along the port inner wall above the bench');
 rack('boat-hook',[-1.62,5.72,6.25],[.18,.18,2.5],'Accessible open clips along the port wall; available for fending off');
 rack('second-boat-hook',[1.62,5.72,6.25],[.18,.18,2.5],'Accessible open clips along the starboard wall; available for fending off');
 stow('oarlocks','tool-locker',[.29,4.58,4.98],[.13,.12,.4]);
 for(const id of ['oars','boat-hook','second-boat-hook']){const target=nodes.get(id)!;target.updateMatrixWorld(true);const b=new THREE.Box3().setFromObject(target);const c=b.getCenter(new THREE.Vector3());const brackets=add(id+'-clips',equipment.find(e=>e.id===id)!.name+' Retaining Clips',undefined,'Inner hull wall above the seating','Retain the long equipment while keeping it accessible.');for(const dz of [-.65,.65]){box(brackets,[c.x-CX,c.y,c.z+dz],[.09,.1,.05],M.rubber);box(brackets,[c.x-CX,c.y-.055,c.z+dz],[.14,.025,.09],M.metal);}brackets.userData.closeRevealDistance=3.5;}
 for(const id of ['painter','spare-painter','quoit','second-quoit','hatchet','forward-hatchet','tiller','extinguisher','vhf','epirb','sart','bilge'])nodes.get(id)!.userData.closeRevealDistance=3.4;
 // Reposition the extinguisher into a reachable bulkhead bracket, clear of the aisle.
 rack('extinguisher',[1.4,5.09,2.28],[.36,.72,.3],'Retaining bracket beside the aft access route, clear of controls and walkways');
 // Keep the seating rigid and comfortable: level seat pans, upright planar
 // backrests and full seat spacing. End the side benches before the narrow bow.
 root.updateMatrixWorld(true);
 for(const id of ['benches','harnesses','interior-rails','buoyancy']){
  nodes.get(id)!.traverse(object=>{
   if(!(object instanceof THREE.Mesh))return;
   const center=new THREE.Box3().setFromObject(object).getCenter(new THREE.Vector3());
   object.position.x-=Math.sign(center.x-CX)*.18;
  });
 }
 // Only the floor perimeter follows the hull; never deform seating surfaces.
 nodes.get('interior-floor')!.traverse(object=>{
  if(!(object instanceof THREE.Mesh))return;
  const positions=object.geometry.getAttribute('position');
  const inverse=object.matrixWorld.clone().invert(),point=new THREE.Vector3();
  for(let i=0;i<positions.count;i++){
   point.fromBufferAttribute(positions,i).applyMatrix4(object.matrixWorld);
   const inset=.1*THREE.MathUtils.clamp((point.z-6.2)/2.1,0,1)**2;
   point.x-=Math.sign(point.x-CX)*inset*Math.min(1,Math.abs(point.x-CX));
   point.applyMatrix4(inverse);positions.setXYZ(i,point.x,point.y,point.z);
  }
  positions.needsUpdate=true;object.geometry.computeVertexNormals();
  object.geometry.computeBoundingBox();object.geometry.computeBoundingSphere();
 });
 // Move the rigid oars and boat hooks with their brackets; do not bend them
 // to match the hull's curve.
 for(const id of ['oars','boat-hook','second-boat-hook']){
  const group=nodes.get(id)!,center=new THREE.Box3().setFromObject(group).getCenter(new THREE.Vector3());
  const offset=Math.sign(center.x-CX)*.16;
  group.position.x-=offset;nodes.get(id+'-clips')!.position.x-=offset;
 }
 // Move complete under-seat compartments and their contents with the bench.
 // Keep their dimensions and reveal bounds aligned with the rigid geometry.
 for(const id of ['personal-locker','food-locker','thermal-locker','pyro-locker','signal-locker','utility-locker']){
  const zone=zones.find(zone=>zone.id===id)!;
  const offset=Math.sign(zone.center[0]-CX)*.18;
  for(const group of root.children){
   if(group.name===id||group.userData.storageId===id)group.position.x-=offset;
  }
  zone.center[0]-=offset;
  nodes.get(id)!.userData.storageZone={center:[...zone.center],size:[...zone.size]};
 }
 root.userData.stowageZones=zones;root.updateMatrixWorld(true);
}

export function storageReveal(distance:number){return 1-THREE.MathUtils.smoothstep(distance,1.15,2.65);}
export function storedItemVisible(reveal:number,focused:boolean){return focused||reveal>.16;}
