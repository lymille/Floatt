export type LearningComponent={
 id:string;
 name:string;
 category:string;
 purpose:string;
 location?:string;
 quantity?:string;
 use?:string;
 care?:string;
 stowage?:{id:string;name:string};
 identification?:string;
 references?:{label:string;url:string}[];
};

export type ComponentProgress={part_id:string;status:string;exercise_passed:number;viewed:number};
