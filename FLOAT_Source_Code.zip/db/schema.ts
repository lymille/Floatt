import { sqliteTable, text, integer, primaryKey, uniqueIndex, index } from 'drizzle-orm/sqlite-core';
import {sql} from 'drizzle-orm';
export const profiles=sqliteTable('profiles',{userId:text('user_id').primaryKey(),name:text('name').notNull(),age:integer('age'),createdAt:text('created_at').notNull()});
export const attempts=sqliteTable('attempts',{id:text('id').primaryKey(),userId:text('user_id').notNull(),kind:text('kind').notNull(),status:text('status').notNull(),order:text('question_order').notNull(),answers:text('answers').notNull(),revision:integer('revision').notNull().default(0),score:integer('score'),evaluation:text('evaluation'),name:text('certificate_name'),completedAt:text('completed_at'),createdAt:text('created_at').notNull()},t=>[uniqueIndex('attempt_user_kind').on(t.userId,t.kind)]);
export const progress=sqliteTable('progress',{userId:text('user_id').notNull(),partId:text('part_id').notNull(),status:text('status').notNull().default('not_yet'),exercisePassed:integer('exercise_passed').notNull().default(0),viewed:integer('viewed').notNull().default(0),updatedAt:text('updated_at').notNull()},t=>[primaryKey({columns:[t.userId,t.partId]})]);
export const practiceSessions=sqliteTable('practice_sessions',{
 id:text('id').primaryKey(),userId:text('user_id').notNull(),mode:text('mode').notNull(),craft:text('craft').notNull(),
 status:text('status').notNull().default('in_progress'),payload:text('payload').notNull(),answers:text('answers').notNull(),
 revision:integer('revision').notNull().default(0),score:integer('score').notNull().default(0),total:integer('total').notNull(),
 moves:integer('moves').notNull().default(0),xp:integer('xp').notNull().default(0),createdAt:text('created_at').notNull(),completedAt:text('completed_at'),
},t=>[uniqueIndex('practice_user_active_mode').on(t.userId,t.mode).where(sql`${t.status} = 'in_progress'`),index('practice_user_status').on(t.userId,t.status)]);
