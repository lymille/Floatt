import {getChatGPTUser,chatGPTSignInPath} from './chatgpt-auth';
import {SoundToggle} from './site-sounds';
import LearningApp from './learning-app';
export const dynamic='force-dynamic';
export default async function Page(){const user=await getChatGPTUser();if(!user)return <main className="entry"><div className="entry-card"><div className="entry-sound-row"><div className="brand-mark">⚓</div><SoundToggle/></div><p className="eyebrow">F L O A T</p><h1>Your learning voyage starts here.</h1><p>Discover lifeboat equipment, practice each part’s function, and see how much you improve.</p><div className="journey"><span>01 · Pre-test</span><span>02 · Learn & practice</span><span>03 · Post-test</span></div><a className="primary" href={chatGPTSignInPath('/')} target="_top">Sign in with ChatGPT</a><p className="muted">Sign in to save your progress and certificates across devices. Direct Google sign-in is not available in this version.</p></div></main>;return <LearningApp email={user.email}/>}
