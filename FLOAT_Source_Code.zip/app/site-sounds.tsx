'use client';
import {useEffect,useId,useSyncExternalStore} from 'react';
import {Volume2,VolumeX} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {sounds,controlSound,defaultSoundPreferences,SOUND_STORAGE_KEY} from '@/lib/sound-effects';

const serverPreferences=()=>defaultSoundPreferences;
function useSoundPreferences(){return useSyncExternalStore(sounds.subscribe,sounds.getPreferences,serverPreferences)}
export function SiteSounds({children}:{children:React.ReactNode}){
 useEffect(()=>{
  sounds.loadPreferences();
  const click=(event:MouseEvent)=>{
   if(!event.isTrusted||event.button!==0||!(event.target instanceof Element))return;
   const control=event.target.closest('button,a[href],summary,[role="button"],[role="radio"],[role="switch"],[role="tab"],input[type="checkbox"],input[type="radio"]');
   if(!control)return;
   const cue=controlSound(control);if(cue)sounds.play(cue,Number(control.getAttribute('data-sound-pitch'))||0);
  };
  const change=(event:Event)=>{if(event.isTrusted&&event.target instanceof HTMLSelectElement&&!event.target.disabled)sounds.play('select')};
  const visibility=()=>{if(document.hidden)sounds.pause()};
  const storage=(event:StorageEvent)=>{if(event.key===SOUND_STORAGE_KEY||event.key===null)sounds.loadPreferences()};
  document.addEventListener('click',click,true);document.addEventListener('change',change,true);document.addEventListener('visibilitychange',visibility);window.addEventListener('storage',storage);
  return()=>{document.removeEventListener('click',click,true);document.removeEventListener('change',change,true);document.removeEventListener('visibilitychange',visibility);window.removeEventListener('storage',storage);sounds.dispose()};
 },[]);
 return children;
}
export function SoundToggle(){
 const {enabled}=useSoundPreferences();
 return <Button type="button" variant="outline" className="sound-toggle" data-sound="none" aria-label={enabled?'Mute sound effects':'Enable sound effects'} aria-pressed={enabled} onClick={()=>{sounds.setPreferences({enabled:!enabled});if(!enabled)sounds.play('select')}}>{enabled?<Volume2/>:<VolumeX/>}<span>{enabled?'Sound on':'Sound off'}</span></Button>;
}
export function SoundSettings(){
 const {enabled,volume}=useSoundPreferences(),id=useId();
 return <Card className="section sound-settings"><div className="sound-settings-heading"><div><h2>Sound effects</h2><p>Playful sounds for menus, buttons, equipment, and results.</p></div><SoundToggle/></div><label htmlFor={id}>Sound volume <strong>{Math.round(volume*100)}%</strong></label><input id={id} type="range" min="0" max="100" step="5" value={Math.round(volume*100)} disabled={!enabled} onChange={e=>sounds.setPreferences({volume:Number(e.target.value)/100})} onPointerUp={()=>sounds.play('tap')} onKeyUp={e=>{if(e.key.startsWith('Arrow'))sounds.play('tap')}}/><p className="muted">A score of 60% or higher plays a celebration. Below 60% plays a gentle sad tune. Your sound preference is saved on this device.</p><div className="actions"><Button variant="outline" data-sound="none" disabled={!enabled||volume===0} onClick={()=>sounds.play('celebrate')}>Preview celebration</Button><Button variant="outline" data-sound="none" disabled={!enabled||volume===0} onClick={()=>sounds.play('sad')}>Preview sad sound</Button></div></Card>;
}
