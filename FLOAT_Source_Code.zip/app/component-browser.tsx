'use client';
import {useState} from 'react';
import {ArrowRight,Check,Search} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Label} from '@/components/ui/label';
import type {LearningComponent,ComponentProgress} from '@/lib/learning-components';

type Props={davit:LearningComponent[];freefall:LearningComponent[];davitProgress:ComponentProgress[];freefallProgress:ComponentProgress[];onOpen:(part:LearningComponent)=>void};
export default function ComponentBrowser({davit,freefall,davitProgress,freefallProgress,onOpen}:Props){
 const [craft,setCraft]=useState<'davit'|'freefall'>('davit');
 const [category,setCategory]=useState('All'),[query,setQuery]=useState('');
 const isFreefall=craft==='freefall',parts=isFreefall?freefall:davit,progress=isFreefall?freefallProgress:davitProgress;
 const craftName=isFreefall?'Free-fall lifeboat':'Davit lifeboat';
 const categories=[...new Set(parts.map(p=>p.category))];
 const statusById=new Map(progress.map(p=>[p.part_id,p]));
 const learned=parts.filter(p=>statusById.get(p.id)?.status==='learned').length;
 const passed=parts.filter(p=>statusById.get(p.id)?.exercise_passed===1).length;
 const explored=parts.filter(p=>statusById.get(p.id)?.viewed===1).length;
 const search=query.trim().toLocaleLowerCase();
 const visible=parts.filter(p=>(category==='All'||p.category===category)&&(!search||`${p.name} ${p.category} ${p.purpose}`.toLocaleLowerCase().includes(search)));
 return <div className="component-browser">
  <div className="page-heading"><p className="eyebrow">LEARN · IDENTIFY · PRACTICE</p><h1>Lifeboat components</h1><p>Choose a lifeboat to learn its parts, equipment, and functions. Your learning status is shared with the 3D explorer.</p></div>
  <div className="component-craft-picker" role="group" aria-label="Choose lifeboat components">
   {([{id:'davit',name:'Davit lifeboat',parts:davit,progress:davitProgress},{id:'freefall',name:'Free-fall lifeboat',parts:freefall,progress:freefallProgress}] as const).map(option=>{
    const saved=new Map(option.progress.map(p=>[p.part_id,p.status]));
    const count=option.parts.filter(p=>saved.get(p.id)==='learned').length;
    return <button key={option.id} type="button" aria-pressed={craft===option.id} aria-controls="component-list" className={`component-craft ${option.id}`} onClick={()=>{setCraft(option.id);setCategory('All');setQuery('')}}><strong>{option.name}</strong><span>{count} / {option.parts.length} learned</span></button>;
   })}
  </div>
  <section id="component-list" aria-labelledby="component-craft-title">
   <div className="component-list-heading"><h2 id="component-craft-title">{craftName} components</h2><p>{learned}/{parts.length} learned · {isFreefall?`${explored}/${parts.length} explored`:`${passed}/${parts.length} exercises passed`}</p></div>
   <div className="filter-row component-filters">
    <div className="component-search"><Search size={18} aria-hidden="true"/><Input aria-label={`Search ${craftName.toLowerCase()} components`} placeholder="Search parts or equipment…" value={query} onChange={e=>setQuery(e.target.value)}/></div>
    <Label htmlFor="component-category">Category</Label><select id="component-category" value={category} onChange={e=>setCategory(e.target.value)}><option>All</option>{categories.map(c=><option key={c}>{c}</option>)}</select>
    <span role="status">{visible.length} of {parts.length} parts</span>
   </div>
   <div className="parts-grid">{visible.map(p=>{const record=statusById.get(p.id);return <button type="button" className="part-card" key={p.id} onClick={()=>onOpen(p)}><span className="muted">{p.category}</span><h3>{p.name}</h3><span className={`badge ${record?.status||'not_yet'}`}>{record?.status==='learned'?'Learned It':record?.status==='almost'?'Almost There':'Not Yet'}</span><p className="exercise-line">{isFreefall?<>View component <ArrowRight size={15}/></>:record?.exercise_passed?<><Check size={16}/> Exercise passed</>:<>Function exercise <ArrowRight size={15}/></>}</p></button>})}</div>
   {!visible.length&&<div className="component-empty"><p>No components match your search.</p><Button variant="outline" onClick={()=>{setCategory('All');setQuery('')}}>Clear filters</Button></div>}
   <p className="curriculum-note">{isFreefall?'Includes the modeled exterior, launch skid, interior, and stored equipment. The arrangement and quantities are illustrative; refer to your vessel’s approved inventory and instructions.':'General learning curriculum; actual equipment and arrangements vary by lifeboat.'}</p>
  </section>
 </div>;
}
