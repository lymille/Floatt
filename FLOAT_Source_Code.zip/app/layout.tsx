import type {Metadata} from 'next';
import './globals.css';
import {SiteSounds} from './site-sounds';
export const metadata:Metadata={title:'F L O A T · Learn, Practice & Assess',description:'Learn lifeboat parts, measure your knowledge, and earn personal learning certificates.',icons:{icon:'/favicon.svg'}};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body><SiteSounds>{children}</SiteSounds></body></html>}
