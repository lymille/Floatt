'use client';
import {useEffect,useRef,useState} from 'react';
import {sounds} from '@/lib/sound-effects';
import * as THREE from 'three';
import {GLTFLoader} from 'three/addons/loaders/GLTFLoader.js';
import {RoomEnvironment} from 'three/addons/environments/RoomEnvironment.js';
import {storageReveal,storedItemVisible} from '@/lib/lifeboat-fitting';
import {OrbitControls} from 'three/addons/controls/OrbitControls.js';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Anchor,Search,Volume2,VolumeX,BookOpen,MapPin,Box,RotateCcw,Scan,Eye,EyeOff,Maximize,Layers,X,Focus,ZoomIn,ZoomOut} from 'lucide-react';
import {buildInterior,referenceEquipment,shellIds,closeViewOpacity,type Equipment} from '@/lib/lifeboat-interior';
import {parts} from '@/lib/curriculum';
import {batchInterior,viewerMaterial} from '@/lib/lifeboat-rendering';
import {buildModelLabels,modelObjectId,type ModelLabel} from '@/lib/lifeboat-labels';
import {equipmentDetails,equipmentSource,videoSource} from '@/lib/lifeboat-equipment-details';
type Mode='auto'|'cutaway'|'solid';
type Controls={select:(id:string)=>void;focus:()=>void;reset:()=>void;view:(name:string)=>void;mode:(value:Mode)=>void;hide:()=>void;restore:()=>void;highlight:(value:boolean)=>void;zoom:(factor:number)=>void;clear:()=>void;locate:()=>void;explode:(v:boolean)=>void};
type Craft='davit'|'freefall';
type ViewerProps={onLearn?:(id:string)=>void;progress?:{part_id:string;status:string}[];saving?:boolean;onStatus?:(id:string,status:string)=>Promise<boolean>};
export default function LifeboatViewer(props:ViewerProps){
 const [craft,setCraft]=useState<Craft>('davit');
 // A fresh session disposes the previous scene, textures and WebGL context.
 // Selection and search never leak between the two independent inventories.
 return <LifeboatSession key={craft} {...props} craft={craft} onCraft={setCraft}/>;
}
function LifeboatSession({onLearn,progress=[],saving=false,onStatus,craft,onCraft}:ViewerProps&{craft:Craft;onCraft:(craft:Craft)=>void}){
 const freefall=craft==='freefall';
 const mount=useRef<HTMLDivElement>(null),wrap=useRef<HTMLDivElement>(null),tag=useRef<HTMLDivElement>(null),api=useRef<Controls|null>(null);
 const [selected,setSelected]=useState(''),[status,setStatus]=useState('Loading your lifeboat…'),[loaded,setLoaded]=useState(false),[failed,setFailed]=useState(false),[mode,setMode]=useState<Mode>('auto'),[isolated,setIsolated]=useState(false),[allBlue,setAllBlue]=useState(false),[query,setQuery]=useState(''),[hidden,setHidden]=useState(0),[retry,setRetry]=useState(0),[equipment,setEquipment]=useState<ModelLabel[]>(freefall?[]:referenceEquipment);
 const [showParts,setShowParts]=useState(false),[showLabels,setShowLabels]=useState(true),[exploded,setExploded]=useState(false),[speaking,setSpeaking]=useState(false),[saveMessage,setSaveMessage]=useState('');
 const labelRefs=useRef(new Map<string,HTMLButtonElement>());
 const item=equipment.find(e=>e.id===selected||e.objects.includes(selected));
 const details=item?equipmentDetails(item):undefined;
 const selectedName=item?.name||(selected?`Reference Fitting · ${selected}`:'');
 const categoryOf=(e:ModelLabel)=>e.category||parts.find(p=>p.id===e.partId)?.category||'Additional Equipment';
 const trackingId=(e:Equipment)=>freefall?e.id:e.partId;
 const statusOf=(e:Equipment)=>progress.find(p=>p.part_id===trackingId(e))?.status||'not_yet';
 const visibleEquipment=equipment.filter(e=>`${e.name} ${e.id} ${e.location}`.toLowerCase().includes(query.toLowerCase()));
 const related=item?equipment.filter(e=>e.id!==item.id&&categoryOf(e)===categoryOf(item)).slice(0,6):[];
 useEffect(()=>{api.current?.mode(mode);},[loaded,equipment,query,showLabels,mode]);
 const inspect=(id:string)=>{setSaveMessage('');api.current?.select(id);setShowParts(false);setQuery('');};
 useEffect(()=>{if('speechSynthesis' in window)window.speechSynthesis.cancel();setSpeaking(false);setSaveMessage('');return()=>{if('speechSynthesis' in window)window.speechSynthesis.cancel();};},[selected]);
 const speak=()=>{if(!('speechSynthesis' in window))return;if(speaking){window.speechSynthesis.cancel();setSpeaking(false);return;}const utterance=new SpeechSynthesisUtterance(`${selectedName}. ${item?.description||''}. Location: ${item?.location||'Not yet identified'}. ${details?`Quantity: ${details.quantity}. Use: ${details.use}. ${details.care}`:''}`);utterance.onend=()=>setSpeaking(false);utterance.onerror=()=>setSpeaking(false);setSpeaking(true);window.speechSynthesis.speak(utterance);};
 useEffect(()=>{
  const host=mount.current!;const touchDevice=matchMedia('(pointer: coarse)').matches||navigator.maxTouchPoints>1;const abort=new AbortController();let renderer:THREE.WebGLRenderer;
  try{renderer=new THREE.WebGLRenderer({antialias:!touchDevice,alpha:false,powerPreference:'default'});}catch{setFailed(true);setStatus('3D rendering is unavailable on this device. Try a browser with WebGL enabled.');return;}
  let disposed=false,contextLost=false,dirty=true,lastFrame=0,frame=0,model:THREE.Group|undefined,current='',transparency:Mode='auto',focusMode=false,whole=false,downPoint={x:0,y:0},moved=false;
  let navigateToSelection:(()=>void)|undefined;
  let modelShellIds=shellIds,engineId='engine',explodedView=false;
  let interiorView={target:new THREE.Vector3(-.626,4.9,4.4),position:new THREE.Vector3(-6.8,10.5,9.4)};
  const storageBounds=new Map<string,THREE.Box3>(),storageLevels=new Map<string,number>();
  const localCamera=new THREE.Vector3(),closestPoint=new THREE.Vector3(),inverseNode=new THREE.Matrix4();
  function equipmentDistance(node:THREE.Object3D,box:THREE.Box3){inverseNode.copy(node.matrixWorld).invert();localCamera.copy(camera.position).applyMatrix4(inverseNode);box.clampPoint(localCamera,closestPoint).applyMatrix4(node.matrixWorld);return closestPoint.distanceTo(camera.position);}
  const pointers=new Set<number>(),hiddenIds=new Set<string>(),nodes=new Map<string,THREE.Object3D>(),meshes:THREE.Mesh[]=[];
  let catalog:ModelLabel[]=[...referenceEquipment];const labelAnchors=new Map<string,{node:THREE.Object3D;point:THREE.Vector3}>();const reduced=matchMedia('(prefers-reduced-motion: reduce)').matches;
  renderer.setPixelRatio(touchDevice?1:Math.min(devicePixelRatio,1.5));renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.15;
  host.appendChild(renderer.domElement);renderer.domElement.setAttribute('aria-label',`Interactive ${freefall?'free-fall':'davit'} lifeboat. Drag to rotate, pinch or scroll to zoom, and tap equipment to identify it.`);renderer.domElement.setAttribute('role','img');
  const scene=new THREE.Scene();scene.background=new THREE.Color('#071d2b');
  const camera=new THREE.PerspectiveCamera(40,1,.025,1000),controls=new OrbitControls(camera,renderer.domElement);
  controls.enableDamping=true;controls.dampingFactor=.08;controls.rotateSpeed=.7;controls.screenSpacePanning=true;controls.minDistance=.15;controls.maxDistance=90;controls.addEventListener('change',()=>{dirty=true;});
  scene.add(new THREE.HemisphereLight(0xffffff,0x6b8090,touchDevice?2.3:1.6));const key=new THREE.DirectionalLight(0xffffff,3);key.position.set(-10,20,15);scene.add(key);const fill=new THREE.DirectionalLight(0xd4e9ff,1.5);fill.position.set(15,8,-10);scene.add(fill);
  let environmentTarget:THREE.WebGLRenderTarget|undefined;
  if(!touchDevice){const pmrem=new THREE.PMREMGenerator(renderer),room=new RoomEnvironment();try{environmentTarget=pmrem.fromScene(room,.04);scene.environment=environmentTarget.texture;scene.environmentIntensity=.6;}catch{scene.environment=null;environmentTarget?.dispose();environmentTarget=undefined;}finally{room.dispose();pmrem.dispose();}}
  const center=new THREE.Vector3(),boatCenter=new THREE.Vector3(-.626,4.7,4.4),boatBounds=new THREE.Box3(new THREE.Vector3(-2.6,2.4,-1.4),new THREE.Vector3(1.43,7.4,10.38));let radius=9,shellOpacity=1,lastLabels=0,sceneReady=false,firstFrame=false;const originalPositions=new Map<THREE.Object3D,THREE.Vector3>();
  const ray=new THREE.Raycaster(),pointer=new THREE.Vector2(),worldLabel=new THREE.Vector3(),labelBox=new THREE.Box3();
  const idOf=(o:THREE.Object3D):string=>modelObjectId(o)||o.name;
  const idsOf=(id:string)=>catalog.find(e=>e.id===id||e.objects.includes(id))?.objects||[id];
  function resetCamera(){controls.target.copy(boatCenter);camera.position.copy(boatCenter).add(new THREE.Vector3(-1.25,.75,1.4).normalize().multiplyScalar(radius*2.4));controls.update();}
  function appearance(){dirty=true;const ids=idsOf(current);for(const m of meshes){const id=idOf(m);m.visible=!hiddenIds.has(id)&&(!focusMode||ids.includes(id))&&(nodes.get(id)?.userData.stowageVisible!==false||(focusMode&&ids.includes(id)));for(const mat of (Array.isArray(m.material)?m.material:[m.material]) as THREE.MeshStandardMaterial[]){mat.emissive.set(whole||(current&&ids.includes(id))?0x008cff:0x000000);mat.emissiveIntensity=0;}}}
  function select(id:string){sounds.play('inspect');current=id;setSelected(id);focusMode=false;setIsolated(false);idsOf(id).forEach(x=>hiddenIds.delete(x));setHidden(hiddenIds.size);appearance();navigateToSelection?.();}
  function clear(){current='';setSelected('');focusMode=false;setIsolated(false);appearance();}
  function disposeTree(tree:THREE.Object3D){const geos=new Set<THREE.BufferGeometry>(),mats=new Set<THREE.Material>(),tex=new Set<THREE.Texture>();tree.traverse(o=>{if(o instanceof THREE.Mesh){geos.add(o.geometry);for(const mat of Array.isArray(o.material)?o.material:[o.material]){mats.add(mat);for(const v of Object.values(mat))if(v instanceof THREE.Texture)tex.add(v);}}});geos.forEach(g=>g.dispose());mats.forEach(m=>m.dispose());const images=new Set<unknown>();tex.forEach(t=>{images.add(t.source.data);t.dispose();});images.forEach(img=>{if(typeof ImageBitmap!=='undefined'&&img instanceof ImageBitmap)img.close();});}
  const resize=new ResizeObserver(()=>{const w=host.clientWidth,h=host.clientHeight;const scale=Math.min(touchDevice?1:Math.min(devicePixelRatio,1.5),Math.sqrt((touchDevice?1000000:1800000)/Math.max(1,w*h)));renderer.setPixelRatio(scale);renderer.setSize(w,h);dirty=true;camera.aspect=w/Math.max(h,1);camera.updateProjectionMatrix();});resize.observe(host);
  function down(e:PointerEvent){pointers.add(e.pointerId);if(pointers.size>1)moved=true;else{downPoint={x:e.clientX,y:e.clientY};moved=false;}}
  function move(e:PointerEvent){if(Math.hypot(e.clientX-downPoint.x,e.clientY-downPoint.y)>5)moved=true;}
  function up(e:PointerEvent){const multi=pointers.size>1;pointers.delete(e.pointerId);if(moved||multi||e.button!==0)return;const r=renderer.domElement.getBoundingClientRect();pointer.set((e.clientX-r.left)/r.width*2-1,-(e.clientY-r.top)/r.height*2+1);ray.setFromCamera(pointer,camera);const hits=ray.intersectObjects(meshes,false).filter(h=>{const id=idOf(h.object),n=nodes.get(id);return h.object.visible&&!(modelShellIds.has(id)&&shellOpacity<.35&&!focusMode)&&!((n?.userData.storageCover||h.object.userData.compartmentCover)&&(storageLevels.get(h.object.userData.compartmentCover||id)||0)>.7&&!focusMode);});if(hits[0])select(idOf(hits[0].object));}
  function cancel(e:PointerEvent){pointers.delete(e.pointerId);moved=true;}
  renderer.domElement.addEventListener('pointerdown',down);renderer.domElement.addEventListener('pointermove',move);renderer.domElement.addEventListener('pointerup',up);renderer.domElement.addEventListener('pointercancel',cancel);
  const onContext=(e:Event)=>e.preventDefault();renderer.domElement.addEventListener('contextmenu',onContext);
  let startupTimer:ReturnType<typeof setTimeout>|undefined;
  function fail(message:string){if(disposed)return;clearTimeout(startupTimer);sceneReady=false;setLoaded(false);setFailed(true);setStatus(message);api.current=null;}
  function onLost(e:Event){e.preventDefault();contextLost=true;cancelAnimationFrame(frame);frame=0;abort.abort();fail('The 3D graphics connection was interrupted. Tap Retry loading to reopen the model.');}
  renderer.domElement.addEventListener('webglcontextlost',onLost);
  function visibility(){if(document.hidden){cancelAnimationFrame(frame);frame=0;}else if(!disposed&&!contextLost&&!frame){dirty=true;frame=requestAnimationFrame(animate);}}
  document.addEventListener('visibilitychange',visibility);
  const loader=new GLTFLoader();
  async function loadModel(){try{
   startupTimer=setTimeout(()=>{abort.abort();fail('Loading took too long. Check your connection, then tap Retry loading.');},60000);
   if(freefall){
    setStatus('Preparing the free-fall lifeboat and launch skid…');
    const {buildFreefallLifeboat,freefallShellIds}=await import('@/lib/freefall-lifeboat');
    if(disposed||contextLost||abort.signal.aborted)return;
    const built=buildFreefallLifeboat();model=built.root;catalog=built.equipment;modelShellIds=freefallShellIds;engineId='ff-engine';interiorView=built.interiorView;
    batchInterior(model);boatBounds.copy(built.boatBounds);boatCenter.copy(built.boatCenter);
   }else{
   setStatus('Downloading the lifeboat…');
   const response=await fetch(touchDevice?'/models/davit-lifeboat-mobile.glb':'/models/davit-lifeboat.glb',{signal:abort.signal});
   if(response.status===401||response.status===403)throw Error('Your session has expired. Reload this page and sign in again.');
   if(!response.ok)throw Error(`The model download failed (${response.status}). Tap Retry loading.`);
   const bytes=await response.arrayBuffer();if(disposed||contextLost||abort.signal.aborted)return;
   if(bytes.byteLength<12||new DataView(bytes).getUint32(0,true)!==0x46546c67)throw Error('The server did not return a valid model. Reload the page and try again.');
   setStatus('Opening the lifeboat and its equipment…');
   const g=await loader.parseAsync(bytes,'/models/');

   if(disposed||contextLost||abort.signal.aborted){disposeTree(g.scene);return;}
   model=g.scene;
   const interior=buildInterior();batchInterior(interior.root);model.add(interior.root);catalog=buildModelLabels(model,[...referenceEquipment,...interior.equipment]);
   }
   setEquipment(catalog);scene.add(model);
   const originals=new Set<THREE.Material>();
   model.traverse(o=>{if(o.userData.sourceObjectId)nodes.set(o.userData.sourceObjectId,o);if(o instanceof THREE.Mesh){meshes.push(o);const mats=(Array.isArray(o.material)?o.material:[o.material]).map(m=>{originals.add(m);const c=viewerMaterial(m as THREE.MeshStandardMaterial,touchDevice);if(c instanceof THREE.MeshStandardMaterial){const id=idOf(o),name=catalog.find(e=>e.id===id)?.name||'';if(modelShellIds.has(id)){c.roughness=id==='NODE254'?.18:.4;c.metalness=.025;}else if(id.startsWith('NODE')&&/bolt|nut|washer|shaft|pin|wire|sheave|hook|handle|hinge/i.test(name)){c.roughness=.32;c.metalness=.65;}}if(c.map)c.map.anisotropy=Math.min(touchDevice?1:4,renderer.capabilities.getMaxAnisotropy());return c;});o.material=Array.isArray(o.material)?mats:mats[0];}});originals.forEach(m=>m.dispose());
   model.updateMatrixWorld(true);
   for(const entry of catalog){const node=nodes.get(entry.id);if(!node)continue;const bounds=new THREE.Box3().setFromObject(node);const point=bounds.getCenter(new THREE.Vector3());point.y=bounds.max.y+.12;node.worldToLocal(point);labelAnchors.set(entry.id,{node,point});}
   for(const [id,node] of nodes){if(node.userData.storageCover||node.userData.storageId||node.userData.closeRevealDistance||node.userData.concealedByShell){const box=new THREE.Box3(),inverse=node.matrixWorld.clone().invert();node.traverse(child=>{if(child instanceof THREE.Mesh){child.geometry.computeBoundingBox();box.union(child.geometry.boundingBox!.clone().applyMatrix4(inverse.clone().multiply(child.matrixWorld)));}});storageBounds.set(id,box);if(node.userData.storageCover)storageLevels.set(id,0);}}
   const bounds=new THREE.Box3().setFromObject(model);bounds.getCenter(center);radius=bounds.getSize(new THREE.Vector3()).length()/2;resetCamera();dirty=true;sceneReady=true;setStatus('Preparing the 3D view…');
   for(const node of nodes.values())originalPositions.set(node,node.position.clone());
   const locate=()=>{if(!current)return;focusMode=false;setIsolated(false);appearance();const b=new THREE.Box3();idsOf(current).forEach(id=>{const o=nodes.get(id);if(o)b.expandByObject(o);});if(b.isEmpty())return;const c=b.getCenter(new THREE.Vector3());const node=nodes.get(current),stored=!!(node?.userData.storageId||node?.userData.storageCover||node?.userData.closeRevealDistance);const distance=stored?Math.max(.9,Math.min(2.1,b.getSize(new THREE.Vector3()).length()*1.35)):Math.max(.9,Math.min(12,b.getSize(new THREE.Vector3()).length()*1.7));const dir=camera.position.clone().sub(controls.target).normalize();if(stored){dir.y=Math.max(.3,dir.y);dir.normalize();}controls.target.copy(c);camera.position.copy(c).add(dir.multiplyScalar(distance));if(node?.userData.interior||stored){transparency='cutaway';setMode('cutaway');}controls.update();};
   navigateToSelection=locate;
   const explode=(v:boolean)=>{explodedView=v;setExploded(v);focusMode=false;setIsolated(false);for(const [node,pos] of originalPositions){node.position.copy(pos);if(v){const b=new THREE.Box3().setFromObject(node),c=b.getCenter(new THREE.Vector3());const dir=c.clone().sub(boatCenter);if(dir.length()<.1)dir.set(0,1,0);node.position.add(dir.normalize().multiplyScalar(node.userData.interior?.65:1));}}model!.updateMatrixWorld(true);appearance();};
   const focus=()=>{if(!current)return;focusMode=true;setIsolated(true);appearance();const box=new THREE.Box3();idsOf(current).forEach(id=>{const o=nodes.get(id);if(o)box.expandByObject(o);});if(box.isEmpty())return;const c=box.getCenter(new THREE.Vector3()),r=Math.max(box.getSize(new THREE.Vector3()).length()/2,.12);const dir=camera.position.clone().sub(controls.target).normalize();controls.target.copy(c);camera.position.copy(c).add(dir.multiplyScalar(r*3.2));controls.update();};
   api.current={select,focus,locate,explode,clear,reset(){explode(false);clear();hiddenIds.clear();setHidden(0);transparency='auto';setMode('auto');whole=false;setAllBlue(false);appearance();resetCamera();},view(name){focusMode=false;setIsolated(false);if(name==='Engine'){select(engineId);focus();return;}if(name==='Interior'){transparency='cutaway';setMode('cutaway');controls.target.copy(interiorView.target);camera.position.copy(interiorView.position);}else{const dirs:Record<string,THREE.Vector3>={Front:new THREE.Vector3(0,.15,1),Rear:new THREE.Vector3(0,.15,-1),Port:new THREE.Vector3(-1,.15,0),Starboard:new THREE.Vector3(1,.15,0),Top:new THREE.Vector3(0,1,.001),Bottom:new THREE.Vector3(0,-1,.001)};controls.target.copy(boatCenter);camera.position.copy(boatCenter).add(dirs[name].normalize().multiplyScalar(radius*2.4));}appearance();controls.update();},mode(v){transparency=v;setMode(v);dirty=true;lastLabels=0;},hide(){idsOf(current).forEach(id=>hiddenIds.add(id));setHidden(hiddenIds.size);clear();},restore(){hiddenIds.clear();setHidden(0);focusMode=false;setIsolated(false);appearance();},highlight(v){whole=v;setAllBlue(v);appearance();},zoom(f){camera.position.sub(controls.target).multiplyScalar(f).add(controls.target);controls.update();}};
  }catch(error){if(!disposed&&!contextLost&&!abort.signal.aborted){if(model){scene.remove(model);disposeTree(model);model=undefined;meshes.length=0;}console.error('Lifeboat startup failed',error);fail(error instanceof Error&&/session has expired|download failed|valid model/.test(error.message)?error.message:'The model could not be opened. Tap Retry loading. Your learning progress is safe.');}}}
  void loadModel();
  function animate(t:number){frame=0;if(disposed||contextLost||document.hidden)return;frame=requestAnimationFrame(animate);if(t-lastFrame<(touchDevice?1000/30:1000/60))return;lastFrame=t;controls.update();if(!sceneReady)return;
   let storageFading=false;
   for(const [id,localBox] of storageBounds){const node=nodes.get(id)!;if(!node.userData.storageCover)continue;const want=storageReveal(equipmentDistance(node,localBox)),previous=storageLevels.get(id)||0;const next=reduced?want:THREE.MathUtils.lerp(previous,want,.22);if(Math.abs(next-want)>.002)storageFading=true;storageLevels.set(id,next);}
   for(const [id,localBox] of storageBounds){const node=nodes.get(id)!;let shown=true;if(node.userData.storageId){shown=storedItemVisible(storageLevels.get(node.userData.storageId)||0,focusMode&&idsOf(current).includes(id));}else if(node.userData.closeRevealDistance){shown=equipmentDistance(node,localBox)<node.userData.closeRevealDistance||(focusMode&&idsOf(current).includes(id));}if(node.userData.concealedByShell&&shellOpacity>=.5&&!explodedView&&!(focusMode&&idsOf(current).includes(id)))shown=false;if(node.userData.stowageVisible!==shown){dirty=true;lastLabels=0;}node.userData.stowageVisible=shown;}
   const target=transparency==='solid'?1:transparency==='cutaway'?.045:closeViewOpacity(boatBounds.distanceToPoint(camera.position));const fading=Math.abs(shellOpacity-target)>.001;if(!dirty&&!fading&&!storageFading&&(!(current||whole)||reduced))return;shellOpacity=reduced?target:THREE.MathUtils.lerp(shellOpacity,target,.18);dirty=false;
   const ids=idsOf(current);for(const m of meshes){const id=idOf(m),isSelected=!!current&&ids.includes(id),node=nodes.get(id);m.visible=!hiddenIds.has(id)&&(!focusMode||isSelected)&&(node?.userData.stowageVisible!==false||(focusMode&&isSelected));for(const mat of (Array.isArray(m.material)?m.material:[m.material]) as THREE.MeshStandardMaterial[]){const base=mat.userData.baseOpacity??1;const opacity=focusMode&&isSelected?base:(node?.userData.storageCover||m.userData.compartmentCover)?base*(1-.96*(storageLevels.get(m.userData.compartmentCover||id)||0)):modelShellIds.has(id)?Math.min(base,shellOpacity):base;mat.opacity=opacity;const tr=opacity<.99;if(mat.transparent!==tr){mat.transparent=tr;mat.needsUpdate=true;}mat.depthWrite=!tr;m.renderOrder=tr?2:0;if(isSelected||whole)mat.emissiveIntensity=reduced?.6:.4+.35*(.5+.5*Math.sin(t*.0035));}}
   if(tag.current){if(current){labelBox.makeEmpty();ids.forEach(id=>{const o=nodes.get(id);if(o)labelBox.expandByObject(o);});labelBox.getCenter(worldLabel);worldLabel.y=labelBox.max.y+.15;worldLabel.project(camera);const visible=nodes.get(current)?.userData.stowageVisible!==false&&!labelBox.isEmpty()&&worldLabel.z>-1&&worldLabel.z<1&&Math.abs(worldLabel.x)<.94&&Math.abs(worldLabel.y)<.88;tag.current.style.display=visible?'block':'none';tag.current.style.left=`${(worldLabel.x*.5+.5)*100}%`;tag.current.style.top=`${(-worldLabel.y*.5+.5)*100}%`;}else tag.current.style.display='none';}
   if(t-lastLabels>100){lastLabels=t;const occupied:{x:number;y:number;w:number;h:number}[]=[];
    // Prioritize the selected item. Other labels appear as space permits; every
    // item remains available in All Parts, even in a crowded overview.
    const entries=[...labelRefs.current].sort(([a],[b])=>Number(b===current)-Number(a===current)||Number(catalog.find(e=>e.id===a)?.unverified||false)-Number(catalog.find(e=>e.id===b)?.unverified||false));
    for(const [id,el] of entries){const anchor=labelAnchors.get(id);if(!anchor)continue;
     const a=anchor.point.clone().applyMatrix4(anchor.node.matrixWorld).project(camera);
     let visible=anchor.node.userData.stowageVisible!==false&&!hiddenIds.has(id)&&(!focusMode||idsOf(current).includes(id))&&a.z>-1&&a.z<1&&Math.abs(a.x)<.95&&Math.abs(a.y)<.88;
     const x=(a.x*.5+.5)*host.clientWidth,y=(-a.y*.5+.5)*host.clientHeight;
     const w=160,h=60,rect={x:x-w/2,y:y-h,w,h};
     if(visible&&occupied.some(r=>rect.x<r.x+r.w+5&&rect.x+w+5>r.x&&rect.y<r.y+r.h+5&&rect.y+h+5>r.y))visible=false;
     if(visible)occupied.push(rect);
     el.style.display=visible?'block':'none';el.style.left=`${x}px`;el.style.top=`${y}px`;
    }
   }
   try{renderer.render(scene,camera);if(!firstFrame&&!contextLost){firstFrame=true;clearTimeout(startupTimer);setLoaded(true);setStatus('Ready');}}catch{contextLost=true;cancelAnimationFrame(frame);frame=0;fail('The 3D view was interrupted. Tap Retry loading to reopen it.');}
  }frame=requestAnimationFrame(animate);
  return()=>{disposed=true;clearTimeout(startupTimer);abort.abort();cancelAnimationFrame(frame);document.removeEventListener('visibilitychange',visibility);renderer.domElement.removeEventListener('webglcontextlost',onLost);resize.disconnect();controls.dispose();api.current=null;if(model)disposeTree(model);environmentTarget?.dispose();renderer.dispose();renderer.forceContextLoss();renderer.domElement.remove();};
 },[retry,freefall]);
 return <section className={`inspection-workspace ${selected?'has-selection':''}`} ref={wrap} aria-label="Lifeboat equipment explorer">
 <div className="inspection-stage">
 <div className="model-canvas" ref={mount}/>
 <div className="equipment-tag" ref={tag} style={{display:'none'}}>{selectedName}</div>
 <div className="inspection-labels">{showLabels&&visibleEquipment.map(e=><button key={e.id} ref={el=>{if(el)labelRefs.current.set(e.id,el);else labelRefs.current.delete(e.id);}} style={{display:'none'}} aria-label={`Inspect ${e.name}${e.unverified?' (name unverified)':''}`} title={e.unverified?'Name unverified':e.name} aria-pressed={selected===e.id} onClick={()=>inspect(e.id)}>{e.name}{e.unverified&&<small>Name unverified</small>}</button>)}</div>
 <div className="inspection-search">
 <div className="inspection-model-picker" role="group" aria-label="Choose lifeboat model"><Button variant="ghost" aria-pressed={!freefall} onClick={()=>onCraft('davit')}>Davit lifeboat</Button><Button variant="ghost" aria-pressed={freefall} onClick={()=>onCraft('freefall')}>Free-fall lifeboat</Button>{freefall&&<span>Full model</span>}</div>
 <div className="inspection-search-row"><Search size={18}/><Input aria-label="Search survival craft equipment" placeholder="Search survival craft equipment…" value={query} onFocus={()=>setShowParts(true)} onChange={e=>{setQuery(e.target.value);setShowParts(true);api.current?.mode(mode);}}/><Button variant="ghost" size="icon" aria-label="Toggle equipment list" aria-expanded={showParts} onClick={()=>setShowParts(!showParts)}>{showParts?<X/>:<Layers/>}</Button></div>
 {showParts&&<div className="inspection-results" aria-label="Equipment search results"><div><strong>{visibleEquipment.length} labeled parts</strong><button onClick={()=>setShowParts(false)} aria-label="Close equipment list"><X size={16}/></button></div>{visibleEquipment.length?visibleEquipment.map(e=><button key={e.id} disabled={!loaded} onClick={()=>inspect(e.id)}><span>{e.name}<small>{categoryOf(e)}{e.unverified?' · Name unverified':''}</small></span>{trackingId(e)&&<i className={`status-dot ${statusOf(e)}`}/>}</button>):<p>No equipment matches your search.</p>}</div>}
 </div>
 {!loaded&&<div className="inspection-loading" role="status"><Box/><p>{status}</p>{failed&&<Button onClick={()=>{setFailed(false);setLoaded(false);setSelected('');setHidden(0);setIsolated(false);setExploded(false);setAllBlue(false);setMode('auto');setStatus('Loading your lifeboat…');setRetry(retry+1);}}>Retry loading</Button>}</div>}
 {loaded&&showLabels&&<div className="inspection-label-note">{freefall?'Zoom close to see inside · Inspect lockers to reveal supplies':'Zoom close to a locker to reveal its contents'} · {equipment.length} labeled parts</div>}
 <div className="inspection-controls">
 <Button variant="secondary" disabled={!loaded} onClick={()=>api.current?.reset()}><RotateCcw/>Reset</Button>
 <div className="inspection-zoom"><Button variant="secondary" size="icon" disabled={!loaded} aria-label="Zoom in" onClick={()=>api.current?.zoom(.8)}><ZoomIn/></Button><Button variant="secondary" size="icon" disabled={!loaded} aria-label="Zoom out" onClick={()=>api.current?.zoom(1.25)}><ZoomOut/></Button></div>
 <Button variant="secondary" disabled={!loaded} aria-pressed={exploded} onClick={()=>api.current?.explode(!exploded)}><Box/>{exploded?'Reassemble':'Explode'}</Button>
 <Button variant="secondary" disabled={!loaded} onClick={()=>setShowParts(!showParts)}><Layers/>All Parts</Button>
 <Button variant="secondary" disabled={!loaded} aria-pressed={allBlue} onClick={()=>api.current?.highlight(!allBlue)}><Scan/>Highlight all</Button>
 <Button variant="secondary" disabled={!loaded} aria-pressed={showLabels} onClick={()=>{setShowLabels(!showLabels);api.current?.mode(mode);}}><Scan/>{showLabels?'Hide Labels':'Show Labels'}</Button>
 <select aria-label="Exterior visibility" value={mode} disabled={!loaded} onChange={e=>api.current?.mode(e.target.value as Mode)}><option value="auto">Auto see-through</option><option value="cutaway">See inside</option><option value="solid">Solid exterior</option></select>
 <select aria-label="Camera view" value="" disabled={!loaded} onChange={e=>api.current?.view(e.target.value)}><option value="" disabled>Views</option>{['Interior','Engine','Front','Rear','Port','Starboard','Top','Bottom'].map(v=><option key={v}>{v}</option>)}</select>
 {(hidden>0||isolated)&&<Button variant="secondary" onClick={()=>api.current?.restore()}><Layers/>Restore all</Button>}
 <Button variant="secondary" size="icon" aria-label="Fullscreen explorer" onClick={()=>{if(document.fullscreenElement)void document.exitFullscreen();else void wrap.current?.requestFullscreen?.().catch(()=>{});}}><Maximize/></Button>
 </div>
 <details className="inspection-help"><summary>3D controls</summary><p>Drag — rotate<br/>Pinch apart / scroll — zoom in<br/>Right-drag — pan<br/>Tap equipment — inspect</p></details>
 </div>
 {selected&&<section className="inspection-dock" aria-label={`${selectedName} inspection`}>
 <header className="inspection-dock-header"><span className="inspection-part-icon"><Anchor/></span><div><h2>{selectedName}</h2><p>{item?categoryOf(item):'Reference model'}{item?.unverified?' · Name unverified':''}</p></div><Button variant="ghost" size="icon" aria-label={speaking?'Stop reading':'Read equipment information aloud'} onClick={speak}>{speaking?<VolumeX/>:<Volume2/>}</Button><Button variant="ghost" size="icon" aria-label="Close equipment inspection" onClick={()=>api.current?.clear()}><X/></Button></header>
 <div className="inspection-dock-body" key={selected}>
 <div className="inspection-locate"><Button onClick={()=>api.current?.locate()}><MapPin/>Locate on Model</Button><Button variant="outline" onClick={()=>api.current?.focus()}><Focus/>Focus</Button><Button variant="outline" aria-label="Hide selected equipment" onClick={()=>api.current?.hide()}><EyeOff/></Button></div>
 <section><h3><BookOpen/>What is it?</h3><p>{details?.meaning||(item?`${item.name} · ${categoryOf(item)}`:'An original model fitting whose equipment name has not yet been verified.')}</p></section>
 {item&&<><section><h3>Purpose & function</h3><p>{item.description}</p></section><section><h3><MapPin/>Where is it located?</h3><p>{item.location}</p>{item.stowage&&<p className="inspection-stowage">Stowed in: <strong>{item.stowage.name}</strong>. Contents are concealed at a distance and revealed for close inspection.</p>}</section><section><h3>Quantity / ratio</h3><p>{details?.quantity||'Craft-specific fitting or assembly; there is no universal per-person quantity. Confirm the approved inventory and drawings.'}</p>{details?.videoTime!==undefined&&<small>P = the lifeboat’s approved person capacity. Illustrated examples do not establish its capacity or complete stock. Baseline figures require checking against applicable amendments and the vessel’s approved inventory.</small>}</section>{details&&<><section><h3>How is it used?</h3><p>{details.use}</p></section><section><h3>Care & important limits</h3><p>{details.care}</p></section><section className="inspection-reference"><details><summary>Equipment reference notes</summary><p>{freefall?'This is an illustrative free-fall interior. Seating and storage positions are representative; stock and capacity follow the actual vessel’s approved arrangement.':'Storage positions are illustrative. Optional examples are labeled; the video is a learning reference, not an operating procedure.'}</p>{(details.videoTime!==undefined||details.standards)&&<a href={equipmentSource.url} target="_blank" rel="noopener noreferrer">{equipmentSource.label}</a>}{details.videoTime!==undefined&&<p><a href={`${videoSource}&t=${details.videoTime}s`} target="_blank" rel="noopener noreferrer">Video discussion · {Math.floor(details.videoTime/60)}:{String(details.videoTime%60).padStart(2,'0')}</a></p>}</details></section></>}{item.identification&&<section className="inspection-reference"><details><summary>Identification & references</summary><p>{item.identification}</p>{item.source==='Reference model'&&<p>References describe equipment types. Matching to this model uses its visible geometry and the supplied guide; it is not a manufacturer-approved parts list.</p>}<ul>{item.references?.map(ref=><li key={ref.url}><a href={ref.url} target="_blank" rel="noopener noreferrer">{ref.label}</a></li>)}</ul></details></section>}<section className="inspection-facts"><h3>Key facts</h3><ul><li>{item.unverified?'Original model fitting; equipment name not yet verified.':item.source==='Reference model'?'Part of your original lifeboat model.':'Added to the illustrative training model.'}</li><li>Use Focus to inspect this equipment separately.</li><li>{freefall?'The seat count and visible supplies do not establish a certified capacity or complete inventory.':'Your learning status changes only when you choose it.'}</li></ul></section><section className="inspection-safety"><h3>Safety & familiarization</h3><p>Use your lifeboat’s approved instructions for operation and inspection. Added equipment locations are illustrative and may differ from the actual craft.</p></section>{related.length>0&&<section><h3>Related components</h3><div className="inspection-related">{related.map(e=><button key={e.id} aria-label={`Inspect ${e.name}${e.unverified?' (name unverified)':''}`} title={e.unverified?'Name unverified':e.name} aria-pressed={selected===e.id} onClick={()=>inspect(e.id)}>{e.name}{e.unverified&&<small>Name unverified</small>}</button>)}</div></section>}{trackingId(item)&&onLearn&&<Button variant="outline" onClick={()=>onLearn(trackingId(item)!)}><BookOpen/>{freefall?'Open component lesson':'Open lesson & exercise'}</Button>}</>}
 </div>
 <footer className="inspection-status"><div><span>{freefall?'Free-fall learning status':'Your learning status'}</span><small role="status">{saving?'Saving…':saveMessage}</small></div>{item&&trackingId(item)&&onStatus?<div className="inspection-status-buttons">{[['not_yet','Not Yet'],['almost','Almost There'],['learned','Learned It']].map(([v,label])=><Button key={v} variant="outline" disabled={saving} aria-pressed={statusOf(item)===v} className={statusOf(item)===v?'chosen':''} onClick={async()=>{setSaveMessage('');const ok=await onStatus(trackingId(item)!,v);setSaveMessage(ok?'Saved to your account':'Could not save. Please try again.');}}><i className={`status-dot ${v}`}/>{label}</Button>)}</div>:<p>This additional fitting is not linked to a tracked lesson yet.</p>}</footer>
 </section>}
 </section>;
}
