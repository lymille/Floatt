import {getChatGPTUser} from '../../chatgpt-auth';
import {db} from '@/lib/store';
import {createPractice,type MatchMove,type PracticePayload} from '@/lib/practice';
import {practiceSummary} from '@/lib/practice-records';
export const dynamic='force-dynamic';
const json=(data:unknown,status=200)=>Response.json(data,{status,headers:{'Cache-Control':'no-store'}});
type Row={id:string;user_id:string;mode:string;craft:string;status:string;payload:string;answers:string;revision:number;score:number;total:number;moves:number;xp:number;created_at:string;completed_at:string|null};
const result=(a:Row)=>({id:a.id,mode:a.mode,craft:a.craft,status:a.status,revision:a.revision,score:a.score,total:a.total,moves:a.moves,xp:a.xp,date:a.completed_at});
function publicSession(a:Row){
 const p=JSON.parse(a.payload) as PracticePayload,answers=JSON.parse(a.answers),base=result(a);
 if(a.mode==='quiz'){
  const questions=p.questions!,done=Object.keys(answers).length;
  const review=questions.filter(q=>answers[q.id]).map(q=>({id:q.id,prompt:q.prompt,answer:q.choices.find(c=>c.id===answers[q.id])!.text,correct:q.choices.find(c=>c.id===q.correct)!.text,isCorrect:answers[q.id]===q.correct,explanation:q.explanation}));
  const current=questions[done];
  return {...base,answered:done,review,question:current?{id:current.id,prompt:current.prompt,category:current.category,craft:current.craft,choices:current.choices}:null};
 }
 const moves=answers as MatchMove[],pairs=p.pairs!,matched=pairs.filter(pair=>moves.some(m=>m.left===pair.left&&m.right===pair.right&&m.correct));
 return {...base,matched:matched.length,
  left:p.leftOrder!.map(id=>{const pair=pairs.find(p=>p.left===id)!;return {id,text:pair.name,craft:pair.craft,matched:matched.includes(pair)};}),
  right:p.rightOrder!.map(id=>{const pair=pairs.find(p=>p.right===id)!;return {id,text:pair.purpose,matched:matched.includes(pair)};}),
  lastMove:moves.at(-1)||null,
  review:a.status==='completed'?pairs.map(p=>({id:p.id,name:p.name,purpose:p.purpose})):[],
 };
}
async function records(uid:string,mode:string){
 const d=db();const active=await d.prepare("SELECT * FROM practice_sessions WHERE user_id=? AND mode=? AND status='in_progress'").bind(uid,mode).first<Row>();
 const recent=(await d.prepare("SELECT * FROM practice_sessions WHERE user_id=? AND mode=? AND status='completed' ORDER BY completed_at DESC LIMIT 8").bind(uid,mode).all()).results as Row[];
 return {session:active?publicSession(active):null,activeSession:active?publicSession(active):null,recent:recent.map(result),summary:await practiceSummary(uid)};
}
async function eligible(uid:string){return !!await db().prepare("SELECT id FROM attempts WHERE user_id=? AND kind='pre' AND status='completed'").bind(uid).first();}
export async function GET(request:Request){try{
 const user=await getChatGPTUser();if(!user)return json({error:'Please sign in to practice.'},401);
 if(!await eligible(user.userId))return json({error:'Complete your pre-test first.'},403);
 const params=new URL(request.url).searchParams,mode=params.get('mode');
 if(!['quiz','match'].includes(mode||''))return json({error:'Choose a practice activity.'},400);
 const data=await records(user.userId,mode!);const id=params.get('id');
 if(id){const a=await db().prepare('SELECT * FROM practice_sessions WHERE user_id=? AND id=? AND mode=?').bind(user.userId,id,mode).first<Row>();if(!a)return json({error:'Activity not found.'},404);return json({...data,session:publicSession(a)});}
 return json(data);
}catch(e){console.error(e);return json({error:'Your practice records are unavailable. Please try again.'},503);}}
export async function POST(request:Request){try{
 const user=await getChatGPTUser();if(!user)return json({error:'Please sign in to practice.'},401);
 if(request.headers.get('origin')!==new URL(request.url).origin)return json({error:'Use this learning site to save practice.'},403);
 if(!await eligible(user.userId))return json({error:'Complete your pre-test first.'},403);
 const b=await request.json() as any,uid=user.userId,d=db(),now=new Date().toISOString();
 if(b.action==='start'){
  if(!['quiz','match'].includes(b.mode)||!['both','davit','freefall'].includes(b.craft)||(b.mode==='quiz'&&![10,20].includes(b.count)))return json({error:'Choose a boat and a valid round length.'},400);
  const payload=createPractice(b.mode,b.craft,b.count);
  await d.prepare(`INSERT INTO practice_sessions (id,user_id,mode,craft,status,payload,answers,total,created_at) VALUES (?,?,?,?,'in_progress',?,?,?,?) ON CONFLICT DO NOTHING`).bind(crypto.randomUUID(),uid,b.mode,b.craft,JSON.stringify(payload),b.mode==='quiz'?'{}':'[]',b.mode==='quiz'?b.count:60,now).run();
  return json(await records(uid,b.mode));
 }
 if(typeof b.sessionId!=='string')return json({error:'Activity not found.'},404);
 const a=await d.prepare('SELECT * FROM practice_sessions WHERE user_id=? AND id=?').bind(uid,b.sessionId).first<Row>();
 if(!a)return json({error:'Activity not found.'},404);
 if(!['quiz','match'].includes(a.mode))return json({error:'This activity is no longer available.'},410);
 const response=async(row:Row)=>json({...await records(uid,row.mode),session:publicSession(row)});
 if(!['answer','match','abandon'].includes(b.action))return json({error:'Unknown practice action.'},400);
 if(a.status==='completed')return response(a);
 if(a.status!=='in_progress')return json({error:'This round has ended. Start a new round.'},409);
 const payload=JSON.parse(a.payload) as PracticePayload,answers=JSON.parse(a.answers);
 // Identical retries never award points or count a move a second time.
 if(b.action==='answer'&&a.mode==='quiz'&&Object.hasOwn(answers,b.questionId)&&answers[b.questionId]===b.answer)return response(a);
 if(b.action==='match'&&a.mode==='match'&&(answers as MatchMove[]).some(m=>m.id===b.moveId))return response(a);
 if(b.revision!==a.revision)return json({error:'This round changed in another tab. Reload the saved round to continue.'},409);
 let score=a.score,moves=a.moves,xp=0,status='in_progress';
 if(b.action==='abandon')status='abandoned';
 else if(b.action==='answer'&&a.mode==='quiz'){
  const q=payload.questions![Object.keys(answers).length];
  if(!q||q.id!==b.questionId||!q.choices.some(c=>c.id===b.answer))return json({error:'Choose one answer for the current question.'},400);
  answers[q.id]=b.answer;score+=Number(q.correct===b.answer);moves++;
  if(moves===payload.questions!.length){status='completed';xp=score*5+5;}
 }else if(b.action==='match'&&a.mode==='match'){
  if(typeof b.moveId!=='string'||!/^[a-zA-Z0-9-]{1,64}$/.test(b.moveId))return json({error:'Invalid move. Please select the pair again.'},400);
  const pairs=payload.pairs!,history=answers as MatchMove[],left=pairs.find(p=>p.left===b.left),right=pairs.find(p=>p.right===b.right);
  if(!left||!right||history.some(m=>m.correct&&(m.left===b.left||m.right===b.right)))return json({error:'Choose two cards that have not been matched.'},400);
  history.push({id:b.moveId,left:b.left,right:b.right,correct:left===right});moves++;
  score=Math.max(0,60-history.filter(m=>!m.correct).length*5);
  if(history.filter(m=>m.correct).length===6){status='completed';xp=Math.max(6,30-history.filter(m=>!m.correct).length*2);}
 }else return json({error:'That action does not belong to this activity.'},400);
 const saved=await d.prepare(`UPDATE practice_sessions SET answers=?,score=?,moves=?,xp=?,status=?,completed_at=?,revision=revision+1 WHERE user_id=? AND id=? AND status='in_progress' AND revision=?`).bind(JSON.stringify(answers),score,moves,xp,status,status==='completed'?now:null,uid,a.id,a.revision).run();
 if(!saved.meta.changes)return json({error:'This round changed in another tab. Reload the saved round to continue.'},409);
 if(status==='abandoned')return json(await records(uid,a.mode));
 return response({...a,answers:JSON.stringify(answers),score,moves,xp,status,completed_at:status==='completed'?now:null,revision:a.revision+1});
}catch(e){console.error(e);return json({error:'That move could not be saved. Keep your selection and try again.'},503);}}
