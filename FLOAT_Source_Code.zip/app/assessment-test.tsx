'use client';
import {useEffect,useRef,useState} from 'react';
import {ArrowRight,Check} from 'lucide-react';
import {sounds} from '@/lib/sound-effects';
import {Button} from '@/components/ui/button';
import {Card} from '@/components/ui/card';
import {Progress} from '@/components/ui/progress';
import {RadioGroup,RadioGroupItem} from '@/components/ui/radio-group';
import {Dialog,DialogContent,DialogHeader,DialogTitle,DialogDescription} from '@/components/ui/dialog';

export type AssessmentQuestion={id:string;prompt:string;category:string;choices:{id:string;text:string}[]};
type TestAttempt={id:string;kind:string;answers:Record<string,string>;questions?:AssessmentQuestion[]};
export default function AssessmentTest({attempt,busy,onSave,onSubmit}:{attempt:TestAttempt;busy:boolean;onSave:(answers:Record<string,string>)=>Promise<boolean>;onSubmit:(answers:Record<string,string>)=>Promise<void>}){
 const [index,setIndex]=useState(0),[answers,setAnswers]=useState(attempt.answers),[unsaved,setUnsaved]=useState(false),[confirm,setConfirm]=useState(false);
 const saving=useRef(false);
 const questions=attempt.questions!,q=questions[index],total=questions.length,answered=Object.keys(answers).length;
 const title=attempt.kind==='pre'?'Pre-test':'Post-test';
 useEffect(()=>{setAnswers(attempt.answers);setUnsaved(false);setIndex(0)},[attempt.id]);
 async function choose(value:string){
  if(saving.current||busy)return;
  saving.current=true;sounds.play('select');
  const next={...answers,[q.id]:value};setAnswers(next);setUnsaved(true);
  try{if(await onSave(next))setUnsaved(false)}finally{saving.current=false}
 }
 return <div className="test-shell">
  <div className="test-heading"><div><p className="eyebrow">{title.toUpperCase()} · YOUR KNOWLEDGE</p><h1>One question at a time.</h1></div><span className="save-status" aria-live="polite">{busy?'Saving…':unsaved?'Unsaved answer':'Saved to your account'}</span></div>
  <div className="test-progress"><span>{answered} of {total} answered</span><Progress value={answered/total*100} aria-label={`${answered} of ${total} questions answered`}/></div>
  <Card className="question-card"><span className="question-label">QUESTION {index+1} / {total} · {q.category}</span><h2>{q.prompt}</h2>
   <RadioGroup value={answers[q.id]||''} onValueChange={choose} disabled={busy}>{q.choices.map((c,i)=><label key={c.id} className={`answer-option ${answers[q.id]===c.id?'selected':''}`}><RadioGroupItem value={c.id}/><span className="letter">{'ABCD'[i]}</span><span>{c.text}</span></label>)}</RadioGroup>
   <div className="test-buttons"><Button variant="outline" disabled={busy||index===0} onClick={()=>setIndex(index-1)}>Previous</Button>{unsaved&&<Button variant="outline" disabled={busy} onClick={async()=>{if(await onSave(answers))setUnsaved(false)}}>Retry saving</Button>}<Button disabled={busy||index===total-1} onClick={()=>setIndex(index+1)}>Next <ArrowRight/></Button></div>
  </Card>
  <div className="question-map" aria-label="Jump to question">{questions.map((item,i)=><button key={item.id} className={`${answers[item.id]?'answered':''} ${index===i?'current':''}`} disabled={busy} aria-label={`Question ${i+1}, ${answers[item.id]?'answered':'unanswered'}`} aria-current={index===i?'step':undefined} onClick={()=>setIndex(i)}>{i+1}</button>)}</div>
  <div className="submit-row"><p>{answered===total?'All questions answered. You can review them before submitting.':`Answer ${total-answered} more question${total-answered===1?'':'s'} to finish.`}</p><Button disabled={busy||answered!==total} onClick={()=>setConfirm(true)}>Finish {title.toLowerCase()}<Check/></Button></div>
  <Dialog open={confirm} onOpenChange={setConfirm}><DialogContent><DialogHeader><DialogTitle>Submit your {title.toLowerCase()}?</DialogTitle><DialogDescription>Your score and certificate will be saved. This completed test can’t be retaken or edited.</DialogDescription></DialogHeader><div className="actions"><Button variant="outline" disabled={busy} onClick={()=>setConfirm(false)}>Keep reviewing</Button><Button disabled={busy} onClick={async()=>{await onSubmit(answers);setConfirm(false)}}>{busy?'Submitting…':'Submit assessment'}</Button></div></DialogContent></Dialog>
 </div>;
}
