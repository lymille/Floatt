# Put F L O A T on GitHub from your iPad

## 1. Save the download

Download `FLOAT_Source_Code.zip` from ChatGPT and save it in the Files app. Keep this original ZIP. Tap the ZIP in Files to extract a folder and read these instructions.

## 2. Upload the ZIP as a backup

1. Open your GitHub repository in Safari or Chrome.
2. Choose **Add file → Upload files → choose your files**.
3. Select `FLOAT_Source_Code.zip` from Files.
4. Enter a message such as **Add F L O A T source backup**, then commit the upload (or propose a branch and merge it if your repository requires that).

For a brand-new repository, create it with a README first so the normal repository controls appear. The ZIP is below GitHub's 25 MiB browser-upload limit.

At this point GitHub stores the ZIP as a backup. It does not automatically extract the archive into editable source files or publish the website.

## 3. Optional: turn the ZIP into an editable source repository

This method works in a browser and preserves the complete folder structure, including files whose names begin with a dot. Use a **new repository containing only its starter README and the uploaded ZIP**. The extraction below replaces that starter README. Do not run it over an unrelated existing project.

1. In that repository, choose **Code → Codespaces**, then create a Codespace on the branch containing the ZIP. Codespaces availability and included usage depend on your GitHub account. Check the displayed billing information before creating it.
2. When the browser editor opens, choose **Terminal → New Terminal** from its menu.
3. Run the following commands from the repository's root folder, one line at a time. Stop if any command reports an error:

```bash
python3 -m zipfile -e FLOAT_Source_Code.zip .
git status --short
git rm -- FLOAT_Source_Code.zip
git add .
git commit -m "Import F L O A T application source"
git push
```

The `git rm` step removes the backup ZIP from the working branch after extraction; your original download and the earlier GitHub commit still retain it. Review the `git status` output before committing. If your repository protects the branch, push an import branch and open a pull request instead.

4. Return to GitHub and refresh the repository. It should now contain `app`, `lib`, `public`, `scripts`, `package.json`, and the other project files. `public/models` must contain both davit GLB files. The free-fall model is built from the files in `lib`.
5. Stop the Codespace when finished.

You can also extract and commit these files with a Git client on a computer. Preserve the directories and the configuration files whose names begin with a dot. Do not upload every file into a single flat folder.

## Uploading is different from hosting

The exported source includes server routes and a database integration. A GitHub repository holds the code; hosting it as a working website requires a compatible server environment, authentication, and database configuration. GitHub Pages alone is not sufficient for this application. Read the main README before setting up another host.

Your current live F L O A T website remains available at:

https://survival-craft-learning.kingkofndf.chatgpt.site

## Official instructions

- [Open ZIP files on iPad](https://support.apple.com/en-us/102532)
- [Upload files to GitHub](https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository)
- [Create a Codespace for a repository](https://docs.github.com/en/codespaces/developing-in-a-codespace/creating-a-codespace-for-a-repository)
