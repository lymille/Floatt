// The real practice handlers, real migrations and a SQLite-backed D1 adapter.
// These disposable learners never touch production records.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import ts from 'typescript';
const temp=await fs.mkdtemp(path.resolve('.practice-check-'));
let fixture;
try{
 const compile=s=>ts.transpileModule(s,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
 for(const name of ['curriculum','questions','practice','practice-records']){
  let s=await fs.readFile(`lib/${name}.ts`,'utf8');
  for(const n of ['curriculum','questions','practice','practice-records'])s=s.replaceAll(`'./${n}'`,`'./${n}.mjs'`);
  s=s.replace("'./store'","'./fixture.mjs'").replace("'./practice-freefall.json'","'./practice-freefall.json' with {type:'json'}");
  await fs.writeFile(path.join(temp,`${name}.mjs`),compile(s));
 }
 for(const name of ['practice-freefall','freefall-part-ids','freefall-components'])await fs.copyFile(`lib/${name}.json`,path.join(temp,`${name}.json`));
 await fs.writeFile(path.join(temp,'fixture.mjs'),`
 import {DatabaseSync} from 'node:sqlite';import {fileURLToPath} from 'node:url';
 let raw,userId='practice-a';
 export function reopen(){raw?.close();raw=new DatabaseSync(fileURLToPath(new URL('records.sqlite',import.meta.url)));}
 export function close(){raw?.close();}export function setUser(id){userId=id;}
 export async function getChatGPTUser(){return userId?{userId,email:userId+'@example.test'}:null;}
 export function exec(sql){raw.exec(sql);}export function seed(sql,...args){return raw.prepare(sql).run(...args);}
 export function row(sql,...args){return raw.prepare(sql).get(...args);}
 export function db(){return {prepare(sql){return {bind(...args){return {async first(){return raw.prepare(sql).get(...args)||null;},async all(){return {results:raw.prepare(sql).all(...args)};},async run(){return {meta:{changes:Number(raw.prepare(sql).run(...args).changes)}};}};}};}};}
 reopen();
 `);
 for(const name of ['practice','learning','certificate']){
  let s=await fs.readFile(`app/api/${name}/route.ts`,'utf8');
  s=s.replace("'../../chatgpt-auth'","'./fixture.mjs'").replace("'@/lib/store'","'./fixture.mjs'");
  for(const n of ['practice','practice-records','curriculum','questions'])s=s.replace(`'@/lib/${n}'`,`'./${n}.mjs'`);
  s=s.replace("'@/lib/freefall-part-ids.json'","'./freefall-part-ids.json' with {type:'json'}");
  s=s.replace("'@/lib/freefall-components.json'","'./freefall-components.json' with {type:'json'}");
  await fs.writeFile(path.join(temp,`${name}-route.mjs`),compile(s));
 }
 fixture=await import(pathToFileURL(path.join(temp,'fixture.mjs')));
 for(const file of (await fs.readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())fixture.exec(await fs.readFile('drizzle/'+file,'utf8'));
 const api=await import(pathToFileURL(path.join(temp,'practice-route.mjs'))),learning=await import(pathToFileURL(path.join(temp,'learning-route.mjs')));
 const certificate=await import(pathToFileURL(path.join(temp,'certificate-route.mjs')));
 const {bank,createOrder}=await import(pathToFileURL(path.join(temp,'questions.mjs')));
 assert.equal(createOrder('pre').length,35);assert.equal(createOrder('post').length,70);
 assert.equal(new Set(bank.filter(q=>q.kind==='post').map(q=>q.id)).size,70);
 assert.equal(new Set(bank.filter(q=>q.kind==='post').map(q=>q.correct)).size,70,'The post-test covers 70 different items');
 for(const q of bank){assert.equal(q.choices.length,4);assert.equal(new Set(q.choices.map(c=>c.id)).size,4);assert.equal(q.choices.filter(c=>c.id===q.correct).length,1);}
 const {createPractice,practiceItems}=await import(pathToFileURL(path.join(temp,'practice.mjs')));
 const allowed=JSON.parse(await fs.readFile('lib/freefall-part-ids.json','utf8'));
 for(const p of practiceItems.filter(p=>p.craft==='freefall'))assert.ok(allowed.includes(p.id),p.id);
 for(const craft of ['both','davit','freefall']){
  const q=createPractice('quiz',craft,20);assert.equal(q.questions.length,20);assert.equal(new Set(q.questions.map(q=>q.name.toLowerCase())).size,20);
  for(const item of q.questions){assert.equal(item.choices.length,4);assert.equal(new Set(item.choices.map(c=>c.text)).size,4);assert.ok(item.choices.some(c=>c.id===item.correct));if(craft!=='both')assert.equal(item.craft,craft);}
  const g=createPractice('match',craft,6);assert.equal(g.pairs.length,6);assert.equal(new Set(g.pairs.map(p=>p.purpose)).size,6);assert.deepEqual(new Set(g.leftOrder),new Set(g.pairs.map(p=>p.left)));
 }
 for(const uid of ['practice-a','practice-b','before-pre']){
  fixture.seed('INSERT INTO profiles (user_id,name,created_at) VALUES (?,?,?)',uid,uid,'2026-01-01');
  if(uid!=='before-pre')fixture.seed("INSERT INTO attempts (id,user_id,kind,status,question_order,answers,created_at) VALUES (?,?,'pre','completed','[]','{}',?)",uid+'-pre',uid,'2026-01-01');
 }
 const url='https://practice.example.test/api/practice';
 const get=(mode='quiz',id='')=>api.GET(new Request(`${url}?mode=${mode}${id?'&id='+id:''}`));
 const post=(body,origin=new URL(url).origin)=>api.POST(new Request(url,{method:'POST',headers:{Origin:origin,'Content-Type':'application/json'},body:JSON.stringify(body)}));
 const ok=async promise=>{const response=await promise,j=await response.json();assert.equal(response.status,200,JSON.stringify(j));return j;};
 fixture.setUser(null);assert.equal((await get()).status,401);fixture.setUser('before-pre');assert.equal((await get()).status,403);
 fixture.setUser('practice-a');assert.equal((await post({action:'start'},'https://elsewhere.test')).status,403);
 for(const craft of ['bad',''])assert.equal((await post({action:'start',mode:'quiz',craft,count:10})).status,400);
 assert.equal((await post({action:'start',mode:'quiz',craft:'both',count:200})).status,400);
 const fixtures={lobbyQuiz:await ok(get()),lobbyMatch:await ok(get('match'))};
 let state=await ok(post({action:'start',mode:'quiz',craft:'davit',count:10}));const quizId=state.session.id;fixtures.quizStart=state;
 assert.equal(state.session.question.correct,undefined);assert.equal(state.session.payload,undefined);assert.equal(state.session.review.length,0);
 assert.equal((await ok(post({action:'start',mode:'quiz',craft:'freefall',count:20}))).session.id,quizId,'Starting twice must resume the existing round');
 fixture.setUser('practice-b');assert.equal((await get('quiz',quizId)).status,404);assert.equal((await post({action:'answer',sessionId:quizId})).status,404);fixture.setUser('practice-a');
 let firstBody;
 for(let i=0;i<10;i++){
  const s=state.session,p=JSON.parse(fixture.row('SELECT payload FROM practice_sessions WHERE id=?',s.id).payload),q=p.questions[i];
  const answer=i===0?q.choices.find(c=>c.id!==q.correct).id:q.correct;
  const body={action:'answer',sessionId:s.id,revision:s.revision,questionId:q.id,answer,score:9999,xp:9999};
  if(i===0){assert.equal((await post({...body,answer:'made-up'})).status,400);firstBody=body;}
  state=await ok(post(body));
  if(i===0){fixtures.quizFeedback=state;assert.equal(state.session.score,0);assert.equal(state.session.review[0].isCorrect,false);assert.equal((await ok(post(body))).session.moves,1);fixture.reopen();assert.equal((await ok(get())).session.answered,1);assert.equal((await post({...body,questionId:state.session.question.id,answer:state.session.question.choices[0].id})).status,409);}
 }
 fixtures.quizComplete=state;assert.equal(state.session.score,9);assert.equal(state.session.xp,50);assert.equal(state.summary.quizCount,1);assert.equal(state.summary.perfectQuiz,false);assert.equal(state.session.review.length,10);
 assert.equal((await ok(post(firstBody))).summary.xp,50,'Retrying completion must not duplicate XP');
 state=await ok(post({action:'start',mode:'match',craft:'freefall'}));fixtures.matchStart=state;const matchId=state.session.id;
 const pairs=JSON.parse(fixture.row('SELECT payload FROM practice_sessions WHERE id=?',matchId).payload).pairs;
 const wrong={action:'match',sessionId:matchId,revision:0,left:pairs[0].left,right:pairs[1].right,moveId:crypto.randomUUID()};
 state=await ok(post(wrong));fixtures.matchWrong=state;assert.equal(state.session.moves,1);assert.equal(state.session.score,55);assert.equal(state.session.matched,0);
 assert.equal((await ok(post(wrong))).session.moves,1);fixture.reopen();state=await ok(get('match'));assert.equal(state.session.moves,1);
 for(const p of pairs){state=await ok(post({action:'match',sessionId:matchId,revision:state.session.revision,left:p.left,right:p.right,moveId:crypto.randomUUID()}));if(state.session.matched===1){fixtures.matchCorrect=state;assert.equal((await post({action:'match',sessionId:matchId,revision:state.session.revision,left:p.left,right:p.right,moveId:crypto.randomUUID()})).status,400);}}
 fixtures.matchComplete=state;assert.equal(state.session.moves,7);assert.equal(state.session.score,55);assert.equal(state.session.xp,28);assert.equal(state.summary.xp,78);assert.equal(state.summary.gameCount,1);
 const gameReplay=await ok(post({action:'match',sessionId:matchId,revision:7,left:pairs[0].left,right:pairs[0].right,moveId:crypto.randomUUID()}));assert.equal(gameReplay.summary.xp,78);
 // Perfect new rounds award the badges; previous results remain immutable.
 state=await ok(post({action:'start',mode:'quiz',craft:'freefall',count:20}));
 const qq=JSON.parse(fixture.row('SELECT payload FROM practice_sessions WHERE id=?',state.session.id).payload).questions;
 for(const q of qq)state=await ok(post({action:'answer',sessionId:state.session.id,revision:state.session.revision,questionId:q.id,answer:q.correct}));
 assert.equal(state.session.score,20);assert.equal(state.session.xp,105);assert.equal(state.summary.perfectQuiz,true);
 state=await ok(post({action:'start',mode:'match',craft:'both'}));
 const pp=JSON.parse(fixture.row('SELECT payload FROM practice_sessions WHERE id=?',state.session.id).payload).pairs;
 for(const p of pp)state=await ok(post({action:'match',sessionId:state.session.id,revision:state.session.revision,left:p.left,right:p.right,moveId:crypto.randomUUID()}));
 assert.equal(state.session.score,60);assert.equal(state.summary.perfectGame,true);assert.equal(state.summary.xp,213);
 state=await ok(post({action:'start',mode:'quiz',craft:'both',count:10}));state=await ok(post({action:'abandon',sessionId:state.session.id,revision:0}));assert.equal(state.session,null);assert.equal(state.summary.quizCount,2);
 const l=await ok(learning.GET(new Request('https://practice.example.test/api/learning')));assert.equal(l.unlocked,true);assert.equal(l.progress.length,0);assert.equal(l.freefallProgress.length,0);assert.equal(l.attempts.length,1);assert.equal(l.practice.xp,213);
 // Post-test is available with no lessons learned, after an explicit readiness confirmation.
 const learningUrl='https://practice.example.test/api/learning';
 const learnPost=body=>learning.POST(new Request(learningUrl,{method:'POST',headers:{Origin:new URL(learningUrl).origin,'Content-Type':'application/json'},body:JSON.stringify(body)}));
 const learnGet=()=>learning.GET(new Request(learningUrl));
 fixture.setUser('before-pre');assert.equal((await learnPost({action:'start',kind:'post',ready:true})).status,403);
 fixture.setUser('practice-a');assert.equal('refresherUnlocked' in l,false);
 assert.equal((await get('refresher')).status,400);assert.equal((await post({action:'start',mode:'refresher'})).status,400);
 assert.equal((await learnPost({action:'start',kind:'post'})).status,400);
 let learner=await ok(learnPost({action:'start',kind:'post',ready:true}));
 const assessment=learner.attempts.find(a=>a.kind==='post');assert.equal(assessment.questions.length,70);assert.equal(assessment.total,70);assert.equal(learner.progress.length,0);
 assert.equal((await ok(learnPost({action:'start',kind:'post'}))).attempts.find(a=>a.kind==='post').id,assessment.id,'The post-test may only be started once');
 const postAnswers=Object.fromEntries(assessment.questions.map((q,i)=>[q.id,i<35?bank.find(b=>b.id===q.id).correct:q.choices.find(c=>c.id!==bank.find(b=>b.id===q.id).correct).id]));
 learner=await ok(learnPost({action:'answers',attemptId:assessment.id,revision:0,answers:postAnswers}));
 learner=await ok(learnPost({action:'submit',attemptId:assessment.id,revision:1,answers:postAnswers}));
 const completedPost=learner.attempts.find(a=>a.kind==='post');assert.equal(completedPost.score,35);assert.equal(completedPost.total,70);assert.equal(completedPost.evaluation,'Needs more learning','35/70 must be graded as 50 percent');assert.equal(completedPost.name,'practice-a');assert.equal('refresherUnlocked' in learner,false);
 assert.equal(learner.progress.length,0);fixtures.postComplete=learner;
 const download=await certificate.GET(new Request('https://practice.example.test/api/certificate?id='+assessment.id));assert.equal(download.status,200);const svg=await download.text();assert.ok(svg.includes('70-question'));assert.ok(svg.includes('35 / 70 · 50%'));
 // Removed activities stay unavailable to older clients without deleting saved data.
 assert.equal((await get('refresher')).status,400);
 assert.equal((await post({action:'start',mode:'refresher',craft:'both',count:70})).status,400);
 for(const status of ['in_progress','completed']){
  const id='removed-refresher-'+status,payload=createPractice('quiz','both',70);
  fixture.seed("INSERT INTO practice_sessions (id,user_id,mode,craft,status,payload,answers,total,score,created_at,completed_at) VALUES (?,?,'refresher','both',?,?,'{}',70,0,'2026-01-01',?)",id,'practice-a',status,JSON.stringify(payload),status==='completed'?'2026-01-01':null);
  const saved=fixture.row('SELECT * FROM practice_sessions WHERE id=?',id);
  assert.equal((await get('refresher',id)).status,400);
  assert.equal((await get('quiz',id)).status,404);
  for(const action of ['answers','submit','abandon'])assert.equal((await post({action,sessionId:id,revision:0,answers:{}})).status,410);
  assert.deepEqual(fixture.row('SELECT * FROM practice_sessions WHERE id=?',id),saved);
  fixture.setUser('practice-b');assert.equal((await post({action:'submit',sessionId:id,revision:0,answers:{}})).status,404);fixture.setUser('practice-a');
 }
 learner=await ok(learnGet());assert.deepEqual(learner.attempts,fixtures.postComplete.attempts);assert.equal(learner.practice.xp,213);
 state=await ok(get());assert.equal(state.session,null);assert.equal(state.recent.length,2);assert.ok(state.recent.every(s=>s.mode==='quiz'));
 state=await ok(get('match'));assert.equal(state.recent.length,2);assert.ok(state.recent.every(s=>s.mode==='match'));
 fixture.setUser('practice-b');state=await ok(get());assert.equal(state.recent.length,0);assert.equal(state.summary.xp,0);assert.equal(state.session,null);
 // Preserve legacy completed certificates; expand unfinished tests without losing saved answers.
 const oldOrder=createOrder('post').filter(q=>Number(q.id.split('-')[1])<=35),oldAnswers={[oldOrder[0].id]:oldOrder[0].choices[0]};
 for(const uid of ['legacy-done','legacy-open']){
  fixture.seed('INSERT INTO profiles (user_id,name,created_at) VALUES (?,?,?)',uid,uid,'2026-01-01');
  fixture.seed("INSERT INTO attempts (id,user_id,kind,status,question_order,answers,created_at) VALUES (?,?,'pre','completed',?,'{}','2026-01-01')",uid+'-pre',uid,JSON.stringify(createOrder('pre')));
  fixture.seed("INSERT INTO attempts (id,user_id,kind,status,question_order,answers,revision,score,evaluation,certificate_name,completed_at,created_at) VALUES (?,?,'post',?,?,?,4,28,'Good understanding',?,'2026-01-01','2026-01-01')",uid+'-post',uid,uid==='legacy-done'?'completed':'in_progress',JSON.stringify(oldOrder),JSON.stringify(oldAnswers),uid);
 }
 fixture.setUser('legacy-done');const oldCompleted=fixture.row('SELECT * FROM attempts WHERE id=?','legacy-done-post');
 learner=await ok(learnGet());assert.equal(learner.attempts.find(a=>a.kind==='pre').total,35);assert.equal(learner.attempts.find(a=>a.kind==='post').total,35);assert.deepEqual(fixture.row('SELECT * FROM attempts WHERE id=?','legacy-done-post'),oldCompleted);
 const oldSvg=await (await certificate.GET(new Request('https://practice.example.test/api/certificate?id=legacy-done-post'))).text();assert.ok(oldSvg.includes('35-question'));assert.ok(oldSvg.includes('28 / 35 · 80%'));
 fixture.setUser('legacy-open');learner=await ok(learnGet());let expanded=learner.attempts.find(a=>a.kind==='post');assert.equal(expanded.total,70);assert.equal(expanded.revision,5);assert.deepEqual(expanded.answers,oldAnswers);assert.deepEqual(expanded.questions.slice(0,35).map(q=>({id:q.id,choices:q.choices.map(c=>c.id)})),oldOrder);
 assert.equal((await learnPost({action:'answers',attemptId:expanded.id,revision:4,answers:oldAnswers})).status,409);assert.equal((await ok(learnGet())).attempts.find(a=>a.kind==='post').revision,5,'Expansion must be idempotent');
 // A legacy browser that submits before loading the new site must also receive the new question count.
 fixture.seed('UPDATE attempts SET question_order=?,revision=4 WHERE id=?',JSON.stringify(oldOrder),expanded.id);
 assert.equal((await learnPost({action:'submit',attemptId:expanded.id,revision:4,answers:oldAnswers})).status,409);assert.equal((await ok(learnGet())).attempts.find(a=>a.kind==='post').total,70);
 if(process.argv[2])await fs.writeFile(process.argv[2],JSON.stringify(fixtures,null,2));
 console.log('PASS: quizzes and games, private sessions, scoring, resume, history, XP, badges, removed activity rejection, immediate 70-question post-test, readiness confirmation, legacy expansion and preserved certificates.');
}finally{fixture?.close();await fs.rm(temp,{recursive:true,force:true});}
