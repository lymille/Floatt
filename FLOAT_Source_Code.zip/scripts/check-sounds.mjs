// Exercise audio scheduling with a Web Audio adapter, without playing test sounds.
import assert from 'node:assert/strict';
import fs from 'node:fs/promises';
import ts from 'typescript';
const compiled=ts.transpileModule(await fs.readFile('lib/sound-effects.ts','utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
const {SoundEffects,scoreSound,soundPlans,readSoundPreferences,SOUND_STORAGE_KEY,controlSound}=await import('data:text/javascript;base64,'+Buffer.from(compiled).toString('base64'));
for(const [score,total,cue] of [[21,35,'celebrate'],[20,35,'sad'],[42,70,'celebrate'],[41,70,'sad'],[36,60,'celebrate'],[35,60,'sad'],[59.99,100,'sad'],[0,70,'sad'],[70,70,'celebrate'],[1,0,null],[NaN,70,null],[71,70,null]])assert.equal(scoreSound(score,total),cue);
assert.deepEqual(readSoundPreferences('broken'),{enabled:true,volume:.45});
assert.deepEqual(readSoundPreferences('{"enabled":false,"volume":4}'),{enabled:false,volume:1});
assert.equal(new Set(Object.values(soundPlans).map(p=>JSON.stringify(p))).size,Object.keys(soundPlans).length,'Each action has a distinct musical cue');
for(const plan of Object.values(soundPlans))for(const n of plan){assert.ok(n.hz>0&&n.at>=0&&n.length>0&&n.level>0);assert.ok(n.at+n.length<1.5,'Effects remain short');}

let clock=1000,created=0;
const realNow=Date.now;Date.now=()=>clock;
class Param{value=0;setValueAtTime(v){this.value=v}exponentialRampToValueAtTime(v){this.value=v}}
class Gain{gain=new Param();connect(){}disconnect(){this.disconnected=true}}
class Oscillator{frequency=new Param();stops=[];connect(){}disconnect(){this.disconnected=true}start(at){this.started=at}stop(at){this.stops.push(at);if(at===undefined)this.onended?.()}}
class Context{
 state='suspended';currentTime=1;destination={};voices=[];resumes=0;
 constructor(){created++;Context.last=this}
 createGain(){return new Gain()}
 createOscillator(){const v=new Oscillator();this.voices.push(v);return v}
 resume(){this.resumes++;this.state='running';return Promise.resolve()}
 suspend(){this.state='suspended';return Promise.resolve()}
 close(){this.state='closed';return Promise.resolve()}
}
const storage=new Map();globalThis.window={AudioContext:Context,localStorage:{getItem:key=>storage.get(key)||null,setItem:(key,value)=>storage.set(key,value)}};globalThis.document={hidden:false};
const flush=async()=>{await Promise.resolve();await Promise.resolve()};
try{
 const s=new SoundEffects();s.loadPreferences();assert.equal(created,0,'Rendering the site never creates audio or autoplays');
 s.play('menu');await flush();let c=Context.last;assert.equal(c.resumes,1);assert.equal(c.voices.length,2);
 s.play('menu');assert.equal(c.voices.length,2,'Rapid duplicate control events are suppressed');
 clock+=100;s.playResultOnce('post:one',42,70);assert.equal(c.voices.length,9);assert.ok(c.voices.slice(0,2).every(v=>v.disconnected),'Result music replaces the preceding click');
 s.playResultOnce('post:one',42,70);assert.equal(c.voices.length,9,'Retries do not repeat celebrations');
 clock+=100;s.play('tap');assert.equal(c.voices.length,9,'Ordinary clicks do not drown out a result');
 s.setPreferences({enabled:false});assert.ok(c.voices.every(v=>v.disconnected),'Muting stops playing and future scheduled notes');
 const mutedCount=c.voices.length;s.play('sad');assert.equal(c.voices.length,mutedCount);assert.equal(JSON.parse(storage.get(SOUND_STORAGE_KEY)).enabled,false);
 const restored=new SoundEffects();restored.loadPreferences();restored.play('tap');assert.equal(created,1,'A saved mute choice is applied before playback');
 s.setPreferences({enabled:true,volume:.3});clock+=100;s.playResultOnce('post:two',41,70);assert.equal(c.voices.length,mutedCount+3);
 s.pause();assert.equal(c.state,'suspended');assert.ok(c.voices.every(v=>v.disconnected));
 c.state='interrupted';clock+=1500;s.play('inspect');await flush();assert.equal(c.state,'running');assert.equal(c.resumes,2,'iOS interrupted contexts resume on the next action');
 document.hidden=true;clock+=100;const hiddenCount=c.voices.length;s.play('tap');assert.equal(c.voices.length,hiddenCount);document.hidden=false;
 s.pause();clock+=100;s.play('menu');s.setPreferences({enabled:false});await flush();assert.equal(c.voices.length,hiddenCount,'Muting cancels playback waiting for resume');
 s.setPreferences({enabled:true,volume:0});clock+=100;s.play('confirm');assert.equal(c.voices.length,hiddenCount,'Zero volume is silent');
 s.dispose();assert.equal(c.state,'closed');
 window.AudioContext=undefined;const unsupported=new SoundEffects();assert.doesNotThrow(()=>unsupported.play('tap'));
 window.AudioContext=class{constructor(){throw Error('Audio unavailable')}};clock+=100;assert.doesNotThrow(()=>unsupported.play('tap'));
 const control=(attributes={},selectors=[],disabled=false)=>({textContent:attributes.text||'',getAttribute:key=>attributes[key]??null,closest:selector=>selector.startsWith('[disabled')?(disabled?{}:null):attributes['data-sound']?{getAttribute:()=>attributes['data-sound']}:null,matches:selector=>selectors.some(s=>selector.split(',').includes(s))});
 assert.equal(controlSound(control({},['.nav-button'])),'menu');assert.equal(controlSound(control({},['[role="radio"]'])),'select');assert.equal(controlSound(control({'aria-label':'Close equipment inspection'})),'back');assert.equal(controlSound(control({'aria-label':'Zoom in'})),'zoom-in');assert.equal(controlSound(control({text:'Submit assessment'})),'confirm');assert.equal(controlSound(control({'data-sound':'none'})),null);assert.equal(controlSound(control({},['.nav-button'],true)),null);
 // Check that result playback is connected to successful writes, not result-history loading.
 for(const file of ['app/learning-app.tsx','app/practice-activities.tsx']){const source=await fs.readFile(file,'utf8');assert.ok(source.includes('sounds.playResultOnce'),file);}
 console.log('PASS: exact 60% threshold, distinct short cues, no autoplay, deduplicated results, mute/volume persistence, interrupted-context recovery, background silence and safe unavailable-audio fallback.');
}finally{Date.now=realNow;delete globalThis.window;delete globalThis.document}
