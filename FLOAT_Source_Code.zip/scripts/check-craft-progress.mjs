// Exercise the actual learning API with SQLite-backed records and isolated test users.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import ts from 'typescript';
const temp=await fs.mkdtemp(path.resolve('.progress-check-'));
let fixture;
try{
 const compile=source=>ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
 for(const name of ['curriculum','questions'])await fs.writeFile(path.join(temp,`${name}.mjs`),compile((await fs.readFile(`lib/${name}.ts`,'utf8')).replace("'./curriculum'","'./curriculum.mjs'").replace("'./practice-freefall.json'","'./practice-freefall.json' with {type:'json'}")));
 await fs.writeFile(path.join(temp,'practice-records.mjs'),compile((await fs.readFile('lib/practice-records.ts','utf8')).replace("'./store'","'./fixture.mjs'")));
 await fs.copyFile('lib/practice-freefall.json',path.join(temp,'practice-freefall.json'));
 await fs.copyFile('lib/freefall-part-ids.json',path.join(temp,'freefall-part-ids.json'));
 await fs.copyFile('lib/freefall-components.json',path.join(temp,'freefall-components.json'));
 await fs.writeFile(path.join(temp,'fixture.mjs'),`
 import {DatabaseSync} from 'node:sqlite';
 import {fileURLToPath} from 'node:url';
 let raw;let userId='learner-a';
 export function reopen(){raw?.close();raw=new DatabaseSync(fileURLToPath(new URL('records.sqlite',import.meta.url)));}
 export function close(){raw?.close();}
 export function setUser(id){userId=id;}
 export async function getChatGPTUser(){return userId?{userId,email:userId+'@example.test'}:null;}
 export function exec(sql){return raw.exec(sql);}
 export function seed(sql,...args){return raw.prepare(sql).run(...args);}
 export function db(){return {prepare(sql){return {bind(...args){return {
  async first(){return raw.prepare(sql).get(...args)||null;},
  async all(){return {results:raw.prepare(sql).all(...args)};},
  async run(){const result=raw.prepare(sql).run(...args);return {meta:{changes:Number(result.changes)}};}
 }}}}};}
 reopen();
 `);
 const source=(await fs.readFile('app/api/learning/route.ts','utf8'))
  .replace("'../../chatgpt-auth'","'./fixture.mjs'").replace("'@/lib/store'","'./fixture.mjs'")
  .replace("'@/lib/practice-records'","'./practice-records.mjs'").replace("'@/lib/curriculum'","'./curriculum.mjs'").replace("'@/lib/questions'","'./questions.mjs'")
  .replace("'@/lib/freefall-part-ids.json'","'./freefall-part-ids.json' with {type:'json'}")
  .replace("'@/lib/freefall-components.json'","'./freefall-components.json' with {type:'json'}");
 await fs.writeFile(path.join(temp,'route.mjs'),compile(source));
 fixture=await import(pathToFileURL(path.join(temp,'fixture.mjs')));
 for(const file of (await fs.readdir('drizzle')).filter(f=>f.endsWith('.sql')).sort())fixture.exec(await fs.readFile('drizzle/'+file,'utf8'));
 const {parts}=await import(pathToFileURL(path.join(temp,'curriculum.mjs')));
 const ff=JSON.parse(await fs.readFile('lib/freefall-part-ids.json','utf8'));
 const api=await import(pathToFileURL(path.join(temp,'route.mjs')));
 const url='https://learning.example.test/api/learning';
 const get=()=>api.GET(new Request(url));
 const post=body=>api.POST(new Request(url,{method:'POST',headers:{Origin:new URL(url).origin,'Content-Type':'application/json'},body:JSON.stringify(body)}));
 const learn=(partId,status='learned')=>post({action:'part',partId,status});
 for(const uid of ['learner-a','learner-b','before-pre']){
  fixture.seed('INSERT INTO profiles (user_id,name,created_at) VALUES (?,?,?)',uid,uid,'2026-01-01');
  if(uid!=='before-pre')fixture.seed("INSERT INTO attempts (id,user_id,kind,status,question_order,answers,created_at) VALUES (?,?,'pre','completed','[]','{}',?)",uid+'-pre',uid,'2026-01-01');
 }
 fixture.setUser(null);assert.equal((await get()).status,401);
 fixture.setUser('before-pre');assert.equal((await learn(ff[0])).status,403);
 const gated=await (await get()).json();assert.deepEqual(gated.parts,[]);assert.deepEqual(gated.freefallParts,[]);
 fixture.setUser('learner-a');
 assert.equal((await learn(parts[0].id)).status,200);
 assert.equal((await learn('ff-engine')).status,200);
 assert.equal((await learn('ff-helm-seat','almost')).status,200);
 assert.equal((await learn('ff-not-a-real-part')).status,404);
 assert.equal((await learn('ff-engine','invalid')).status,400);
 fixture.reopen();let state=await (await get()).json();
 assert.equal(state.progress.length,1);assert.equal(state.freefallProgress.length,2);
 assert.equal(state.freefallTotal,ff.length);assert.equal(state.progress[0].part_id,parts[0].id);
 assert.equal(state.parts.length,61);assert.equal(state.freefallParts.length,ff.length);
 assert.deepEqual(state.freefallParts.map(p=>p.id).sort(),[...ff].sort(),'Components must expose every saved free-fall model ID exactly once');
 for(const part of state.freefallParts){assert.ok(part.name&&part.purpose&&part.category&&part.location&&part.quantity&&part.use&&part.care);assert.ok(!state.parts.some(p=>p.id===part.id));}
 assert.equal(state.freefallParts.find(p=>p.id==='ff-engine').stowage.name,'Aft engine enclosure');
 assert.equal(state.freefallProgress.find(p=>p.part_id==='ff-engine').status,'learned');
 assert.equal(state.freefallProgress.find(p=>p.part_id==='ff-helm-seat').status,'almost');
 assert.equal(state.unlocked,true);
 await learn('ff-engine','not_yet');state=await (await get()).json();assert.equal(state.freefallProgress.find(p=>p.part_id==='ff-engine').status,'not_yet');
 // A second account has a separate record even for the same modeled part.
 fixture.setUser('learner-b');state=await (await get()).json();assert.equal(state.progress.length,0);assert.equal(state.freefallProgress.length,0);
 await learn('ff-engine');fixture.setUser('learner-a');state=await (await get()).json();assert.equal(state.freefallProgress.find(p=>p.part_id==='ff-engine').status,'not_yet');
 // All free-fall items learned must not count toward the 61 davit progress totals.
 const save="INSERT INTO progress (user_id,part_id,status,exercise_passed,viewed,updated_at) VALUES (?,?,'learned',0,1,'2026-01-01') ON CONFLICT(user_id,part_id) DO UPDATE SET status='learned'";
 for(const id of ff)fixture.seed(save,'learner-a',id);
 state=await (await get()).json();assert.equal(state.freefallProgress.filter(p=>p.status==='learned').length,ff.length);assert.equal(state.progress.length,1);assert.equal(state.unlocked,true);
 for(const p of parts)fixture.seed(save,'learner-a',p.id);
 state=await (await get()).json();assert.equal(state.progress.length,61);assert.equal(state.unlocked,true,'Post-test access must not depend on exercises');
 for(const p of parts)fixture.seed('UPDATE progress SET exercise_passed=1 WHERE user_id=? AND part_id=?','learner-a',p.id);
 state=await (await get()).json();assert.equal(state.unlocked,true);
 await learn('ff-engine','not_yet');state=await (await get()).json();assert.equal(state.unlocked,true,'Free-fall status must not change post-test access');
 console.log('Craft progress passed: saved statuses survive reopening storage, totals stay separate, account isolation and immediate post-test access hold.');
}finally{fixture?.close();await fs.rm(temp,{recursive:true,force:true});}
