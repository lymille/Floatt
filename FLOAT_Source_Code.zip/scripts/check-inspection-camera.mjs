// Exercise the viewer's actual handlers without requiring a WebGL context.
import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
import ts from 'typescript';
import * as THREE from 'three';
const source=await fs.readFile('app/lifeboat-viewer.tsx','utf8');
const ast=ts.createSourceFile('viewer.tsx',source,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
const functions=new Map(),variables=new Map();let apiAssignment;
function visit(node){
 if(ts.isFunctionDeclaration(node)&&node.name)functions.set(node.name.text,node.getText(ast));
 if(ts.isVariableDeclaration(node)&&ts.isIdentifier(node.name))variables.set(node.name.text,node.getText(ast));
 if(ts.isBinaryExpression(node)&&node.left.getText(ast)==='api.current'&&ts.isObjectLiteralExpression(node.right))apiAssignment=node.getText(ast);
 ts.forEachChild(node,visit);
}visit(ast);
const handlers=[...['resetCamera','appearance','select','clear','equipmentDistance','up'].map(n=>functions.get(n)),...['locate','focus'].map(n=>'const '+variables.get(n)+';'),apiAssignment+';'].join('\n');
assert.ok(apiAssignment);
const js=ts.transpileModule(handlers,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText;
new Function('THREE','assert',`
 let current='',focusMode=false,whole=false,dirty=false,transparency='auto',lastLabels=0;
 let selected='',isolated=false,navigateToSelection;
 const setSelected=v=>selected=v,setIsolated=v=>isolated=v;
 const setHidden=()=>{},setMode=()=>{},setAllBlue=()=>{},explode=()=>{};
 const api={current:null},hiddenIds=new Set(),nodes=new Map(),storageLevels=new Map();
 const boatCenter=new THREE.Vector3(-.626,4.7,4.4),radius=9;
 const camera=new THREE.PerspectiveCamera();camera.position.set(-15,12,24);
 const controls={target:boatCenter.clone(),update(){}};
 const engineId='locker',interiorView={target:new THREE.Vector3(0,3,-1),position:new THREE.Vector3(-4,7,3)};
 const localCamera=new THREE.Vector3(),closestPoint=new THREE.Vector3(),inverseNode=new THREE.Matrix4();
 const pointers=new Set(),pointer=new THREE.Vector2(),ray=new THREE.Raycaster();let moved=false,shellOpacity=1;
 const modelShellIds=new Set(['exterior']);
 const renderer={domElement:{getBoundingClientRect:()=>({left:0,top:0,width:100,height:100})}};
 for(const [id,x,inside] of [['exterior',2,false],['locker',-1,true]]){
  const mesh=new THREE.Mesh(new THREE.BoxGeometry(.3,.4,.5),new THREE.MeshStandardMaterial());
  mesh.position.set(x,5,6);mesh.name=id;mesh.userData.interior=inside;
  if(inside)mesh.userData.storageCover=id;
  mesh.updateMatrixWorld(true);nodes.set(id,mesh);
 }
 const meshes=[...nodes.values()],idOf=o=>o.name,idsOf=id=>[id];
 ${js}
 navigateToSelection=locate;
 const pose=()=>JSON.stringify([camera.position.toArray(),controls.target.toArray()]);
 const start=pose();
 api.current.select('exterior');assert.notEqual(pose(),start,'Selecting an exterior fitting must also zoom to it');
 assert.ok(controls.target.distanceTo(nodes.get('exterior').position)<1e-8);
 let closePose=pose();api.current.clear();assert.equal(pose(),closePose,'Closing inspection must preserve the camera');
 assert.equal(selected,'');assert.equal(isolated,false);
 api.current.select('locker');assert.notEqual(pose(),closePose,'Selecting the next item must move to it');
 closePose=pose();api.current.clear();assert.equal(pose(),closePose,'Closing a locker must retain the close view');
 api.current.select('exterior');api.current.focus();assert.equal(nodes.get('locker').visible,false);
 closePose=pose();api.current.clear();assert.equal(pose(),closePose,'Exiting isolated focus must not reset the camera');
 assert.equal(nodes.get('locker').visible,true);assert.equal(isolated,false);
 camera.position.add(new THREE.Vector3(.2,.3,.4));closePose=pose();api.current.clear();assert.equal(pose(),closePose,'Closing must also retain a manually adjusted viewpoint');
 api.current.reset();assert.notEqual(pose(),closePose,'Explicit Reset must still return to the overview');
 assert.ok(controls.target.equals(boatCenter));
 api.current.view('Interior');assert.equal(transparency,'cutaway');assert.ok(camera.position.equals(interiorView.position));assert.ok(controls.target.equals(interiorView.target));
 api.current.view('Engine');assert.equal(selected,engineId);assert.equal(isolated,true);
 closePose=pose();api.current.clear();assert.equal(pose(),closePose,'Closing the free-fall engine view must retain the camera');
 // A point in the large world AABB can still be far from a sloped compartment.
 const compartment=new THREE.Group();compartment.rotation.x=Math.PI/4;compartment.updateMatrixWorld(true);
 const localBox=new THREE.Box3(new THREE.Vector3(-.3,-.1,-2),new THREE.Vector3(.3,.1,2));
 camera.position.set(0,1.35,1.35);
 assert.ok(localBox.clone().applyMatrix4(compartment.matrixWorld).containsPoint(camera.position));
 assert.ok(equipmentDistance(compartment,localBox)>1.8,'Sloped storage must not reveal early because its world box is oversized');
 camera.position.set(0,.15,0).applyMatrix4(compartment.matrixWorld);assert.ok(Math.abs(equipmentDistance(compartment,localBox)-.05)<1e-8);
 // Use actual ray intersections to check shell/locker picking during a reveal.
 camera.position.set(0,0,0);camera.lookAt(0,0,-1);camera.updateMatrixWorld(true);
 nodes.get('exterior').position.set(0,0,-2);nodes.get('locker').position.set(0,0,-4);
 for(const n of nodes.values()){n.visible=true;n.updateMatrixWorld(true);}
 navigateToSelection=undefined;
 up({clientX:50,clientY:50,button:0,pointerId:1});assert.equal(selected,'exterior','Opaque shell should still be selectable');
 shellOpacity=.045;up({clientX:50,clientY:50,button:0,pointerId:1});assert.equal(selected,'locker','Transparent shell must allow picking the interior');
 const content=new THREE.Mesh(new THREE.BoxGeometry(.2,.2,.2),new THREE.MeshStandardMaterial());content.name='content';content.position.set(0,0,-5);content.updateMatrixWorld(true);nodes.set('content',content);meshes.push(content);
 storageLevels.set('locker',1);up({clientX:50,clientY:50,button:0,pointerId:1});assert.equal(selected,'content','Open storage cover must allow picking its contents');
`)(THREE,assert);
console.log('Inspection: camera retention, interior/engine views, sloped storage distances, transparent-shell and open-locker picking passed');
