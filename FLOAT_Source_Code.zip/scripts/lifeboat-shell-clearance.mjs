import assert from 'node:assert/strict';
import * as THREE from 'three';

// Check real GLB surfaces, not the hull's rectangular bounding box: that box
// misses the narrowing bow and sloping canopy which caused bench protrusions.
export function checkBenchClearance(root,bytes){
 const jsonLength=bytes.readUInt32LE(12);
 const gltf=JSON.parse(bytes.subarray(20,20+jsonLength).toString());
 const bin=bytes.subarray(28+jsonLength),cells=new Map(),cellSize=.2;
 function values(index){
  const a=gltf.accessors[index],v=gltf.bufferViews[a.bufferView];
  const ArrayType={5123:Uint16Array,5125:Uint32Array,5126:Float32Array}[a.componentType];
  assert.ok(ArrayType);assert.ok(!v.byteStride,'Interleaved GLB needs an accessor reader');
  const count=a.count*({SCALAR:1,VEC3:3}[a.type]);
  const start=(v.byteOffset||0)+(a.byteOffset||0);
  return new ArrayType(bin.buffer.slice(bin.byteOffset+start,bin.byteOffset+start+count*ArrayType.BYTES_PER_ELEMENT));
 }
 for(const node of gltf.nodes){
  // NODE248 also contains interior deck faces; those are not the enclosure.
  if(!['NODE250','NODE260'].includes(node.extras?.sourceObjectId))continue;
  assert.ok(!node.matrix&&!node.translation&&!node.rotation&&!node.scale,'Shell coordinates must be in model space');
  for(const primitive of gltf.meshes[node.mesh].primitives){
   const p=values(primitive.attributes.POSITION),indices=primitive.indices===undefined?null:values(primitive.indices);
   for(let i=0;i<(indices?.length??p.length/3);i+=3){
    const tri=[0,1,2].map(j=>Array.from(p.slice((indices?.[i+j]??i+j)*3,(indices?.[i+j]??i+j)*3+3)));
    const [a,b,c]=tri,dy=b[1]-a[1],dz=b[2]-a[2],ey=c[1]-a[1],ez=c[2]-a[2],den=dy*ez-dz*ey;
    if(Math.abs(den)<1e-10)continue;
    const face={a,b,c,dy,dz,ey,ez,den};
    const minY=Math.floor(Math.min(...tri.map(p=>p[1]))/cellSize),maxY=Math.floor(Math.max(...tri.map(p=>p[1]))/cellSize);
    const minZ=Math.floor(Math.min(...tri.map(p=>p[2]))/cellSize),maxZ=Math.floor(Math.max(...tri.map(p=>p[2]))/cellSize);
    for(let y=minY;y<=maxY;y++)for(let z=minZ;z<=maxZ;z++){const key=y+','+z;const list=cells.get(key)||[];list.push(face);cells.set(key,list);}
   }
  }
 }
 const ids=['benches','center-bench','harnesses','center-belts','interior-rails','buoyancy','interior-floor','oars','boat-hook','second-boat-hook','oars-clips','boat-hook-clips','second-boat-hook-clips','thermal-locker','utility-locker'];
 const report=[];root.updateMatrixWorld(true);
 for(const id of ids){
  const group=root.getObjectByName(id);assert.ok(group);let minimum=Infinity,worst,checked=0;
  function check(point){
   const side=point.x<-.626?-1:1;
   const candidates=cells.get(Math.floor(point.y/cellSize)+','+Math.floor(point.z/cellSize))||[];
   let boundary=Infinity;
   for(const {a,b,c,dy,dz,ey,ez,den} of candidates){
    const py=point.y-a[1],pz=point.z-a[2],u=(py*ez-pz*ey)/den,v=(dy*pz-dz*py)/den;
    if(u< -1e-6||v< -1e-6||u+v>1+1e-6)continue;
    const x=(a[0]+u*(b[0]-a[0])+v*(c[0]-a[0])+.626)*side;
    if(x>0)boundary=Math.min(boundary,x);
   }
   assert.ok(Number.isFinite(boundary),`${id}: no enclosing shell at ${point.toArray()}`);
   const clearance=boundary-Math.abs(point.x+.626);checked++;
   if(clearance<minimum){minimum=clearance;worst=point.toArray();}
  }
  group.traverse(mesh=>{
   if(!mesh.isMesh)return;
   const p=mesh.geometry.getAttribute('position'),index=mesh.geometry.index;
   for(let i=0;i<(index?.count??p.count);i+=3){
    const vertices=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(p,index?index.getX(i+j):i+j).applyMatrix4(mesh.matrixWorld));
    vertices.forEach(check);
    check(vertices[0].clone().add(vertices[1]).add(vertices[2]).multiplyScalar(1/3));
    // Also sample long face edges: the end vertices alone miss bow collisions.
    for(let j=0;j<3;j++)for(const t of [.25,.5,.75])check(vertices[j].clone().lerp(vertices[(j+1)%3],t));
   }
  });
  report.push({id,clearance:Number(minimum.toFixed(4)),point:worst,checked});
 }
 const failures=report.filter(r=>r.clearance<.02);
 assert.equal(failures.length,0,`Bench assembly must remain inside the shell with clearance: ${JSON.stringify(failures)}`);
 console.log(`Shell clearance: ${report.length} fitted groups checked on both sides; minimum ${Math.min(...report.map(r=>r.clearance)).toFixed(4)}`);
}
