import * as THREE from 'three';
import assert from 'node:assert/strict';

// Test the real lofted shell, including its taper. A rectangular bounding box
// cannot catch seats protruding through the bow or sloping canopy.
export function checkFreefallClearance(root,boatPose){
 const inverse=boatPose.clone().invert(),cells=new Map(),cellSize=.18;
 root.updateMatrixWorld(true);
 for(const group of root.children){
  if(!['ff-hull','ff-canopy','ff-wheelhouse'].includes(group.userData.sourceObjectId))continue;
  group.traverse(mesh=>{
   if(!mesh.isMesh)return;
   const pos=mesh.geometry.attributes.position,index=mesh.geometry.index,matrix=inverse.clone().multiply(mesh.matrixWorld);
   for(let i=0;i<(index?.count??pos.count);i+=3){
    const [a,b,c]=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(pos,index?index.getX(i+j):i+j).applyMatrix4(matrix));
    const dy=b.y-a.y,dz=b.z-a.z,ey=c.y-a.y,ez=c.z-a.z,den=dy*ez-dz*ey;if(Math.abs(den)<1e-10)continue;
    const f={a,b,c,dy,dz,ey,ez,den};
    for(let y=Math.floor(Math.min(a.y,b.y,c.y)/cellSize);y<=Math.floor(Math.max(a.y,b.y,c.y)/cellSize);y++)for(let z=Math.floor(Math.min(a.z,b.z,c.z)/cellSize);z<=Math.floor(Math.max(a.z,b.z,c.z)/cellSize);z++){const key=y+','+z,list=cells.get(key)||[];list.push(f);cells.set(key,list);}
   }
  });
 }
 const failures=[];let checked=0,minimum=Infinity;
 for(const group of root.children){
  if(!group.userData.interior)continue;
  let worst=Infinity,point;
  function check(p){
   const faces=cells.get(Math.floor(p.y/cellSize)+','+Math.floor(p.z/cellSize))||[];let low=Infinity,high=-Infinity;
   for(const {a,b,c,dy,dz,ey,ez,den} of faces){const y=p.y-a.y,z=p.z-a.z,u=(y*ez-z*ey)/den,v=(dy*z-dz*y)/den;if(u< -1e-6||v< -1e-6||u+v>1+1e-6)continue;const x=a.x+u*(b.x-a.x)+v*(c.x-a.x);low=Math.min(low,x);high=Math.max(high,x);}
   const clearance=Math.min(p.x-low,high-p.x);checked++;if(clearance<worst){worst=clearance;point=p.toArray();}
  }
  group.traverse(mesh=>{
   if(!mesh.isMesh)return;const pos=mesh.geometry.attributes.position,index=mesh.geometry.index,matrix=inverse.clone().multiply(mesh.matrixWorld);
   for(let i=0;i<(index?.count??pos.count);i+=3){const vs=[0,1,2].map(j=>new THREE.Vector3().fromBufferAttribute(pos,index?index.getX(i+j):i+j).applyMatrix4(matrix));vs.forEach(check);check(vs[0].clone().add(vs[1]).add(vs[2]).multiplyScalar(1/3));for(let j=0;j<3;j++)for(const t of [.25,.5,.75])check(vs[j].clone().lerp(vs[(j+1)%3],t));}
  });
  if(worst<.008)failures.push({id:group.userData.sourceObjectId,clearance:worst,point});minimum=Math.min(minimum,worst);
 }
 assert.equal(failures.length,0,`Interior must fit inside the actual free-fall shell: ${JSON.stringify(failures)}`);
 console.log(`Free-fall clearance: ${checked} surface samples, minimum ${minimum.toFixed(4)}`);
}
