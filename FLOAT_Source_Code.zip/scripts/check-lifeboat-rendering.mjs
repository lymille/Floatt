// Structural regression check: optimization must preserve equipment and geometry.
import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import assert from 'node:assert/strict';
import ts from 'typescript';
import * as THREE from 'three';
import {checkBenchClearance} from './lifeboat-shell-clearance.mjs';
const temp=await fs.mkdtemp(path.resolve('.render-check-'));
try {
 for(const name of ['curriculum','lifeboat-interior','lifeboat-rendering','lifeboat-labels','lifeboat-equipment-details','lifeboat-fitting']){
  const source=(await fs.readFile(`lib/${name}.ts`,'utf8')).replace("'./curriculum'","'./curriculum.mjs'").replace("'./lifeboat-fitting'","'./lifeboat-fitting.mjs'").replace("from './model-identifications.json'","from './model-identifications.json' with {type:'json'}");
  await fs.writeFile(path.join(temp,`${name}.mjs`),ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
 }
 await fs.copyFile('lib/model-identifications.json',path.join(temp,'model-identifications.json'));
 const {buildInterior,referenceEquipment}=await import(pathToFileURL(path.join(temp,'lifeboat-interior.mjs')));
 const {batchInterior,viewerMaterial}=await import(pathToFileURL(path.join(temp,'lifeboat-rendering.mjs')));
 const {equipmentDetails}=await import(pathToFileURL(path.join(temp,'lifeboat-equipment-details.mjs')));
 const {root,equipment}=buildInterior();
 for(const id of ['painter','spare-painter','radar-reflector','searchlight','jackknife','rescue-signals','dipper','bailer','second-bucket','second-quoit','second-boat-hook','forward-hatchet','can-opener-2','can-opener-3','seasickness-bags','air-horn','solar-still'])assert.ok(equipment.some(e=>e.id===id),`Missing video equipment: ${id}`);
 function snapshot(){root.updateMatrixWorld(true);return root.children.map(group=>{
  let meshes=0,triangles=0;
  group.traverse(o=>{if(o instanceof THREE.Mesh){meshes++;const g=o.geometry;triangles+=(g.index?.count??g.attributes.position.count)/3;

  }});
  return {id:group.userData.sourceObjectId,meshes,triangles};
 });}
 const {storageReveal,storedItemVisible}=await import(pathToFileURL(path.join(temp,'lifeboat-fitting.mjs')));
 assert.equal(storageReveal(8),0);assert.equal(storageReveal(0),1);
 assert.equal(storedItemVisible(storageReveal(8),false),false);
 assert.equal(storedItemVisible(storageReveal(.6),false),true);
 const fittings=new Map(root.children.map(g=>[g.name,g]));
 for(const id of ['benches','center-bench']){assert.equal(fittings.get(id).userData.structurallyAttached,true);const bounds=new THREE.Box3().setFromObject(fittings.get(id));assert.ok(bounds.min.z>4.29,'Bench must not obstruct side-hatch access');assert.ok(bounds.min.y<4.33,'Bench supports must meet deck');}
 // A backrest may fit the hull yet still be warped. Require the two long
 // side backrests to remain straight upright slabs, not hull-shaped surfaces.
 const sideBackrests=fittings.get('benches').children.filter(m=>{const size=new THREE.Box3().setFromObject(m).getSize(new THREE.Vector3());return size.z>2.5&&size.y>.5;});
 assert.equal(sideBackrests.length,2);
 for(const back of sideBackrests){const bounds=new THREE.Box3().setFromObject(back);assert.ok(bounds.max.x-bounds.min.x<.095,'Side backrests must be straight and upright');}
 for(const id of ['harnesses','center-belts']){const g=fittings.get(id),seats=g.userData.seats;assert.equal(seats.length,id==='harnesses'?10:12);const colors=new Set();g.traverse(o=>{if(o instanceof THREE.Mesh)colors.add(o.material.color.getHex());});for(const seat of seats)assert.ok(colors.has(seat.color),'Alternating belt color must exist in rendered geometry');for(const row of new Set(seats.map(s=>s.row))){const adjacent=seats.filter(s=>s.row===row).sort((a,b)=>a.z-b.z);for(let i=1;i<adjacent.length;i++)assert.notEqual(adjacent[i].color,adjacent[i-1].color,'Adjacent seats must have contrasting belts');}}
 for(const g of root.children){const zone=g.userData.storageId;if(!zone)continue;assert.ok(fittings.has(zone),`Missing storage: ${g.name}`);if(zone==='engine-hatch')continue;const z=fittings.get(zone).userData.storageZone;const box=new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(...z.center),new THREE.Vector3(...z.size));box.expandByScalar(.015);assert.ok(box.containsBox(new THREE.Box3().setFromObject(g)),`Equipment outside its locker: ${g.name}`);assert.equal(equipment.find(e=>e.id===g.name).stowage.id,zone);}
 const coverTriangles=()=>{const cover=new Map();root.traverse(m=>{if(m instanceof THREE.Mesh&&m.userData.compartmentCover){const id=m.userData.compartmentCover;cover.set(id,(cover.get(id)||0)+(m.geometry.index?.count??m.geometry.attributes.position.count)/3);}});return [...cover].sort();};
 const coverBefore=coverTriangles();assert.equal(coverBefore.length,9);
 const before=snapshot();batchInterior(root);const after=snapshot();assert.deepEqual(coverTriangles(),coverBefore,'Batching must retain compartment-cover behavior');

 assert.equal(root.children.length,equipment.length);
 for(let i=0;i<before.length;i++){
  assert.equal(after[i].id,before[i].id);assert.equal(after[i].triangles,before[i].triangles);
 }
 const original=buildInterior().root;
 for(let i=0;i<root.children.length;i++){
  const a=new THREE.Box3().setFromObject(root.children[i]),b=new THREE.Box3().setFromObject(original.children[i]);
  assert.ok(a.min.distanceTo(b.min)<1e-5&&a.max.distanceTo(b.max)<1e-5);
 }
 const {buildModelLabels,modelObjectId}=await import(pathToFileURL(path.join(temp,'lifeboat-labels.mjs')));
 for(const file of ['davit-lifeboat.glb','davit-lifeboat-mobile.glb']){
  const bytes=await fs.readFile(`public/models/${file}`);
  checkBenchClearance(root,bytes);
  const gltf=JSON.parse(bytes.subarray(20,20+bytes.readUInt32LE(12)).toString());
  const scene=new THREE.Group();
  for(const n of gltf.nodes){const node=new THREE.Mesh();node.name=n.name;node.userData={...n.extras};scene.add(node);}
  scene.add(root);
  const labels=buildModelLabels(scene,[...referenceEquipment,...equipment]);
  assert.equal(labels.length,159+equipment.length);
  assert.equal(new Set(labels.map(l=>l.id)).size,labels.length);
  assert.equal(new Set(labels.map(l=>l.name)).size,labels.length);
  scene.traverse(node=>{if(node instanceof THREE.Mesh){const matches=labels.filter(l=>l.objects.includes(modelObjectId(node)));assert.equal(matches.length,1,`Unlabelled or ambiguous mesh: ${node.name}`);}});
  assert.equal(labels.filter(l=>l.unverified).length,0,'Existing source objects must all have descriptive names');
  assert.ok(labels.every(l=>l.name&&l.description&&l.location));
  assert.ok(labels.every(l=>{const d=equipmentDetails(l);return d.meaning&&d.quantity&&d.use&&d.care;}),'Every selectable part must provide complete inspection information');
  assert.ok(equipmentDetails(labels.find(l=>l.id==='water')).quantity.includes('3 litres'));
  assert.equal(equipmentDetails(labels.find(l=>l.id==='solar-still')).optional,true);
  assert.ok(labels.filter(l=>l.source==='Reference model').every(l=>l.identification&&l.references.length));
  assert.equal(labels.find(l=>l.id==='NODE204').name,'Aft Lifting / Release Hook');
  assert.equal(labels.find(l=>l.id==='NODE112').name,'Aft Winch Drive Housing');
  assert.equal(labels.find(l=>l.id==='NODE194').name,'Steering Nozzle / Duct Rudder');
  const added=new THREE.Mesh();added.userData.sourceObjectId='NEW-FITTING';scene.add(added);
  assert.ok(buildModelLabels(scene,[...referenceEquipment,...equipment]).some(l=>l.id==='NEW-FITTING'));
  console.log(`${file}: all ${labels.length} part labels covered; every mesh resolves to one label`);
 }
 const source=new THREE.MeshStandardMaterial({color:0xf58327,opacity:.4,transparent:true,side:THREE.DoubleSide});
 source.map=new THREE.Texture();const light=viewerMaterial(source,true);
 assert.ok(light.isMeshLambertMaterial);assert.equal(light.map,source.map);assert.ok(light.color.equals(source.color));assert.equal(light.opacity,.4);assert.equal(light.side,THREE.DoubleSide);
 const a=before.reduce((n,g)=>n+g.meshes,0),b=after.reduce((n,g)=>n+g.meshes,0);
 assert.ok(b<a*.5);
 console.log(JSON.stringify({equipment:equipment.length,meshesBefore:a,meshesAfter:b,triangles:after.reduce((n,g)=>n+g.triangles,0),groupBounds:'unchanged',mobileMaterial:'passed'}));
} finally {await fs.rm(temp,{recursive:true,force:true});}
