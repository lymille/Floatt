"""Faithfully convert the supplied triangulated OBJ and MTL to a self-contained GLB.
Preserves source object identifiers and mesh detail. Usage: python scripts/convert-lifeboat.py SOURCE_DIR
"""
from pathlib import Path
import json,struct,sys
import numpy as np
src=Path(sys.argv[1]);out=Path('public/models');out.mkdir(parents=True,exist_ok=True)
blob=bytearray();views=[];access=[]
def add_bytes(data,target=None):
 while len(blob)%4:blob.append(0)
 v={'buffer':0,'byteOffset':len(blob),'byteLength':len(data)}
 if target:v['target']=target
 views.append(v);blob.extend(data);return len(views)-1
def attr(data,kind,bounds=False):
 a=np.array(data,dtype='<f4');v=add_bytes(a.tobytes(),34962);d={'bufferView':v,'componentType':5126,'count':len(a),'type':kind}
 if bounds:d.update(min=a.min(0).tolist(),max=a.max(0).tolist())
 access.append(d);return len(access)-1
materials=[];images=[];textures=[];mat_ids={};current=None
for line in (src/'Davit_3.mtl').read_text().splitlines():
 if line.startswith('newmtl '):
  current={'name':line[7:],'pbrMetallicRoughness':{'baseColorFactor':[1,1,1,1],'metallicFactor':0.15,'roughnessFactor':0.65},'doubleSided':True};mat_ids[current['name']]=len(materials);materials.append(current)
 elif line.startswith('map_Kd '):
  p=src/line[7:];images.append({'bufferView':add_bytes(p.read_bytes()),'mimeType':'image/jpeg'});textures.append({'source':len(images)-1});current['pbrMetallicRoughness']['baseColorTexture']={'index':len(textures)-1}
 elif line.startswith('Kd '):current['pbrMetallicRoughness']['baseColorFactor'][:3]=[float(v) for v in line.split()[1:]]
 elif line.startswith('Tr '):
  alpha=1-float(line.split()[1]);current['pbrMetallicRoughness']['baseColorFactor'][3]=alpha
  if alpha<1:current['alphaMode']='BLEND'
positions=[];normals=[];uvs=[];objects=[];obj=None;material='acmat_0'
for line in (src/'Davit 3.obj').open():
 bits=line.strip().split();
 if not bits:continue
 tag=bits[0]
 if tag=='v':positions.append([float(x) for x in bits[1:4]])
 elif tag=='vn':normals.append([float(x) for x in bits[1:4]])
 elif tag=='vt':uvs.append([float(bits[1]),1-float(bits[2])])
 elif tag=='o':obj={'name':' '.join(bits[1:]),'segments':{}};objects.append(obj)
 elif tag=='usemtl':material=bits[1]
 elif tag=='f':
  if obj is None:raise ValueError('Face without object')
  refs=[tuple(int(x) if x else 0 for x in val.split('/')) for val in bits[1:]]
  for i in range(1,len(refs)-1):obj['segments'].setdefault(material,[]).extend([refs[0],refs[i],refs[i+1]])
meshes=[];nodes=[];inventory=[];seen={}
for obj in objects:
 source_name=obj["name"];seen[source_name]=seen.get(source_name,0)+1
 if seen[source_name]>1:obj["name"]=f"{source_name}-{seen[source_name]}"
 prim=[];coords=[];triangles=0
 for mat,refs in obj['segments'].items():
  if not refs:continue
  p=[positions[r[0]-1] for r in refs];n=[normals[r[2]-1] for r in refs];uv=[uvs[r[1]-1] for r in refs];coords+=p;triangles+=len(refs)//3
  prim.append({'attributes':{'POSITION':attr(p,'VEC3',True),'NORMAL':attr(n,'VEC3'),'TEXCOORD_0':attr(uv,'VEC2')},'material':mat_ids[mat]})
 if not prim:continue
 meshes.append({'name':obj['name'],'primitives':prim});nodes.append({'name':obj['name'],'mesh':len(meshes)-1,'extras':{'sourceObjectId':obj['name']}})
 c=np.array(coords);inventory.append({'id':obj['name'],'triangles':triangles,'materials':list(obj['segments']),'min':c.min(0).tolist(),'max':c.max(0).tolist()})
gltf={'asset':{'version':'2.0','generator':'Survival Craft reference-preserving OBJ converter'},'scene':0,'scenes':[{'nodes':list(range(len(nodes)))}],'nodes':nodes,'meshes':meshes,'materials':materials,'textures':textures,'images':images,'accessors':access,'bufferViews':views,'buffers':[{'byteLength':len(blob)}]}
j=json.dumps(gltf,separators=(',',':')).encode();j+=b' '*((-len(j))%4);blob.extend(b'\0'*((-len(blob))%4))
glb=struct.pack('<III',0x46546c67,2,12+8+len(j)+8+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
(out/'davit-lifeboat.glb').write_bytes(glb)
Path('lib/model-inventory.json').write_text(json.dumps(inventory,indent=2))
a=np.array(positions);print(json.dumps({'objects':len(meshes),'triangles':sum(x['triangles'] for x in inventory),'sizeBytes':len(glb),'min':a.min(0).tolist(),'max':a.max(0).tolist()}))
