import fs from 'node:fs/promises';
import path from 'node:path';
import {pathToFileURL} from 'node:url';
import {gzipSync} from 'node:zlib';
import assert from 'node:assert/strict';
import ts from 'typescript';
import * as THREE from 'three';
import {checkFreefallClearance} from './freefall-shell-clearance.mjs';

const temp=await fs.mkdtemp(path.resolve('.freefall-check-'));
try{
 for(const name of ['freefall-lifeboat','freefall-interior','lifeboat-rendering']){
  const text=(await fs.readFile(`lib/${name}.ts`,'utf8')).replace("'./freefall-interior'","'./freefall-interior.mjs'");
  await fs.writeFile(path.join(temp,`${name}.mjs`),ts.transpileModule(text,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ESNext}}).outputText);
 }
 const {buildFreefallLifeboat,freefallPoint}=await import(pathToFileURL(path.join(temp,'freefall-lifeboat.mjs')));
 const {batchInterior,viewerMaterial}=await import(pathToFileURL(path.join(temp,'lifeboat-rendering.mjs')));
 const {root,equipment,boatBounds,boatPose,seats}=buildFreefallLifeboat();
 checkFreefallClearance(root,boatPose);
 const ids=new Set(equipment.map(e=>e.id));assert.equal(ids.size,equipment.length);
 // This small registry lets saved progress validate IDs without loading Three.js.
 // Regenerate when adding/removing modeled parts: --sync-learning-ids.
 if(process.argv.includes('--sync-learning-ids'))await fs.writeFile('lib/freefall-part-ids.json',JSON.stringify([...ids],null,2)+'\n');
 const learningIds=JSON.parse(await fs.readFile('lib/freefall-part-ids.json','utf8'));
 assert.deepEqual([...learningIds].sort(),[...ids].sort(),'Every modeled free-fall part must have exactly one progress ID');
 // Keep the lightweight Components catalog aligned with the 3D inventory.
 const componentCatalog=equipment.map(e=>({id:e.id,name:e.name,category:e.category,purpose:e.description,location:e.location,quantity:e.learning.quantity,use:e.learning.use,care:e.learning.care,...(e.stowage?{stowage:e.stowage}:{}),identification:e.identification,references:e.references}));
 if(process.argv.includes('--sync-component-catalog'))await fs.writeFile('lib/freefall-components.json',JSON.stringify(componentCatalog,null,2)+'\n');
 assert.deepEqual(JSON.parse(await fs.readFile('lib/freefall-components.json','utf8')),componentCatalog,'Components must match the current model; regenerate with --sync-component-catalog after editing its inventory');
 assert.equal(root.children.length,equipment.length);
 const metrics=()=>{let triangles=0,meshes=0;root.traverse(o=>{if(o instanceof THREE.Mesh){meshes++;triangles+=(o.geometry.index?.count??o.geometry.attributes.position.count)/3;}});return {triangles,meshes};};
 const before=metrics(),bounds=new Map();root.updateMatrixWorld(true);
 const nodes=new Map(root.children.map(g=>[g.userData.sourceObjectId,g]));
 assert.equal(seats.length,15,'The illustrated arrangement has 14 passenger seats and a helm seat');
 assert.equal(seats.filter(s=>s.helm).length,1);
 const harnesses=root.children.filter(g=>g.userData.harness);
 assert.equal(harnesses.length,seats.length,'Every seat needs its own identifiable restraint');
 for(const seat of seats){
  assert.deepEqual(nodes.get(seat.id).userData.seat.facing,seat.helm?[0,0,1]:[0,0,-1],'The operating helm faces forward; passenger seats face aft');
  assert.equal(harnesses.filter(g=>g.userData.harness.seatId===seat.id).length,1);
 }
 for(const z of new Set(seats.filter(s=>!s.helm).map(s=>s.z))){
  const row=seats.filter(s=>!s.helm&&s.z===z).sort((a,b)=>a.x-b.x);
  row.slice(1).forEach((seat,i)=>assert.notEqual(seat.color,row[i].color,'Adjacent restraints must alternate colors'));
 }
 const inversePose=boatPose.clone().invert(),point=new THREE.Vector3(),escaped=[];
 const helm=nodes.get('ff-helm-seat');
 const seatPan=helm.getObjectByName('seat-pan').getWorldPosition(new THREE.Vector3()).applyMatrix4(inversePose);
 const seatBack=helm.getObjectByName('seat-back').getWorldPosition(new THREE.Vector3()).applyMatrix4(inversePose);
 const platform=helm.getObjectByName('helm-platform');platform.geometry.computeBoundingBox();
 const platformBox=platform.geometry.boundingBox.clone().applyMatrix4(inversePose.clone().multiply(platform.matrixWorld));
 assert.ok(platformBox.max.z>=-2.06&&platformBox.max.y>=1.65,'The forward platform must support the console legs and driver’s feet');
 assert.ok(seatBack.z<seatPan.z,'The actual helm backrest must sit aft of its seat pan');
 const localBounds=id=>{const b=new THREE.Box3();nodes.get(id).traverse(o=>{if(o.isMesh){o.geometry.computeBoundingBox();b.union(o.geometry.boundingBox.clone().applyMatrix4(inversePose.clone().multiply(o.matrixWorld)));}});return b;};
 const wheelBox=localBounds('ff-steering-wheel'),consoleBox=localBounds('ff-console');
 assert.ok(wheelBox.min.z>seatPan.z+.15,'The steering wheel must be ahead of the driver');
 assert.ok(consoleBox.getCenter(new THREE.Vector3()).z>wheelBox.getCenter(new THREE.Vector3()).z,'The dashboard must be ahead of the wheel');
 assert.ok(consoleBox.max.y<2.79,'The dashboard must remain below the forward window');
 assert.ok(localBounds('ff-throttle').min.x>0,'The throttle must be at the driver’s starboard hand');
 const shell=[nodes.get('ff-canopy'),nodes.get('ff-wheelhouse')],sides=new Map();
 for(const g of shell)g.traverse(o=>{if(o.isMesh){if(!sides.has(o.material))sides.set(o.material,o.material.side);o.material.side=THREE.DoubleSide;}});
 const roofRay=new THREE.Raycaster(freefallPoint(0,3.30,-2.80),new THREE.Vector3(0,-1,0).transformDirection(boatPose));
 const roofHit=roofRay.intersectObjects(shell,true)[0];
 assert.ok(!roofHit||roofHit.point.clone().applyMatrix4(inversePose).y<2,'The cabin roof must not cross the raised helm occupant');
 for(const [material,side] of sides)material.side=side;
 for(const item of root.children.filter(g=>g.userData.storageId)){
  const holder=nodes.get(item.userData.storageId),zone=holder?.userData.storageZone;
  assert.ok(zone,`${item.name} must have a real storage compartment`);
  const inside=new THREE.Box3().setFromCenterAndSize(new THREE.Vector3(...zone.center),new THREE.Vector3(...zone.size)).expandByScalar(.001);
  let outside=false;
  item.traverse(mesh=>{if(mesh instanceof THREE.Mesh){const transform=inversePose.clone().multiply(mesh.matrixWorld),positions=mesh.geometry.attributes.position;for(let i=0;i<positions.count;i++){point.fromBufferAttribute(positions,i).applyMatrix4(transform);if(!inside.containsPoint(point))outside=true;}}});
  if(outside)escaped.push(item.name);
 }
 assert.deepEqual(escaped,[],'Stored equipment must fit inside its assigned compartment');
 for(const g of root.children){
  const id=g.userData.sourceObjectId;assert.ok(ids.has(id));
  const label=equipment.find(e=>e.id===id);
  assert.ok(label.name&&label.description&&label.location&&label.learning.use);
  assert.equal(label.partId,undefined,'Free-fall additions must not change the existing 61-lesson progress');
  const b=new THREE.Box3().setFromObject(g,true);assert.ok(!b.isEmpty());bounds.set(id,b);
  g.traverse(o=>{if(o instanceof THREE.Mesh){assert.ok(o.geometry.attributes.normal);for(const x of o.geometry.attributes.position.array)assert.ok(Number.isFinite(x));}});
 }
 assert.ok(freefallPoint(0,0,4).y<freefallPoint(0,0,-4).y,'Bow must point down the launch slope');
 assert.ok(new THREE.Box3().setFromObject(root).min.y>=-.001,'Frame must not extend below its base');
 assert.ok(boatBounds.getSize(new THREE.Vector3()).length()>6);
 const skid=root.children.find(g=>g.userData.sourceObjectId==='ff-skid');
 const runners=root.children.find(g=>g.userData.sourceObjectId==='ff-runners');
 assert.ok(skid.quaternion.angleTo(runners.quaternion)<1e-8,'Boat runners must align with the ramp');
 const left=skid.children.filter(m=>m.position.x<0),right=skid.children.filter(m=>m.position.x>0);
 assert.ok(left.length&&right.length,'Both skidways must exist');
 // Their contact surfaces coincide in local coordinates to within 1 mm.
 const railTop=.092+.055/2,runnerBottom=.185-.13/2;
 assert.ok(Math.abs(railTop-runnerBottom)<.001,'Boat runners must rest on the skidways');
 batchInterior(root);const after=metrics();assert.equal(after.triangles,before.triangles);
 assert.ok(after.meshes<340,'Keep mobile draw calls bounded');assert.ok(after.triangles<100000);
 for(const g of root.children){const a=bounds.get(g.userData.sourceObjectId),b=new THREE.Box3().setFromObject(g,true);assert.ok(a.min.distanceTo(b.min)<1e-5&&a.max.distanceTo(b.max)<1e-5);}
 for(const touch of [true,false])root.traverse(o=>{if(o instanceof THREE.Mesh){const m=viewerMaterial(o.material,touch);assert.equal(m.opacity,1);assert.ok(m.color.equals(o.material.color));m.dispose();}});
 const exportPath=process.argv.slice(2).find(v=>!v.startsWith('--'));
 if(exportPath){
  const meshes=[];root.traverse(o=>{if(o instanceof THREE.Mesh){const geo=o.geometry.index?o.geometry.toNonIndexed():o.geometry.clone();geo.applyMatrix4(o.matrixWorld);meshes.push({id:o.parent.userData.sourceObjectId,positions:Array.from(geo.attributes.position.array),normals:Array.from(geo.attributes.normal.array),interior:!!o.parent.userData.interior,storageId:o.parent.userData.storageId,storageCover:o.parent.userData.storageCover,color:o.material.color.toArray()});geo.dispose();}});
  await fs.writeFile(exportPath,gzipSync(JSON.stringify(meshes)));
 }
 console.log(JSON.stringify({parts:equipment.length,before,after,bounds:new THREE.Box3().setFromObject(root),checks:'Unique labels, finite geometry, mobile materials, runner contact, ramp alignment and unchanged lesson IDs passed'}));
}finally{await fs.rm(temp,{recursive:true,force:true});}
