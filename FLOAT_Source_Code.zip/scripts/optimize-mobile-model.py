"""Build the touch-device asset without removing triangles or selectable objects."""
import json,struct,io,copy,hashlib
from pathlib import Path
import numpy as np
from PIL import Image
source=Path('public/models/davit-lifeboat.glb').read_bytes();size=struct.unpack_from('<I',source,12)[0];original=json.loads(source[20:20+size]);raw=source[28+size:];g=copy.deepcopy(original)
blob=bytearray();views=[];accessors=[]
def add(data,target=None):
 blob.extend(b'\0'*((-len(blob))%4));v={'buffer':0,'byteOffset':len(blob),'byteLength':len(data)}
 if target:v['target']=target
 views.append(v);blob.extend(data);return len(views)-1
widths={'VEC2':2,'VEC3':3,'SCALAR':1}
def get(index):
 a=original['accessors'][index];v=original['bufferViews'][a['bufferView']];assert a['componentType']==5126
 return np.frombuffer(raw,dtype='<f4',count=a['count']*widths[a['type']],offset=v.get('byteOffset',0)+a.get('byteOffset',0)).reshape(a['count'],-1)
def attr(a,kind,position=False):
 entry={'bufferView':add(a.astype('<f4').tobytes(),34962),'componentType':5126,'count':len(a),'type':kind}
 if position:entry.update(min=a.min(0).tolist(),max=a.max(0).tolist())
 accessors.append(entry);return len(accessors)-1
triangles=0
for mesh in g['meshes']:
 for p in mesh['primitives']:
  keys=list(p['attributes']);arrays=[get(p['attributes'][k]) for k in keys];joined=np.concatenate(arrays,axis=1);unique,inverse=np.unique(joined,axis=0,return_inverse=True)
  assert np.array_equal(unique[inverse],joined), 'Geometry changed'
  cursor=0;attrs={}
  for key,a in zip(keys,arrays):
   w=a.shape[1];attrs[key]=attr(unique[:,cursor:cursor+w],'VEC'+str(w),key=='POSITION');cursor+=w
  p['attributes']=attrs;dtype='<u2' if len(unique)<65536 else '<u4';accessors.append({'bufferView':add(inverse.astype(dtype).tobytes(),34963),'componentType':5123 if dtype=='<u2' else 5125,'count':len(inverse),'type':'SCALAR'});p['indices']=len(accessors)-1;triangles+=len(inverse)//3
tex_bytes=0
for image in g['images']:
 v=original['bufferViews'][image['bufferView']];im=Image.open(io.BytesIO(raw[v.get('byteOffset',0):v.get('byteOffset',0)+v['byteLength']])).convert('RGB');im.thumbnail((512,512),Image.Resampling.LANCZOS);tex_bytes+=im.width*im.height*4;buf=io.BytesIO();im.save(buf,format='JPEG',quality=85,optimize=True);image['bufferView']=add(buf.getvalue());image['mimeType']='image/jpeg'
g['accessors']=accessors;g['bufferViews']=views;g['buffers']=[{'byteLength':len(blob)}];g['asset']['generator']='Survival Craft touch-device optimization (lossless mesh indexing)';j=json.dumps(g,separators=(',',':')).encode();j+=b' '*((-len(j))%4);blob+=b'\0'*((-len(blob))%4)
out=struct.pack('<III',0x46546c67,2,28+len(j)+len(blob))+struct.pack('<II',len(j),0x4e4f534a)+j+struct.pack('<II',len(blob),0x004e4942)+blob
Path('public/models/davit-lifeboat-mobile.glb').write_bytes(out)
assert [n['extras'] for n in original['nodes']]==[n['extras'] for n in g['nodes']]
print(json.dumps({'originalBytes':len(source),'mobileBytes':len(out),'textureMiBWithMipmaps':round(tex_bytes*4/3/1048576,2),'objects':len(g['nodes']),'triangles':triangles,'validation':'All expanded vertex attributes exactly match the original; object IDs preserved.'}))
