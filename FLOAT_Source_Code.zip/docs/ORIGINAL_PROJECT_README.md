> Historical project notes from the source snapshot. For current export and hosting instructions, read the top-level README.md. Some descriptions below may be outdated.

# Survival Craft learning

Private Sites learning app with a mandatory baseline assessment, equipment familiarization, function exercises, a gated final assessment, and score certificates.

- Authentication uses the platform's verified ChatGPT identity headers and dispatch-owned sign-in routes. Direct Google OAuth is **not implemented**. Never substitute an email field for verified identity.
- Profiles, attempts, answer order, answers, and learning progress are stored in D1 and scoped to the signed-in user.
- There are 70 authored assessment items: 35 pre-test questions and 35 differently worded post-test counterparts. Both order and options are shuffled once per saved attempt. Function exercises are separate from this assessment bank.
- Each test can be completed once per account. Partial answers resume. Server-side grading and a unique user/test index protect saved results.
- All 61 parts must be manually marked Learned It and all 61 function exercises passed before starting or submitting the post-test.
- Achievements display saved certificates. SVG downloads are produced from immutable assessment records; the certificate view also supports printing.
- The 61-part curriculum is general, not a verified inventory of a particular lifeboat. The 3D explorer preserves the supplied davit lifeboat as 159 selectable objects. The interior adds named training equipment and lesson links. Unidentified original fittings retain an explicit unverified label; other learning games remain future work.
- Certificates are learning records, not professional qualifications.

## Development

Use the Sites setup, build and publishing scripts. `node tests/assessment.cjs` tests the actual API handlers against isolated in-memory SQLite with mocked signed-in identities. It never modifies production records. `node node_modules/typescript/bin/tsc --noEmit` checks types.

Schema changes are defined in `db/schema.ts`; use Drizzle-generated migrations. Never run schema creation on application requests. Existing applied migrations are immutable.

## Content and assessment

`lib/curriculum.ts` defines part IDs, descriptions, category counts and evaluation bands. `lib/questions.ts` defines both assessment forms. Keep existing part IDs stable when the vessel-specific model is introduced. Preserve question versions and certificates when revising future assessments; do not silently overwrite completed records.

## Lifeboat model

`public/models/davit-lifeboat.glb` is converted from the supplied Davit 3 OBJ with embedded textures. `scripts/convert-lifeboat.py` rebuilds it from the extracted source directory (requires Python and NumPy). Duplicate source object names receive numeric suffixes so selection remains unique. The explorer is loaded on demand after the pre-test gate. Rotation, zoom, selection, pulsing highlight, isolation, hiding, transparency and camera presets are implemented. WebGL is disabled in the managed QA browser; the graceful error screen was verified, but rendered appearance and pointer interactions still need a WebGL-enabled device check. No unverified object is marked as a curriculum part.

## Interior and automatic transparency

`lib/lifeboat-interior.ts` builds 53 equipment groups with stable semantic IDs and links to existing lessons. Locations are an illustrative arrangement fitted inside the original hull, not an as-built inventory. The user’s interior references guide benches, harnesses, rails and stores. The model keeps original exterior geometry. The hull, deck enclosure, canopy and steering shelter fade smoothly based on camera distance to the boat bounding box; zooming out restores them. Auto, forced cutaway and solid modes are available. Raycasting ignores the faded shell below 35% opacity, while isolated selected shell parts remain solid. Engine focus exposes underfloor machinery. Part selection never changes learning status.

Validation: TypeScript compilation; finite generated geometry; unique group IDs and name/purpose coverage; close/far transparency range and monotonicity; offline top and oblique geometry render. Interactive browser QA is limited by WebGL being disabled in the managed browser. General equipment context: https://www.imo.org/en/ourwork/safety/pages/lifesavingappliances-default.aspx . Vessel-specific equipment and placement must be checked against its approved inventory before describing this as an exact vessel model.

## Inspection interface

The explorer uses the supplied video as an interface reference only: full model canvas, overlaid search and category/status filters, bottom controls, and a lower inspection panel with its own scrolling content and fixed learning-status footer. Locate retains the surrounding model; Focus isolates an item. Labels, exploded assembly/reassembly, read-aloud and related-equipment navigation are available. Status buttons call the existing authenticated progress API; additional objects without a curriculum link do not claim saved lesson progress. The original GLB and interior geometry are unchanged. A temporary isolated UI fixture verified selection layout, status callback feedback, close behavior and search; it was removed before packaging. Live WebGL rendering remains unverified in the managed browser.

## Touch-device stability

The touch-device GLB preserves all 159 source object IDs, 149,050 triangles and exact expanded position/normal/UV attributes, using indexed vertices and textures capped at 512px. `scripts/optimize-mobile-model.py` reproduces the asset and asserts lossless mesh indexing. Compressed model size falls from 18,088,656 to 6,743,760 bytes; estimated RGBA texture memory including mipmaps falls from 64.95 to 17.63 MiB. Desktop retains the original asset. Touch rendering disables multisample antialiasing, caps the render buffer at one million pixels and frame rate at 30fps, and skips rendering while idle. Background tabs pause the loop. Abortable downloads, released ImageBitmaps/WebGL contexts, and context-loss retry avoid retaining old models when leaving/re-entering the viewer. These changes address memory-pressure contributors; the user’s iPad process crash cannot be reproduced in the managed browser, which lacks WebGL.

## Complete model labels

`lib/lifeboat-labels.ts` builds the label catalog from the loaded scene, covering all 159 original source objects and 53 interior equipment groups (212 entries). Every mesh resolves through its labelled ancestor. Multi-object exterior assemblies receive individual labels; known lesson IDs remain unchanged. Anonymous original fittings carry their unique source ID and an explicit “Name unverified” designation, without fabricated names, functions, or progress links. Future source objects also receive a fallback label automatically.

Labels start enabled. The selected part has priority, and overlapping labels are suppressed in the overview; zooming and the complete searchable All Parts list provide access to crowded fittings. Label anchors are cached in object-local coordinates to follow exploded parts without repeatedly walking their geometry. `node scripts/check-lifeboat-rendering.mjs` checks both GLB inventories, unique labels, all-mesh coverage, future-object coverage and retained interior geometry. Browser 3D QA remains limited by the managed browser’s disabled WebGL.

## Guide-based part identification

`lib/model-identifications.json` replaces the 148 temporary original-fitting labels with descriptive equipment and mechanical-part names. All 159 original object mappings were inspected in isolated geometry sheets and selected assembly views, including the winch, hook and davit pivots. Fore/aft is checked against the propeller/stern and the model’s longitudinal coordinates. The source has a duplicated aft drive end-cover object and a combined forward suspension-block centre fitting; labels describe those facts rather than inventing separate geometry.

The user-supplied guide is available inside each inspection panel. Terminology was cross-checked against the IMO MSC.1/Circ.1205 example manual (reproduced at imorules.com) and VIKING Norsafe JYN-65 TSB-0120 Rev.3. These references describe equipment types; they do not establish the uploaded model’s manufacturer or its exact bill of materials. Each original mapping records whether it is a guide/geometry match or a descriptive identification from geometry. Unrepresented internal control functions, drive internals and manufacturer part numbers are explicitly not asserted. Future unknown objects retain the unverified fallback. All 212 labels include a purpose and location; scene geometry and assessment records are unchanged.

### Video equipment expansion

The equipment walkthrough at https://www.youtube.com/watch?v=vTG5whMYbek was reviewed via its English auto-generated transcript. The model adds 23 selectable equipment groups, including painters and their securing fitting, radar reflector, searchlight, torch spares, jackknife, signals card, dipper, bailer, second bucket/quoit/boat hook/hatchet, two additional tin openers, seasickness bags, optional air horn/solar still, manual desalinator, oar supports and lights. Existing signal groups now display four rocket flares, six hand flares and two smoke signals.

`lib/lifeboat-equipment-details.ts` supplies meaning, quantity, use and care information with timestamp links where the video discusses the item. Baseline equipment quantities were cross-checked against IMO MSC.48(66), sections 4.4.7–4.4.8; this original adopted text is identified as such, not represented as a current consolidated inventory certificate. The site differentiates optional equipment, ship-level radio allocation and capacity-based supplies. It does not repeat the video's blanket medicine advice, six-miles/hour claim, or assertion that fishing tackle exists only for morale. The model's inventory remains educational; neither rendered seats nor the 61 lessons establish approved capacity.

All 235 named source/equipment groups retain ray-picking coverage. Additional equipment uses the existing batched geometry and touch-device rendering path. Existing lesson IDs, assessment gates and stored progress are unchanged. The rendering check validates geometry preservation, labels and required item detail coverage; it does not certify a real device's GPU performance.

### Attached seating, detailed equipment and concealed stowage

`lib/lifeboat-fitting.ts` refits the learning interior with continuous side benches, a back-to-back center bench, structural feet and hull-side supports, and two clear longitudinal aisles. Seating starts forward of the modeled side-hatch openings. Neighboring belt sets alternate yellow and dark blue, illustrating the contrast requirement in LSA Code 4.6.3.1; these particular colors are a design choice. This is an illustrative arrangement, not a new certified capacity.

Portable equipment is refined with shaped containers, working-form cups/buckets, case seams and latches, folded supplies, quick-access clips, and detailed buckles/instruments. Assigned medical, signal, food, water, thermal, tool and recovery compartments enclose the contents. The aft engine hatch covers the machinery. Floating-display equipment and the erected storage example of the radar reflector have been removed in favor of secured stowage.

Stored meshes and their labels are hidden from the overview. As the camera approaches an individual compartment, its case and associated bench panels fade to reveal contents; selecting a stored item from search moves to its location. The explicit Focus inspection still isolates the selected part. Batched meshes retain per-panel compartment metadata so transparent lids can also be excluded from picking. Long items and emergency equipment remain in reachable holders and appear on closer approach. The source model geometry is retained; desktop material finishes and a bounded environment reflection improve painted, glass and metal surfaces. Touch devices retain the lightweight lighting/material path.

Verification covers all 250 label groups, actual containment within lockers, bench clearance from the side-hatch area, alternating rendered belt colors, and retained cover geometry after batching. Model triangle count remains below the preceding equipment expansion despite added details. Physical iPad rendering is not validated in the available environment.
